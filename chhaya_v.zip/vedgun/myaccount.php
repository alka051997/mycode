<?php
include('dbconnect.php');

if(!$is_login){
  header("location: login.php");
}
$sql_detail = mysqli_query($con,"select * from ac_party_led where ledger_id='$userid'");
$row_detail = mysqli_fetch_assoc($sql_detail);
$ledger_id = $row_detail['ledger_id'];
$l_name = $row_detail['l_name'];
$mobile1 = $row_detail['mobile'];
$email  = $row_detail['email'];
$state = $row_detail['state'];
$city = $row_detail['city'];
$pin_code = $row_detail['pin_code'];
$district = $row_detail['district'];
$address = $row_detail['address'];
$sup_ledger_id = $row_detail['sup_ledger_id'];

if(isset($_POST['submit'])){
  // print_r($_POST);die;
  $l_name = $_POST['name'];
  $mobile = $_POST['mobile'];
  $email = $_POST['email'];
  $state = $_POST['state'];
  $city = $_POST['city'];
  $pin_code = $_POST['pin_code'];
  $district = $_POST['district'];
  $address = $_POST['billing_address'];
  $up_qry = "UPDATE ac_party_led SET l_name = '".$l_name."', mobile = '".$mobile."', email = '".$email."', state = '".$state."', city = '".$city."', pin_code = '".$pin_code."', district = '".$district."', address = '".$address."' WHERE ledger_id = '".$ledger_id."' ";
  mysqli_query($con,$up_qry);
  $up_qry_sup = "UPDATE ac_party_led SET l_name = '".$l_name."', mobile = '".$mobile."', email = '".$email."', state = '".$state."', city = '".$city."', pin_code = '".$pin_code."', district = '".$district."', address = '".$address."' WHERE ledger_id = '".$sup_ledger_id."' ";
  mysqli_query($con_sup,$up_qry_sup);

}
?>
<!doctype html>
<html lang="en-US"> 
<!-- Mirrored from www.Vedgun.com/about-us by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 30 Nov 2020 05:09:01 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
 <title>My Account- Vedgun.com</title> <meta charset="utf-8"> <meta name="robots" content="INDEX,FOLLOW"> <meta name="description" content="Buy Grocery Online in Mumbai, Pune, Bangalore at Vedgun online grocery store. Best price on fresh fruits &amp; vegetables, dairy &amp; bakery, packaged food." /> <meta name="keywords" content="" /> <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"> <meta property="og:site_name" content="Vedgun" /> <meta property="og:type" content="website" /> <meta property="og:title" content="About us - Vedgun.com" /> <meta property="og:description" content="" /> <meta property="og:url" content="about-us.php" /> 
<meta property="og:image" content="assets/global/logo-fb.png" /> <!-- Appple Touch Icons --> 
 <?php include('include/files.php');?>

<style> .multi-srch-hide{ display:none !important; } .ais-InfiniteHits-loadMore{ display:none; } .gift-page #saved_location{ display:none; }</style> 
<link rel="manifest" href="manifest.json">
<style> .otc-product-page #first_desc h2 {display: none} .otc-product-page #first_desc h2.pname{display: block!important;}.catalog-category-view.level-3 .white-bg.msite-list, .catalog-category-view.level-0 .white-bg.msite-list{display:none !important} .cat-fashion .right-block .empty_listing {position:absolute;z-index:3} .compare_products{ display:none; }#bought_together{display:none !important}.prod-groceries #similar_products{display: none;} .prod-groceries .section-seperate1{display: none;} .prod-fashion .new_product #product_details #left_col .gallery-top,.prod-groceries .new_product #product_details #left_col .gallery-top{height: auto;} .gift-page .all-product .row product-list .col-md-3:last-child .price-box{display:none} .gift-page #free_gift_wrap{display:none !important} .best_deals .add_banner {margin: 0 auto;text-align: center;} .best_deals .add_banner img {width: auto;height: 100%;border-radius: 0;} .best_deals .section-seperate{display: none;} .prod-jewellery .brand_name{display:none !important} .prod-jewellery .prepaid_msg{display:block;font-size:14px;color:#dd0608;font-family: sans-serif;} .aa-dropdown-menu .aa-suggestions .aa-suggestion .product-item-info.search-jewellery a .drug_img { background: url(assets/version1605113383/smartweb/images/search_icons/search_jewellery.png) center no-repeat; background-size: 40px; } 

.tab {

    float: left;
    /* border: 1px solid #ccc; */
    background-color: #f1f1f1;
    width: 20%;
    height: 300px;

    /* margin: 0 auto 16px; */
    /* padding: 24px; */
    /* min-height: 235px; */
   
    border: 1px solid #ccc;
  }

/* Style the buttons inside the tab */
.tab button {
  display: block;
  background-color: inherit;
  color: black;
  padding: 10px;
  width: 100%;
  border: none;
  outline: none;
  text-align: left;
  cursor: pointer;
  transition: 0.3s;
  font-size: 17px;
      border-bottom: 1px solid #fff;
}

/* Change background color of buttons on hover */
.tab button:hover {
     background-color: #ff5722;
}

/* Create an active/current "tab button" class */
.tab button.active {
  background-color: #8ec63f;
}

/* Style the tab content */
.tabcontent {
     float: left;
    padding: 0px 12px;
    border: 1px solid #ccc;
    width: 70%;
    /* border-left: none; */
    height: 650px;
    box-shadow: 1px 2px 2px 0.5px rgb(147 133 133);
    margin-left: 10%;
    /* display: block; */
    background: #fff;
    /* margin: 0 auto 16px; */
    /* padding: 24px; */
    /* min-height: 235px; */
    border-radius: 8px;

}
.myaccount{
  margin-top: 20px;
}
.user_img{
width:50px;
}
.user_name{
  color: #ffff;
  font-weight: 700;
}
.per_con{
      margin-top: 30px;
}
.edit_btn{
  background-color: #ff5722;
    color: #fff !important;
    padding: 10px;
    border-radius: 5px;
    margin-top: 22px;
    display: inline-block;
}
.update{
  background-color: #ff5722;
  padding: 10px;
  color: #ffff;
  border-radius: 5px;
}

  </style>
</head> 
<body class="static-page cms-about-us">
  <div class="page-wrapper">
    <div class="top-section"> 
    <?php include('include/header.php');?>  
    </div>
    <main id="maincontent" class=" static-content">
      <div class="breadcrumbs d-none d-sm-block"> 
        <ul class="items">
          <li class="home"> <a href="index.php" title="Go to Home"> Home </a> </li> 
          <li class="home"> <span>My Account</span> </li>
       </ul> 
      </div> 
      <div class="content-section">
        <div class="staticcontent about-us"> 
          <div class="row"> 
            <div class="col-sm-12 myaccount" >
              <div class="tab">
                <button class="tablinks" onclick="openCity(event, 'London')" id="defaultOpen"><img src='images/user.png' class='user_img'>&nbsp;<span class='user_name'> <?php echo ucwords($username);?></span></button>
                <button class="tablinks" onclick="window.location='cart.php'">My Cart</button>
                <button class="tablinks" onclick="openCity(event, 'orders')">My Order</button>
                <button class="tablinks" onclick="#'">Contact Us</button>
                 <button class="tablinks" onclick="window.location='logout.php'">Logout</button>
              </div>

              <div id="London" class="tabcontent">
                <div class='col-md-10'>
                  <h3>Personal Information </h3>
                </div>
                <div class='col-md-2'>
                  <a href='#' class='edit_btn' style='color:#fff'>
                    <span class="glyphicon glyphicon-edit"></span>&nbsp;<span>Edit</span>
                  </a>
                </div>
                <div class='clearfix'></div>
                <hr>
                <div class='col-md-12 per_con'>
                  <form id="signupForm" action='' method='POST'>
                    <div class="topcol col-md-12">
                      <div class='row'>
                        <div class='col-md-6'>
                          <div class="md-form position-relative">
                            <input autocomplete="off" class="form-control" id="name" name='name' placeholder="Your First Name" type="text" value="<?php echo $l_name;?>"  required>
                          </div>
                        </div>
                        <div class='col-md-6'>
                          <div class="md-form position-relative">
                            <input autocomplete="off" class="form-control" name='mobile'  id="mobile"  placeholder="Your Mobile No" onchange="validamobile();" value="<?php echo $mobile1;?>" type="text"  required onchange='return validate'>
                          </div>
                        </div>
                      </div>
                      <br>
                      <div class='row'>
                        <div class='col-md-6'>
                          <div class="md-form position-relative">
                            <input  autocomplete="off" class="form-control" id="email" name="email" placeholder="Enter your Email Id" type="email" value="<?php echo $email;?>"  required>
                          </div>
                        </div>
                  <!--       <div class='col-md-6'>
                          <div class="md-form position-relative">
                             <input  autocomplete="off" class="form-control" id="pincode" name="pincode" placeholder="Enter your Pincode" type="text" value="<?php echo $pincode;?>" readonly required>
                          </div>
                        </div> -->
                        <div class='clearfix'></div>
                      </div>
                      <br>
                      <div class='col-md-12' style="padding-left: 0px;">
                        <h3>Billing Information </h3>
                      </div>
                    <!-- <div class='col-md-1'>
                      <a href='#' class='edit_btn' style='color:#fff'>Edit</a>
                    </div> -->
                      <div class='clearfix'></div>
                      <hr>
                      <div class='row'>
                        <div class='col-md-6'>
                          <div class="md-form position-relative">
                           <select class='form-control'  name='state' id='state' onchange="getCity()">
                              <option value=''>--Select State--</option>
                              <?php 
                                $res = mysqli_query($con,"SELECT state FROM pin_code group by state ");
                                while ($row = mysqli_fetch_assoc($res)) {
                                  echo '<option value="'.$row['state'].'">'.$row['state'].'</option>';
                                }
                              ?>
                           </select>
                           <script>document.getElementById("state").value = "<?php echo $state;?>" </script>
                          </div>
                        </div>
                        <div class='col-md-6'>
                          <div class="md-form position-relative">
                            <select class='form-control'  name='city' id='city' onchange="getPincode()">
                              <option value=''>--Select City--</option>
                           </select>
                           <script>document.getElementById("city").value = "<?php echo $city;?>" </script>
                          </div>
                        </div>
                        <div class='clearfix'></div>
                      </div>
                      <br>
                     <div class='row'>
                        <div class='col-md-6'>
                          <div class="md-form position-relative">
                              <select class='form-control'  name='pin_code' id='pin_code' onchange="getDistrict()">
                              <option value=''>--Select Pincode--</option>
                           </select>
                           <!-- <input  autocomplete="off" class="form-control" id="pincode" name="pincode" placeholder="Enter your Pincode" type="text" value="<?php echo $pin_code;?>"  required> -->
                           <script>document.getElementById("pin_code").value = "<?php echo $pin_code;?>" </script>
                          </div>
                        </div>
                        <div class='col-md-6'>
                          <div class="md-form position-relative">
                            <select class='form-control' name='district' id='district'>
                              <option value=''>--Select District--</option>
                            </select>
                           <script>document.getElementById("district").value = "<?php echo $district;?>" </script>
                          </div>
                        </div>
                      </div>
                      <br>
                      <div class='row'>
                        <div class='col-md-12'>
                          <div class="md-form position-relative">
                           <textarea class='form-control'  style="height:120px;" name='billing_address' id='billing_address' placeholder="Enter Billing Adress...."><?php echo $address;?></textarea>
                          </div>
                        </div>              
                      </div>
                      <br>
                      <input type='submit' name='submit' value='Submit' class='update'>
                    </div>
                  </form>
                </div>
              </div>
              <div id="orders" class="tabcontent">
                <div class='col-md-10'>
                  <h3>Order List </h3>
                </div>
                <div class='clearfix'></div>
                <hr>
                <div class='col-md-12'>
                  <div class="topcol col-md-12">
                    <?php
                      echo $order_qry = "SELECT sp_id,order_v_id,p_desc,p_qty,p_rate,p_amt,invoice_date FROM order_product_list WHERE invoice_to_id = '".$userid."' ";
                      $res = mysqli_query($con,$order_qry);
                      while ($order = mysqli_fetch_assoc($res)) {
                    ?>
                    <div class='row' style="padding:5px;box-shadow: 5px 5px 5px #eee, -5px -5px 5px #eee;color:#666">
                      <div class='col-md-12'>
                        <div class="md-form position-relative col-md-8">
                          <h5 style="line-height: 0.6rem;margin-bottom: 1px"><?php echo $order['p_desc'] ?></h5>
                          <p style="font-size: 11px">Ordered On <?php echo date('d M y',strtotime($order['invoice_date'])); ?> </p>
                        </div>
                        <div class="md-form position-relative col-md-4">
                          <p><?php echo $order['p_rate'] ?> x <?php echo $order['p_qty'] ?> = <?php echo $order['p_amt'] ?></p>
                        </div>
                        <div class="md-form position-relative col-md-4" style="float:right">
                          <button class="btn btn-primary" onclick="window.location='order_detail.php?id=<?php echo $order['sp_id'] ?>'"> Order Detail</button>
                        </div>
                      </div>
                    </div>
                    <?php
                      }
                    ?>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="row"> 

          </div>
        </div>
        <?php include('include/footer.php');?>    
          <!-- Mirrored from www.Vedgun.com/about-us by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 30 Nov 2020 05:09:01 GMT -->
      </div>
    </main> <!-- Copyright Section --> 
  </div>
<script>
function openCity(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}
// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();
</script>
<script>
  {
    getCity();
  }
function getCity(){
  var state = document.querySelector("#state").value;
  var selCity = "<?php echo $city ?>";
  $.ajax({
    type:"POST",
    url:"ajax.php",
    data:{
      getCity:1,
      state:state,
    },
    success:function(data){
      $("#city").empty();
      $("#city").append(`<option>--Select City--</option>`)
      data = JSON.parse(data);
      data.map((city)=>{
        var selected = "";
        if(city == selCity){
          selected = "selected";
        }
        $("#city").append(`<option value="${city}" ${selected} >${city}</option>`);

        if(city == selCity){
          getPincode();
        }
      })
    }
  })
}
function getPincode(){
  var city = document.querySelector("#city").value;
  var selPincode = "<?php echo $pin_code ?>";
  $.ajax({
    type:"POST",
    url:"ajax.php",
    data:{
      getPincode:1,
      city:city,
    },
    success:function(data){
      $("#pin_code").empty();
      $("#pin_code").append(`<option>--Select Pincode--</option>`)
      data = JSON.parse(data);
      data.map((pincode)=>{
        var selected = "";
        if(pincode == selPincode){
          selected = "selected";
        }
        $("#pin_code").append(`<option value="${pincode}" ${selected}>${pincode}</option>`);
        if(pincode == selPincode){
         getDistrict();
        }
      })
    }
  })
}
function getDistrict(){
  var pin_code = document.querySelector("#pin_code").value;
  var selDistrict = "<?php echo $district ?>";
  $.ajax({
    type:"POST",
    url:"ajax.php",
    data:{
      getDistrict:1,
      pin_code:pin_code,
    },
    success:function(data){
      $("#district").empty();
      $("#district").append(`<option>--Select District--</option>`)
      data = JSON.parse(data);
      data.map((district)=>{
        var selected = "";
        if(district == selDistrict){
          selected = "selected";
        }
        $("#district").append(`<option value="${district}" ${selected} >${district}</option>`)
      })
    }
  })
}
</script>
 </body>
</html>