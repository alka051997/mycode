<?php
 include('dbconnect.php');
 if(isset($_POST['submit'])){
    $name=$_POST['name'];
    $mobile=$_POST['mobile'];
    $email=$_POST['email'];
    $password=$_POST['password'];
    $ref_sponsor_code=$_POST['ref_sponsor_code'];
    $ref_sponsor_id = 0;
    if($ref_sponsor_code != ''){
      $ref_sponsor_id = $cmn->getvalfield($con,"ac_party_led","ledger_id","sponsor_code='$ref_sponsor_code' ");
    }
    $rs = mysqli_query($con,"select * from ac_party_led where (mobile='$mobile') ");
    if(mysqli_num_rows($rs)>0){
      echo "<script>alert('Your Mobile is already Registered ');
          </script>";
    }else{
        $sponsor_code = rand(100000000,999999999);
        $qry = "INSERT into ac_party_led(l_name, mobile, email, password, sponsor_code, ref_sponsor_id) values('".$name."','".$mobile."','".$email."','".$password."','".$sponsor_code."','".$ref_sponsor_id."')";
        $datamy = mysqli_query($con,$qry);
        $ledger_id = mysqli_insert_id($con);
        mysqli_query($con_sup,$qry);
        $sup_ledger_id = mysqli_insert_id($con_sup);
        $qry_up = "UPDATE ac_party_led SET sup_ledger_id = '".$sup_ledger_id."' WHERE ledger_id = '".$ledger_id."' ";
        mysqli_query($con,$qry_up);
        echo "<script>alert('Thank you for Registration....');</script>";
        // login process
        $rs=mysqli_query($con,"SELECT * from ac_party_led where (mobile='$mobile') ");
        if(mysqli_num_rows($rs)==1){
          $row = mysqli_fetch_array($rs);
          $_SESSION['username'] = $row['l_name'];
          $_SESSION['userid'] = $row['ledger_id'];
          $_SESSION['mobile'] = $row['mobile'];
          $_SESSION['login'] = true;
          echo "<script>window.location='index.php';</script>";
        }else {
          echo "<script>window.location='index.php?error'</script>";
        }
       echo "<script>
          alert('Thank you for register. Please login to continue.');
          location.href='signin.php';
          </script>";
    }
 }
 ?>
<!Doctype html>
 <html lang="en-US"> 
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
  <title>Buy Grocery Online | Daily Needs Supermarket - Vedgun</title>
  <meta charset="utf-8"> <meta name="robots" content="INDEX,FOLLOW">
  <meta name="description" content="Vedgun - Choose and Buy Online Grocery from a wide range of fruits, vegetables, baby care products, personal care products and much more. Shop Now !" />
  <meta name="keywords" content="Online Grocery, Fruits &amp; Vegetables, Staples, Dairy, Packages Foods, Home care, Personal Care" />
  <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
  <meta property="og:site_name" content="Vedgun" />
  <meta property="og:type" content="website" />
  <meta property="og:title" content="Buy Grocery Online | Daily Needs Supermarket - Vedgun" />
  <meta property="og:description" content="Vedgun - Choose and Buy Online Grocery from a wide range of fruits, vegetables, baby care products, personal care products and much more. Shop Now !" />
  <meta property="og:url" content="index.php" />
  <meta property="og:image" content="assets/global/logo-fb.png" /> <!-- Appple Touch Icons -->
  <meta name="google-play-app" content="app-id=com.jpl.Vedgun">
  <meta name="apple-itunes-app" content="app-id=1522085683">
  <meta name="theme-color" content="#ffffff"/>
  <?php include('include/files.php');?>
  <style> .multi-srch-hide{ display:none !important; }
  .ais-InfiniteHits-loadMore{ display:none; }
  .gift-page #saved_location{ display:none; }
  </style>
  <link rel="manifest" href="manifest.json">
  <style> .otc-product-page #first_desc h2 {display: none}
  .otc-product-page #first_desc h2.pname{display: block!important;}
  .catalog-category-view.level-3 .white-bg.msite-list, .catalog-category-view.level-0 .white-bg.msite-list{display:none !important}
  .cat-fashion .right-block .empty_listing {position:absolute;z-index:3}
  .compare_products{ display:none; }
  #bought_together{display:none !important}
  .prod-groceries #similar_products{display: none;}
  .prod-groceries .section-seperate1{display: none;}
  .prod-fashion .new_product #product_details #left_col .gallery-top,.prod-groceries .new_product #product_details #left_col .gallery-top{height: auto;}
  .gift-page .all-product .row product-list .col-md-3:last-child .price-box{display:none}
  .gift-page #free_gift_wrap{display:none !important}
  .best_deals .add_banner {margin: 0 auto;text-align: center;}
  .best_deals .add_banner img {width: auto;height: 100%;border-radius: 0;}
  .best_deals .section-seperate{display: none;}
  .prod-jewellery .brand_name{display:none !important}
  .prod-jewellery .prepaid_msg{display:block;font-size:14px;color:#dd0608;font-family: sans-serif;}
  .aa-dropdown-menu .aa-suggestions .aa-suggestion .product-item-info.search-jewellery a .drug_img{background: url(assets/version1605113383/smartweb/images/search_icons/search_jewellery.png) center no-repeat; background-size: 40px; } 
  .custreg-form  {
    background: #eee;
    border-radius: 16px;
    overflow: hidden;
    margin-top: 30px;
    padding: 20px;
  }
  .ac-title{
    padding: 0;
    margin: 0 0 8px;
    font-family: sans-serif;
    font-size: 24px;
    color: #000;
    text-align: center;
    width: 100%;
    border-bottom: 2px solid #fff;
    padding-top: 5px;
    padding-bottom: 20px;
    margin-bottom: 24px;
  }
  .sign-txt{
    padding: 0 20px 16px!important;
    margin: 0!important;
  }
  .topcol{
    padding: 0 20px;
    
  }
  .md-form{
       margin-bottom: 21px;
    display: inline-block;
    width: 100%;
  }
  .singalotpcol{
    border: 1px solid rgba(0,0,0,.04);
    font-family: sans-serif;
    font-size: 14px;
    color: #000;
    padding: 9px 0 9px 12px;
    margin: 0;
    width: calc(100% - 3.5rem);
    border-radius: 4px;
  }
  .btn-login{
    background: #ff5722;
    font-family: sans-serif;
    font-size: 14px;
    color: #fff;
    line-height: 20px;
    border-radius: 4px;
    box-shadow: none!important;
    -webkit-box-shadow: none!important;
    -moz-box-shadow: none!important;
    letter-spacing: 1px;
    text-transform: capitalize;
    padding: 10px 6px;
    width: 100%;
    height: 100%;
    margin-top: 20;
    border: 0;
  }
  .pro-img1 {
    width: 100%;
  height: 411px;
    
  }
  .singalotpcol {
    border: 1px solid rgba(0,0,0,.04);
    font-family: sans-serif;
    font-size: 14px;
    color: #000;
    padding: 9px 0 9px 12px;
    margin: 0;
    width: 100%;
    border-radius: 4px;
}
.innercol{
  
      background: #fff;
    padding: 20px;
}
  </style>

</head>
<body class="cms-home Vedgun_home">
  <div class="page-wrapper"> 
    <?php include('include/header.php');?>
    <main>
      <div class="container">
        <div class="custloginmain">
          <div class="custreg-form ">
            <div class="innermain row m-0">
                <h2 class="ac-title">Sign up</h2>
                <br>
                <hr>
              <div class="innercol">
                <div class="col-lg-6 leftcol p-0 d-none d-sm-block">
                  <img class="pro-img1" src="images/login-banner.jpg" alt="Vedgun">
                </div>
                <div class="col-lg-6 rightcol p-0">
                  <form id="signupForm" action='' method='POST'>
                    <div class="topcol">
                      <div class="md-form position-relative">
                        <input autocomplete="off" class="form-control" id="name" name='name' placeholder="Your First Name" type="text" required>
                      </div>
                      <div class="md-form position-relative">
                        <input autocomplete="off" class="form-control" name='mobile'  id="mobile"  placeholder="Your Mobile No" onchange="validamobile();" type="text" required onchange='return validate'>
                      </div>
                      <div class="md-form position-relative">
                        <input  autocomplete="off" class="form-control" id="email" name="email" placeholder="Enter your Email Id" type="email" required>
                      </div>
                    </div>
                    <div class="topcol">
                      <div class="md-form position-relative">
                        <input autocomplete="off" class="form-control" id="password" name='password' placeholder="Enter your Password" type="password" required>
                      </div>
                    </div>
                    <span id='message'></span>
                    <div class="topcol">
                      <div class="md-form position-relative">
                        <input appblockcopypaste="" class="form-control"  id="cpassword" placeholder="Enter your Confirm Password" type="password" name='cpassword' required>
                      </div>
                    </div>
                    <div class="topcol">
                      <div class="md-form position-relative">
                        <input appblockcopypaste="" class="form-control"  id="ref_sponsor_code" placeholder="Enter Valid Sponsor Code" type="text" name='ref_sponsor_code' onchange="validateSponsor()">
                      </div>
                    </div>
                    <!---->
                    <div class="topcol">
                      <input class="singalotpcol logotp ng-untouched ng-pristine ng-invalid" formcontrolname="regotp0" maxlength="6" numbersonly="" name='otp' id='otp' placeholder="Enter your OTP" type="tel">
                    </div>
                    <div class="topcol" style="margin-top: 20px;">
                      <button class="btn-login" style='height: 38px;color: #fff;' type='submit' name='submit'>verify</button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
            <div class="termsbox">
             <p _ngcontent-dxl-c9="" class="terms-service" style="margin-top: 30px;
    font-weight: 700;"> By continuing you agree to our <a style='color:#ff5722;' _ngcontent-dxl-c9="" href="terms_and_conditions.php">Terms of Service </a> & <a _ngcontent-dxl-c9="" href="" style='color:#ff5722;'>Privacy &amp; Legal Policy.</a></p>
            </div>
          </div>
        </div>
      </div>
    </main>
    <?php include('include/footer.php');?>
  </div>
</body> 
<script>
  $('#password, #confirm_password').on('keyup', function () {
    if($('#password').val() == $('#confirm_password').val()) {
      $('#message').html('Matching').css('color', 'green');
    }else{
      $('#message').html('Not Matching').css('color', 'red');
    }
});
</script>
 <script>
  function validateSponsor(){
    var code = document.getElementById('ref_sponsor_code').value;
    $.ajax({
      type: 'POST',
      url: 'mobile.php',
      data:{
        validateSponsor:1,
        code: code,
      },
      success:function(data){
        console.log(data);
        if(data=="valid"){

        }else{
          alert('Please Enter Valid Sponsor Code');
          document.getElementById('ref_sponsor_code').value = '';
          document.getElementById('ref_sponsor_code').focus();
        }
      }
    })
  }
function validamobile(){
  var mobile = document.getElementById('mobile').value;
  var str = mobile; 
  var res = str.substring(0, 1);
  //document.getElementById("demo").innerHTML = res;
  if(res>5 && str.length == 10){
    // alert(mobile);
    $.ajax({
      type: "POST",
      url: "mobile.php",
      data:{
        signup:1,
        mobile:mobile,
      },        
      success: function(data1){
        console.log(data1)
        if(data1 == 'send'){
          alert('Otp Send Successfully');
        }else{
          alert("Your Mobile is already Registered please SignIn.....");
          window.location = 'login.php';
        }
      }
    });
  }else {
    alert('Please enter valid mobile no.');
    document.getElementById('mobile').value='';
    document.getElementById('mobile').focus();
  }
}
document.querySelector("#signupForm").addEventListener("submit",validateOtp);
function validateOtp(e){
  e.preventDefault()
  var otp = document.getElementById('otp').value;
  $.ajax({
      type: "POST",
      url: "mobile.php",
      data:{
        validateOtp:1,
        otp: otp
      },
      success: function(data){
        if(data=='false'){
          alert('Please enter correct otp..');
          document.getElementById('otp').value='';
          document.getElementById('otp').focus();
        }else if(data == 'verify'){
          document.querySelector("#signupForm").removeEventListener("submit",validateOtp);
          formSubmit();
          return false;
        }
      }
    });
}
function formSubmit(){
  $("#signupForm").submit();
}
</script>
</html>