<?php

 include('dbconnect.php');

$my_cat_id=$_REQUEST['my_cat_id'];
 

 


  
  $master_cat=mysqli_query($con_sup,"select * from category_master where cat_id='$my_cat_id'");
  $myimg=mysqli_fetch_array($master_cat);
  $banner=strtolower($myimg['banner']);
     $banner_name=$myimg['cat_name'];

 ?>

<!doctype html>
 <html lang="en-US"> 
<!-- Mirrored from www.Vedgun.com/c/groceries/fruits-vegetables/fresh-fruits/220 by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 30 Nov 2020 05:09:24 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head> <title>Fresh Fruits - Vedgun</title> <meta charset="utf-8"> <meta name="robots" content="INDEX,FOLLOW"> <meta name="description" content="Buy Grocery Online in Mumbai, Pune, Bangalore at Vedgun online grocery store. Best price on fresh fruits &amp; vegetables, dairy &amp; bakery, packaged food." /> <meta name="keywords" content="" /> <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"> <meta property="og:site_name" content="Vedgun" /> <meta property="og:type" content="website" /> <meta property="og:title" content="Fresh Fruits - Vedgun" /> <meta property="og:description" content="Buy Grocery Online in Mumbai, Pune, Bangalore at Reliance Smart online grocery store. Best price on fresh fruits & vegetables, dairy & bakery, packaged food." /> <meta property="og:url" content="220.php" /> <meta property="og:image" content="../../../../assets/global/logo-fb.png" /> <!-- Appple Touch Icons --> <link rel="apple-touch-icon" sizes="48x48" href="../../../../assets/global/new_toch_Vedgun_icon/apple-touch-icon-48x48.png"> <link rel="apple-touch-icon" sizes="72x72" href="../../../../assets/global/new_toch_Vedgun_icon/apple-touch-icon-72x72.png"> <link rel="apple-touch-icon" sizes="128x128" href="../../../../assets/global/new_toch_Vedgun_icon/apple-touch-icon-128x128.png"> <link rel="apple-touch-icon" sizes="256x256" href="../../../../assets/global/new_toch_Vedgun_icon/apple-touch-icon-256x256.png"> <link rel="apple-touch-icon" href="../../../../assets/global/new_toch_Vedgun_icon/apple-touch-icon-48x48.png"> <meta name="google-play-app" content="app-id=com.jpl.Vedgun"> <meta name="apple-itunes-app" content="app-id=1522085683"> <meta name="theme-color" content="#ffffff"/> 

<?php include('include/files.php');?>
    <style> .multi-srch-hide{ display:none !important; } .ais-InfiniteHits-loadMore{ display:none; } .gift-page #saved_location{ display:none; } </style> <link rel="manifest" href="../../../../manifest.json"> <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
		new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
		j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
		'../../../../../www.googletagmanager.com/gtm5445.php?id='+i+dl;f.parentNode.insertBefore(j,f);
		})(window,document,'script','dataLayer','GTM-NQLHTD8');</script> <style> .otc-product-page #first_desc h2 {display: none} .otc-product-page #first_desc h2.pname{display: block!important;}.catalog-category-view.level-3 .white-bg.msite-list, .catalog-category-view.level-0 .white-bg.msite-list{display:none !important} .cat-fashion .right-block .empty_listing {position:absolute;z-index:3} .compare_products{ display:none; }#bought_together{display:none !important}.prod-groceries #similar_products{display: none;} .prod-groceries .section-seperate1{display: none;} .prod-fashion .new_product #product_details #left_col .gallery-top,.prod-groceries .new_product #product_details #left_col .gallery-top{height: auto;} .gift-page .all-product .row product-list .col-md-3:last-child .price-box{display:none} .gift-page #free_gift_wrap{display:none !important} .best_deals .add_banner {margin: 0 auto;text-align: center;} .best_deals .add_banner img {width: auto;height: 100%;border-radius: 0;} .best_deals .section-seperate{display: none;} .prod-jewellery .brand_name{display:none !important} .prod-jewellery .prepaid_msg{display:block;font-size:14px;color:#dd0608;font-family: sans-serif;} .aa-dropdown-menu .aa-suggestions .aa-suggestion .product-item-info.search-jewellery a .drug_img { background: url(../../../../assets/version1605113383/smartweb/images/search_icons/search_jewellery.png) center no-repeat; background-size: 40px; }.drug-list-page .right-block .white-bg .all-product .product-list .cat-item .price-box strike {
    text-decoration: line-through;
    padding-right: 4px;
    color: #000;
} </style> <script>
        window.default_pin = '400020';
        window.algolia_filter = false;
        window.algolia_app_id = "3YP0HP3WSH";
        window.algolia_api_key = "aace3f18430a49e185d2c1111602e4b1";
        //window.algolia_index_name = "";
        window.algolia_suffix = 'prod_mart';
                window.product_image_path = "../../../../index.php";
                window.location_api = "AIzaSyBfquJmLRraJi0sNjV14BQWqGlMAEzqAIw";
        window.default_vertical_city_code = JSON.parse('{"ELECTRONICS": "null","FASHION": null,"GROCERIES": "6221", "JEWELLERY": "PANINDIAJEWEL"}');
        window.inventory_store_code = JSON.parse('{"GROCERIES":["6210"],"FASHION":null,"ELECTRONICS":null}');
    </script> </head> <body class="otc-category-page catalog-category-view cat-groceries level-3"> <noscript><iframe src="https://www.googletagmanager.com/ns.php?id=GTM-NQLHTD8" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript> <div class="page-wrapper"> <div class="top-section">
        <?php include('include/header.php');?>

       </div> </div> <main id="maincontent" class="main-section full-width"> <div class="breadcrumbs d-none d-sm-block"> <ul class="items"> <li class="home"> <a href="index.php" title="Go to Home"> Home </a> </li> <li class="home"> <a href="all-category.php" title="Go to All Categories"> All Categories </a> </li>

        <li class="home"> <a href="#" title="Go to Groceries"> <?php echo $sub_cat_name;?></a> </li>

         </ul> </div> 
        <div class="content-section drug-list-page"> <input type="hidden" name="page_type" id="page_type" value="category" /> <input type="hidden" name="child_cats" id="child_cats" value="Mangoes,Others,Apples,Banana,Chiku (Sapota),Citrus Fruits,Guava,Melons,Papaya,Pears,Plums,Pomegranate,Apples & Pomegranate,Apple,Brinjal,Vegetable Others,Kiwi" /> <input type="hidden" name="cat_id" id="curr_cat_id" value="220" /> <div class="left-block"> <!-- left side Section -->
         <div class="white-bg"> <h1> Categories </h1>
          <ul class="cat-menu">
             <?php 
$data=mysqli_query($con_sup,"select * from item_master  where sup_company_id='$sup_companyid' and delete_data='0' group by sup_category_name order by cat_id");
                 while($row=mysqli_fetch_array($data)){
                  $category_name=$row['sup_category_name'];
                    $category_id=$row['sup_category_id'];
        ?> 
           <li> <a class="cat-submenu " onclick="slideDropdown('custdp11<?php echo $category_id;?>');"><?php echo $category_name;?></a>
               <ul class="inner" id='custdp11<?php echo $category_id;?>'>
               <?php 
  // echo "select * from  item_master where sup_category_id='$category_id' and sup_company_id='2' and publish_status='1' order by item_id";
  // die;
               $data_cat=mysqli_query($con_sup,"select * from  item_master where sup_category_id='$category_id' and sup_company_id='2' and publish_status='1' order by item_id");
                 while($row_cat=mysqli_fetch_array($data_cat)){
                  $item_name=$row_cat['cat_name'];
                   
                ?>
                <li> <a class="cat-submenu-level1 active" href="220.php?sub_cat=<?php echo $item_name;?>"><?php echo $item_name;?></a> </li> 
              <?php } ?>
             </ul>
           </li>
         <?php } ?>
        </ul> 
         </li> 
       </ul> 
     </div> <div class="white-bg"> <div class="filter"> <h1 class="filter-title"> Filters </h1> <div id="algolia_filter"> <div class="filter-option-title"> <h2>Availability</h2> </div> <div class="layer-scroll" id="stock_filter"></div> <div class="filter-option-title"> <h2>Categories</h2> </div> <div class="layer-scroll" id="category_filter"></div> <div class="filter-option-title"> <h2>Brands</h2> </div>
                       <div class="layer-scroll" id="brand_filter"></div> <div class="filter-option-title"> <h2>Price</h2> </div> <div class="layer-scroll" id="avg_selling_price_filter"></div> <div class="filter-option-title"> <h2>Discount</h2> </div> <div class="layer-scroll" id="avg_discount_pct_filter"></div> </div> </div> </div> </div> 
          
                       <div class="right-block">
                       
                        <div class="category-main-banner"> 
                          <img src="<?php echo $imglink_cat.$banner;?>" title='<?php echo $banner_name;?>' alt="<?php echo $banner_name;?>"> 
                        </div>
                       <!--  <div class="category-main-banner"> <img src="../../../../images/category/220/fresh-fruits-20200704.jpg" alt="Fresh Fruits" /> </div>  -->
                        <div class="refinements"> <span id="clear_refinements"></span> <span id="current_refinements"></span> </div> <div class="clearfix"></div> <div id="product_wrapper"> <input type="hidden" name="product_count" id="product_count" value="16" />


                          <div id="mstar_box"> <div class="white-bg box-padding"> <div class="all-product"> <h2>ALL PRODUCTS</span></h2> <div class="row product-list">
                        
                        <?php

						$data_sub_qu=mysqli_query($con_sup,"select * from item_master where cat_id='$my_cat_id' and publish_status='1' and delete_data='0' group by sup_category_name  order by item_id desc");
						while($row_sub=mysqli_fetch_array($data_sub_qu)){
              $item_id=$row_sub['item_id'];
    					$sub_item=$row_sub['item_name'];
							$sub_item_mrp=$row_sub['mrp'];
							$sub_item_offer=$row_sub['offer_price'];
              $sav=$sub_item_mrp-$sub_item_offer;
              $com_id=$row_sub['sup_company_id'];
							$sub_item_image=strtolower($row_sub['image1']);

              if($sub_item_offer!='' && $sub_item_offer!='0'){
                $final_price = $sub_item_offer;
                $pro_del_save = $sub_item_mrp - $sub_item_offer;
              }else{
                $final_price = $sub_item_mrp;
              }
							 ?>
                        <div class="col-md-3 p-0"> 
                        <div class="cat-item "> 
                        <a class="category_name" href="pro_details.php?pro_name=<?php echo $sub_item; ?>" title="<?php echo $sub_item;?>">
                          <?php 
                            if($sub_item_image!='' && $sub_item_image!='0' && !(file_exists($imglink.'comp'.$sup_companyid.'/'.'item_image'.'/'.$sub_item_image))){
                          ?> 
                         <span class="cat-img">
                          <img class="product-image-photo" src="<?php echo $imglink.'comp'.$sup_companyid.'/'.'item_image'.'/'.$sub_item_image; ?>" alt="<?php echo $sub_item;?>">
                          </span>
                        <?php } ?>
                        <span class="clsgetname"><?php echo $sub_item;?></span>
                        </a> 
                         <span class="drug-varients ellipsis"></span> <div class="clearfix"></div> <span class="price-box">
                  
                          <?php if($sub_item_offer!='' && $sub_item_offer!='0'){ ?>

                          <strike id="price"><i class="fa fa-rupee-sign"></i> <?php echo $sub_item_mrp;?>.00 </strike>
                       <?php }else{?>
                         <i class="fa fa-rupee-sign"></i> <?php echo $sub_item_mrp;?>.00
                       <?php } ?>
                       <?php if($sub_item_offer!='' && $sub_item_offer!='0'){?>
                          <span id="final_price">&#8377; <?php echo $sub_item_offer;?>.00</span>
                           <span class="save_price">Save &#8377; <?php echo $sav;?>.00</span>
                       <?php }?>
                            <div class="cart_btn">
                              <button data-name="<?php echo $sub_item;?>" data-price="<?php echo $final_price;?>" data-discount="<?php echo $pro_del_save;?>" data-id='<?php echo $item_id ?>' data-image='<?php echo $sub_item_image ?>' class="add-to-cart btn btn-primary">Add to Basket</button>
                            </div> <div class="clearfix"></div> </div> </div> 
                        <?php } ?>
                  
                        <div class="clearfix"></div> <div class="clearfix"></div> </div> </div> </div> </div> <div class="white-bg" id="algolia_box" style="display:none;"> <div class="all-product"> <h2>ALL PRODUCTS</span></h2> <div class="product-list"> <div id="algolia_hits"> </div> </div> </div> </div> </div> </div> <div class="clearfix"></div> </div></main> 


           <?php include('include/footer.php');?>
             <!-- Copyright Section -->  </div> <div class="modal fade" id="rel_pincode_popup" data-easein="slideUpBigIn" tabindex="-1" role="dialog"> <div class="modal-dialog" role="document"> <div class="modal-content"> <div class="modal-header"> <h5 class="modal-title"><span>Happiness</span> Home Delivered...</h5> <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button></div> <div class="clearfix"></div> <div id="delivery_details"> <form id="rel_pincode_form"> <div class="lblock"> <label>Where do you want us to deliver your grocery?</label> <input type="text" class="inp_text" name="rel_pincode" id="rel_pincode" placeholder="Enter your Pincode" autocomplete="off" maxlength="6" /> <div id="rel_pin_msg"></div> <button type="submit" class="shopping_btn">Start Shopping</button> </div> <div class="rblock"> <img src="../../../../assets/smartweb/images/delivery_popup_jio.png" alt="Vedgun, Online Groceries Shop"> </div> <div class="clearfix"></div> </form> </div> </div> </div> </div>
             <?php include('include/myscript.php');?> 
              </body> 
<script type="text/javascript">
      function slideDropdown(id){
  $('#'+id).slideToggle();
}

  </script>
<!-- Mirrored from www.Vedgun.com/c/groceries/fruits-vegetables/fresh-fruits/220 by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 30 Nov 2020 05:09:35 GMT -->
</html>