<?php 

session_start();
if ($_REQUEST['otp'] == $_SESSION['onlineotp']) {

} else {
	echo "false";
}



?>