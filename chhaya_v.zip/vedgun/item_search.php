<?php 
include('dbconnect.php');
//print_r($_POST);
if(isset($_POST['item'])){
    $search_id=$_REQUEST['item'];
  	$search_item= array();
    $data_item=mysqli_query($con_sup,'select * from item_master where item_name Like "%'.$search_id.'%"');
    while($data_row=mysqli_fetch_array($data_item)){
    	$search_item[]=$data_row;
 //echo $data_row['item_name'];
    }
   echo json_encode($search_item);

   }
?>