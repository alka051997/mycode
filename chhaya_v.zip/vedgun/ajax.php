<?php
include("dbconnect.php");
$invoice_date=date('Y-m-d');

function genNDigitCode($joinchar, $id, $num){
	$digit = strlen($id);
	$zeronum = "";
	for($i=$digit; $i<$num;  $i++)
	$zeronum .= "0";
	return $joinchar . $zeronum . $id;
}

if(isset($_POST['getCity'])){
	$state = $_POST['state'];
	$result = array();
    $rs=mysqli_query($con,"SELECT city from pin_code where state='$state' group by city order by city asc ");
    while($row = mysqli_fetch_assoc($rs)){
		$result[] = $row['city'];
    }
    echo json_encode($result);
}
if(isset($_POST['getPincode'])){
	$city = $_POST['city'];
	$result = array();
    $rs=mysqli_query($con,"SELECT pin_code from pin_code where city='$city' group by pin_code order by pin_code asc ");
    while($row = mysqli_fetch_assoc($rs)){
		$result[] = $row['pin_code'];
    }
    echo json_encode($result);
}
if(isset($_POST['getDistrict'])){
	$pin_code = $_POST['pin_code'];
	$result = array();
    $rs=mysqli_query($con,"SELECT district from pin_code where pin_code='$pin_code' group by district order by district asc ");
    while($row = mysqli_fetch_assoc($rs)){
		$result[] = $row['district'];
    }
    echo json_encode($result);
}

if(isset($_POST['shoppingCartData'])){
	// generate voucher
	$voucher_type = 'SALE';
	$v_row = mysqli_fetch_assoc(mysqli_query($con,"SELECT `series_start`,`session_end`,`prefix` FROM ac_voucher_series WHERE voucher_type='$voucher_type' and company_id = '$company_id' "));
	$v_series = $v_row['series_start'];
	$voucher_sess_setting = $v_row['session_end'];
	$prefix1 = $v_row['prefix'];
	$v_series_digit = strlen($v_series);
	if($v_series_digit == 0){
		$v_series_digit = 3;
	}
	$id = $v_series;
	if($id == 0){
	  $id=1;
	}
	if($voucher_sess_setting == 1){
	  $prefix = $prefix1.'/'.$sessYear.'/';
	}
	else{
	  $prefix = $prefix1;
	}
	$invoice_no =  genNDigitCode($prefix, $id, $v_series_digit);

	$shoppingCartData = $_POST['shoppingCartData'];
	// print_r($_POST);
	$address = $_POST['address'];
	$pin_code = $_POST['pin_code'];
	$city = $_POST['city'];
	$district = $_POST['district'];
	$state = $_POST['state'];
	$payment_method = $_POST['payment_method'];
	$sub_total = $_POST['sub_total'];
	$vedgun_money = $_POST['vedgun_money'];
	// insert into order_details table
    $ins_order = "INSERT INTO order_details(`invoice_to`, `invoice_to_id`,`invoice_no`, `invoice_date`,`remarks`, `state`, `city`, `pin_code`, `district`, `address`, `create_date`, `create_by`,`company_id`, `company_name`, `sub_total`, `frieght_charge`, `other_charge`, `session`) VALUES ('".$username."', '".$userid."','".$invoice_no."', '".$invoice_date."','".$payment_method."', '".$state."', '".$city."', '".$pin_code."', '".$district."', '".$address."', '".$createdate."', '".$create_by."', '".$company_id."', '".$company_name."', '".$sub_total."', '".$frieght_charge."', '".$other_charge."', '".$sessYear."') ";
    $res = mysqli_query($con,$ins_order);
    $inserted_id = mysqli_insert_id($con);
	// insert into order_product_list
	// print_r($_POST);die;
	if($res){
		foreach ($shoppingCartData as $data) {
			$p_desc = $data['name'];
			$p_desc_id = $data['id'];
			$p_qty = $data['count'];
			$p_rate = $data['price'];
			$p_act_rate = (float) $data['price'] + (float) $data['discount'] ;
			$p_amt = (float) $data['price'] * $p_qty;
			$p_net_amt = $_POST['p_net_amt'][$key];
	  		$products_all = "INSERT INTO order_product_list(`order_v_id`,`invoice_no`, `invoice_date`,`invoice_to`, `invoice_to_id`, `p_desc`, `p_desc_id`, `p_act_rate`,`p_rate`, `p_qty`,`p_amt`,`sub_total`,`create_by`, `create_date`, `session`) VALUES ('".$inserted_id ."','".$invoice_no ."', '".$invoice_date ."', '".$username."', '".$userid."', '".$p_desc ."','".$p_desc_id."', '".$p_act_rate ."', '".$p_rate ."', '".$p_qty ."', '".$p_amt ."', '".$sub_total ."', '".$userid ."', '".$createdate ."', '".$sessYear."')";
	        $products_all_run = mysqli_query($con, $products_all);
		}
		// update series
		$new_series = (int)$v_series+1;
		mysqli_query($con,"UPDATE ac_voucher_series SET `series_start` = '".$new_series."' WHERE voucher_type='$voucher_type' and company_id = '$company_id' ");
		// INSERT VEDGUN MONEY AS JOURNAL VOUCHER
		if($vedgun_money!=''){
			$voucher_type = "JOUR";
			// generate voucher
			$v_row = mysqli_fetch_assoc(mysqli_query($con,"SELECT `series_start`,`session_end`,`prefix` FROM ac_voucher_series WHERE voucher_type='$voucher_type' and company_id = '$company_id' "));
			$v_series = $v_row['series_start'];
			$voucher_sess_setting = $v_row['session_end'];
			$prefix1 = $v_row['prefix'];
			$v_series_digit = strlen($v_series);
			if($v_series_digit == 0){
				$v_series_digit = 3;
			}
			$id = $v_series;
			if($id == 0){
			  $id=1;
			}
			if($voucher_sess_setting == 1){
			  $prefix = $prefix1.'/'.$sessYear.'/';
			}
			else{
			  $prefix = $prefix1;
			}
			$voucher_no =  genNDigitCode($prefix, $id, $v_series_digit);

			$ins_qur = "INSERT INTO ac_journal_voucher(`voucher_no`, `refrence_no`, `voucher_date`, `voucher_type`, `ledger_id`, `ledger_name`, `amount`, `dr_amt`, `cr_amt`, `narration`, `created_by`, `createdate`,`company_id`,`company_name`, `party_id`, `party_name`,session) VALUES ('$voucher_no', '$invoice_no', '$invoice_date', '$voucher_type', '$userid', '$username', '$vedgun_money', '0', '$vedgun_money', 'Vedgun Money', '$userid', '$createdate','$company_id','$company_name', '$userid', '$username','$sessYear')";
			$query_1 = mysqli_query($con, $ins_qur);
			if($query_1){
				// update series
				$new_series = (int)$v_series+1;
				mysqli_query($con,"UPDATE ac_voucher_series SET `series_start` = '".$new_series."' WHERE voucher_type='$voucher_type' and company_id = '$company_id' ");
			}
		}
		echo "ordered";
	}else{
		echo "failed";
	}

}
?>
