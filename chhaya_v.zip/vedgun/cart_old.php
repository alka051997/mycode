
<?php
 include('dbconnect.php');
 ?>
<!doctype html> <html lang="en-US"> 
<!-- Mirrored from www.Vedgun.com/terms-and-conditions by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 30 Nov 2020 05:35:21 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
  <title>Terms and Condition - Buy Grocery Online at Best Prices Pan India</title>
  <meta charset="utf-8"> <meta name="robots" content="INDEX,FOLLOW">
  <meta name="description" content="Find the Terms and Condition stated by Reliancesmart.in." />
  <meta name="keywords" content="" />
  <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
  <meta property="og:site_name" content="Vedgun" />
  <meta property="og:type" content="website" />
  <meta property="og:title" content="Terms and Condition - Buy Grocery Online at Best Prices Pan India" />
  <meta property="og:description" content="Find the Terms and Condition stated by Reliancesmart.in." />
  <meta property="og:url" content="terms-and-conditions.php" />
  <meta property="og:image" content="assets/global/logo-fb.png" /> <!-- Appple Touch Icons -->

 <?php include('include/files.php');?>
  <style>
    .multi-srch-hide{ display:none !important; } .ais-InfiniteHits-loadMore{ display:none; } .gift-page #saved_location{ display:none; }
  </style>
  <link rel="manifest" href="manifest.json">
  <!-- <script>
    (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
        new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
        j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
        '../www.googletagmanager.com/gtm5445.php?id='+i+dl;f.parentNode.insertBefore(j,f);
        })(window,document,'script','dataLayer','GTM-NQLHTD8');
  </script> -->
<style>
  .otc-product-page #first_desc h2 {display: none} .otc-product-page #first_desc h2.pname{display: block!important;}.catalog-category-view.level-3 .white-bg.msite-list, .catalog-category-view.level-0 .white-bg.msite-list{display:none !important} .cat-fashion .right-block .empty_listing {position:absolute;z-index:3} .compare_products{ display:none; }#bought_together{display:none !important}.prod-groceries #similar_products{display: none;} .prod-groceries .section-seperate1{display: none;} .prod-fashion .new_product #product_details #left_col .gallery-top,.prod-groceries .new_product #product_details #left_col .gallery-top{height: auto;} .gift-page .all-product .row product-list .col-md-3:last-child .price-box{display:none} .gift-page #free_gift_wrap{display:none !important} .best_deals .add_banner {margin: 0 auto;text-align: center;} .best_deals .add_banner img {width: auto;height: 100%;border-radius: 0;} .best_deals .section-seperate{display: none;} .prod-jewellery .brand_name{display:none !important} .prod-jewellery .prepaid_msg{display:block;font-size:14px;color:#dd0608;font-family: sans-serif;} .aa-dropdown-menu .aa-suggestions .aa-suggestion .product-item-info.search-jewellery a .drug_img { background: url(assets/version1605113383/smartweb/images/search_icons/search_jewellery.png) center no-repeat; background-size: 40px; }
  .point{
    padding-top: 20px;
  }
.point li{
    list-style-type: none;
    float: left;
    margin-right: 20px;
}
.line{
        height: 2px;
    background: #8ec63f;
    width: 100px;
    margin-top: 9px;
}
.input-group {
    position: relative;
    display: inline-flex !important;
    border-collapse: separate;
}
.ttr{

    background-color: #ececed;
    padding: 20px;

}
.totalamt-col{
  display: inline-block;
        background: #ececed;
    padding: 24px;
    width: 100%;
    margin-bottom: 16px;
    border-radius: 4px;
}
.mycart_head{
  font-family: sans-serif;
}
.btn.disabled, .btn[disabled], fieldset[disabled] .btn {
  opacity:1 !important;
}
</style>
</head> 
<body class="static-page cms-terms-and-conditions">
<div class="page-wrapper"> 
  <div class="top-section"> 
    <?php include('include/header.php');?> 
    <main id="maincontent" class=" static-content"> 
      <div class="breadcrumbs d-none d-sm-block">
        <ul class="items">
          <li class="home"> <a href="index.php" title="Go to Home"> Home </a> </li>
          <li class="home"> <span>Cart</span> </li>
        </ul>
      </div>
      <div class='col-md-12'>
        <div class='col-md-3'><h2 class="mycart_head">My Cart</h2></div>
        <div class='col-md-9'>
            <ul style=''class="point float-right">
              <li class="active">
                <span class="icon cart"></span>
                <span style="color: red" class="glyphicon glyphicon-shopping-cart"> Your Cart </span>
              </li>
              <li><p class="line"></p></li>
              <li class="">
                <span class="icon review"></span>
                <span class="glyphicon glyphicon-folder-close">&nbsp;Order Summary </span>
              </li>
              <li><p class="line"></p></li>
              <li class="">
                <span class="icon placeorder"></span>
                <span class="glyphicon glyphicon-folder-close">&nbsp;Payment </span>
              </li>
             <div class='clearfix'></div>
            </ul>
        </div>
        <div class='clearfix'></div>
      </div>
      <div class='clearfix'></div>
      <div class='col-md-12'>
        <div class='col-md-12' style="margin-top: 20px;">
          <div class='col-md-7 ttr'>
            <div class="proditem" style="">
              <div class="col-md-12">
              <div class="leftside-icons col-md-2">
                <a class="product-item-photo" href="p/groceries/aashirvaad-whole-wheat-atta-10-kg/490000041" title="Aashirvaad Whole Wheat Atta 10 kg">
                <img class="pro-img mylistimg" src="http://localhost:8080/i_audit/i_audit/upload/comp2/item_image/p16087866090452.jpg">
                </a>
              </div>
            

              <div class='clearfix'></div>
            </div>
            </div>

            <br>
          </div>
          <div class='col-md-5'>
            
            <div class="totalamt-col">
              <h4 class="paymentdetails-title" style="border-bottom: 2px solid #ffff;padding-bottom: 20px;">Payment Details</h4>
              <div class="allcalculation">
                <div class="subtoal" style="border-bottom: 2px solid #ffff;padding-bottom: 40px; padding-top: 10px;">
                  <div class='col-md-12'>
                    <div class='col-md-6'>
                  <label>MRP Total</label>
                </div>
                <div class='col-md-1'>
                  :
                </div>
                <div class='col-md-5'>
                  <span id="cart_sub_total"><i class="fa fa-rupee-sign"></i>1,430.00</span>
                </div>
                </div>
                </div><!----><!----><!----><!----><!---->
                <div class="discount cart-discount" style="border-bottom: 2px solid #ffff;padding-bottom: 40px;padding-top: 10px;">
                    <div class='col-md-12'>
                    <div class='col-md-6'>
                  <label>Product Discount</label>
                </div>
                <div class='col-md-1'>:</div>
                <div class='col-md-5'>
                  <span id="cart_total_disc1">- <i class="fa fa-rupee-sign"></i>182.50</span>
                </div>
              </div>
                </div><!---->
                <div class="net-amount" style="border-bottom: 2px solid #ffff;padding-bottom: 40px;padding-top: 10px;">
                  <div class='col-md-12'>
                    <div class='col-md-6'>
                  <label>Total Amount</label>
                </div>
                <div class='col-md-1'>:</div>
                <div class='col-md-5'>
                  <span id="cart_netpay_amt1"><i class="fa fa-rupee-sign"></i>1,247.50</span>
                </div>
                 </div>
                </div><!---->
                <div class="save-amount" style="margin-bottom: 40px;margin-top: 10px;">
                 <div class='col-md-12'>
                  <div class='col-md-6'>
                  <label>You Save </label>
                </div>
                <div class='col-md-1'>:</div>
                <div class='col-md-5'>
                  <span id="cart_savings"><i class="fa fa-rupee-sign"></i>182.50</span>
                </div>
                </div>
                </div>
                <br>
                <button class="btn-checkout btn btn-primary btn_to_checkout m-0" type="button" style="padding: 10px;margin-top: 20px;" disabled=""> Make Payment </button>
              </div><!----><!----><!---->
            </div>
          </div>
        </div>
      </div>
      <div class='clearfix'></div>
    </main>
    <?php include('include/footer.php');?>
  </div>
</body>
</html>