<link href="../page_css/pagination.css" rel="stylesheet" type="text/css" />
<center>
<div style="width:100%;" id="pagnnn">
<?php
$gettotal = mysqli_query($con,$sql);
?>
<!--<div style="font-size:14px; color:#06C; font-weight:bold">Total Records : <span style="color:#F30"><?php //echo mysqli_num_rows($gettotal); ?></span></div>-->
<?php
$page_query = $sql;	// Query
$maxlimit = 500;	  // How many rows show in a page

$page = 1;
if(isset($_REQUEST['page']))
$page = $_REQUEST['page'];
echo $cmn->startPagination($con,$page_query, $maxlimit);
$minlimit = 0;
if($page != 1)
$minlimit = ($page - 1) * $maxlimit;
$limit_of_query = " limit $minlimit,$maxlimit";	// Paste into your query //
?>
</div>
</center>