<?php
class Comman {

function send_mail_api($logo,$email,$name,$subject,$header,$content,$regards,$footer){
    $url = explode("/",ltrim($_SERVER["REQUEST_URI"],"/"));
    $src = "https://iaudit.net.in/".$url[0]."/".$logo;
    // echo "url = ".$src;
$msg = '<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html xmlns=\"http://www.w3.org/1999/xhtml\" xmlns:v=\"urn:schemas-microsoft-com:vml\" xmlns:o=\"urn:schemas-microsoft-com:office:office\"><head><meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\" /><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" /><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" /><meta name=\"x-apple-disable-message-reformatting\" /><meta name=\"apple-mobile-web-app-capable\" content=\"yes\" /><meta name=\"apple-mobile-web-app-status-bar-style\" content=\"black\" /><meta name=\"format-detection\" content=\"telephone=no\" /><title></title><style type=\"text/css\"> /* Resets */ .ReadMsgBody { width: 100%; background-color: #ebebeb;} .ExternalClass {width: 100%; background-color: #ebebeb;} .ExternalClass, .ExternalClass p, .ExternalClass span, .ExternalClass font, .ExternalClass td, .ExternalClass div {line-height:100%;} a[x-apple-data-detectors]{ color:inherit !important; text-decoration:none !important; font-size:inherit !important; font-family:inherit !important; font-weight:inherit !important; line-height:inherit !important; } body {-webkit-text-size-adjust:none; -ms-text-size-adjust:none;} body {margin:0; padding:0;} .yshortcuts a {border-bottom: none !important;} .rnb-del-min-width{ min-width: 0 !important; } /* Add new outlook css start */ .templateContainer{ max-width:590px !important; width:auto !important; } /* Add new outlook css end */ /* Image width by default for 3 columns */ img[class=\"rnb-col-3-img\"] { max-width:170px; } /* Image width by default for 2 columns */ img[class=\"rnb-col-2-img\"] { max-width:264px; } /* Image width by default for 2 columns aside small size */ img[class=\"rnb-col-2-img-side-xs\"] { max-width:180px; } /* Image width by default for 2 columns aside big size */ img[class=\"rnb-col-2-img-side-xl\"] { max-width:350px; } /* Image width by default for 1 column */ img[class=\"rnb-col-1-img\"] { max-width:550px;  } /* Image width by default for header */ img[class=\"rnb-header-img\"] { max-width:590px; } /* Ckeditor line-height spacing */ .rnb-force-col p, ul, ol{margin:0px!important;} .rnb-del-min-width p, ul, ol{margin:0px!important;} /* tmpl-2 preview */ .rnb-tmpl-width{ width:100%!important;} /* tmpl-11 preview */ .rnb-social-width{padding-right:15px!important;} /* tmpl-11 preview */ .rnb-social-align{float:right!important;} /* Ul Li outlook extra spacing fix */ li{mso-margin-top-alt: 0; mso-margin-bottom-alt: 0;} /* Outlook fix */ table {mso-table-lspace:0pt; mso-table-rspace:0pt;} /* Outlook fix */ table, tr, td {border-collapse: collapse;} /* Outlook fix */ p,a,li,blockquote {mso-line-height-rule:exactly;} /* Outlook fix */ .msib-right-img { mso-padding-alt: 0 !important;} @media only screen and (min-width:590px){ /* mac fix width */ .templateContainer{width:590px !important;} } @media screen and (max-width: 360px){ /* yahoo app fix width \"tmpl-2 tmpl-10 tmpl-13\" in android devices */ .rnb-yahoo-width{ width:360px !important;} } @media screen and (max-width: 380px){ /* fix width and font size \"tmpl-4 tmpl-6\" in mobile preview */ .element-img-text{ font-size:24px !important;} .element-img-text2{ width:230px !important;} .content-img-text-tmpl-6{ font-size:24px !important;} .content-img-text2-tmpl-6{ width:220px !important;} } @media screen and (max-width: 480px) { td[class=\"rnb-container-padding\"] { padding-left: 10px !important; padding-right: 10px !important; } /* force container nav to (horizontal) blocks */ td.rnb-force-nav { display: inherit; } /* fix text alignment \"tmpl-11\" in mobile preview */ .rnb-social-text-left { width: 100%; text-align: center; margin-bottom: 15px; } .rnb-social-text-right { width: 100%; text-align: center; } } @media only screen and (max-width: 600px) { /* center the address &amp; social icons */ .rnb-text-center {text-align:center !important;} /* force container columns to (horizontal) blocks */ th.rnb-force-col { display: block; padding-right: 0 !important; padding-left: 0 !important; width:100%; } table.rnb-container { width: 100% !important; } table.rnb-btn-col-content { width: 100% !important; } table.rnb-col-3 { /* unset table align=\"left/right\" */ float: none !important; width: 100% !important; /* change left/right padding and margins to top/bottom ones */ margin-bottom: 10px; padding-bottom: 10px; /*border-bottom: 1px solid #eee;*/ } table.rnb-last-col-3 { /* unset table align=\"left/right\" */ float: none !important; width: 100% !important; } table.rnb-col-2 { /* unset table align=\"left/right\" */ float: none !important; width: 100% !important; /* change left/right padding and margins to top/bottom ones */ margin-bottom: 10px; padding-bottom: 10px; /*border-bottom: 1px solid #eee;*/ } table.rnb-col-2-noborder-onright { /* unset table align=\"left/right\" */ float: none !important; width: 100% !important; /* change left/right padding and margins to top/bottom ones */ margin-bottom: 10px; padding-bottom: 10px; } table.rnb-col-2-noborder-onleft { /* unset table align=\"left/right\" */ float: none !important; width: 100% !important; /* change left/right padding and margins to top/bottom ones */ margin-top: 10px; padding-top: 10px; } table.rnb-last-col-2 { /* unset table align=\"left/right\" */ float: none !important; width: 100% !important; } table.rnb-col-1 { /* unset table align=\"left/right\" */ float: none !important; width: 100% !important; } img.rnb-col-3-img { /**max-width:none !important;**/ width:100% !important; } img.rnb-col-2-img { /**max-width:none !important;**/ width:100% !important; } img.rnb-col-2-img-side-xs { /**max-width:none !important;**/ width:100% !important; } img.rnb-col-2-img-side-xl { /**max-width:none !important;**/ width:100% !important; } img.rnb-col-1-img { /**max-width:none !important;**/ width:100% !important; } img.rnb-header-img { /**max-width:none !important;**/ width:100% !important; margin:0 auto; } img.rnb-logo-img { /**max-width:none !important;**/ width:100% !important; } td.rnb-mbl-float-none { float:inherit !important; } .img-block-center{text-align:center !important;} .logo-img-center { float:inherit !important; } /* tmpl-11 preview */ .rnb-social-align{margin:0 auto !important; float:inherit !important;} /* tmpl-11 preview */ .rnb-social-center{display:inline-block;} /* tmpl-11 preview */ .social-text-spacing{margin-bottom:0px !important; padding-bottom:0px !important;} /* tmpl-11 preview */ .social-text-spacing2{padding-top:15px !important;} /* UL bullet fixed in outlook */ ul {mso-special-format:bullet;} }</style><!--[if gte mso 11]><style type=\"text/css\">table{border-spacing: 0; }table td {border-collapse: separate;}</style><![endif]--><!--[if !mso]><!--><style type=\"text/css\">table{border-spacing: 0;} table td {border-collapse: collapse;}</style> <!--<![endif]--><!--[if gte mso 15]><xml><o:OfficeDocumentSettings><o:AllowPNG/><o:PixelsPerInch>96</o:PixelsPerInch></o:OfficeDocumentSettings></xml><![endif]--><!--[if gte mso 9]><xml><o:OfficeDocumentSettings><o:AllowPNG/><o:PixelsPerInch>96</o:PixelsPerInch></o:OfficeDocumentSettings></xml><![endif]--></head><body>  <table border=\"0\" align=\"center\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" class=\"main-template\" bgcolor=\"#ffffff\" style=\"background-color: rgb(255, 255, 255);\"><tbody><tr><td align=\"center\" valign=\"top\"><!--[if gte mso 9]><table align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"590\" style=\"width:590px;\"><tr><td align=\"center\" valign=\"top\" width=\"590\" style=\"width:590px;\"><![endif]--><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"590\" class=\"templateContainer\" style=\"max-width:590px!important; width: 590px;\"><tbody><tr><td align=\"center\" valign=\"top\"><div style=\"background-color: rgb(15, 123, 184);\"><table class=\"rnb-del-min-width rnb-tmpl-width\" width=\"100%\" cellpadding=\"0\" border=\"0\" cellspacing=\"0\" style=\"min-width:590px;\" name=\"Layout_17\" id=\"Layout_17\"><tbody><tr><td class=\"rnb-del-min-width\" align=\"center\" valign=\"top\" style=\"min-width:590px;\"><a href=\"#\" name=\"Layout_17\"></a><table width=\"100%\" cellpadding=\"0\" border=\"0\" align=\"center\" cellspacing=\"0\"  bgcolor=\"#0f7bb8\" style=\"padding-right: 20px; padding-left: 20px; background-color: rgb(15, 123, 184);\"><tbody><tr><td height=\"20\" style=\"font-size:1px; line-height:20px; mso-hide: all;\">&nbsp;</td></tr><tr><td style=\"font-size:14px; color:#888888; font-weight:normal; text-align:center; font-family:Arial,Helvetica,sans-serif;\"><div></div></td></tr><tr><td height=\"20\" style=\"font-size:1px; line-height:20px; mso-hide: all;\">&nbsp;</td></tr></tbody></table></td></tr></tbody></table></div></td></tr><tr><td align=\"center\" valign=\"top\">              <div style=\"background-color: rgb(255, 255, 255); border-radius: 10px;\"><!--[if mso]><table align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\" style=\"width:100%;\">                 <tr>                 <![endif]-->                                  <!--[if mso]>                 <td valign=\"top\" width=\"590\" style=\"width:590px;\">                 <![endif]-->                 <table class=\"rnb-del-min-width\" width=\"100%\" cellpadding=\"0\" border=\"0\" cellspacing=\"0\" style=\"min-width:590px;\" name=\"Layout_1\" id=\"Layout_1\">                 <tbody><tr>                     <td class=\"rnb-del-min-width\" align=\"center\" valign=\"top\" style=\"min-width:590px;\">                         <a href=\"#\" name=\"Layout_1\"></a>                         <table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" class=\"rnb-container\" bgcolor=\"#ffffff\" style=\"background-color: rgb(255, 255, 255); border-radius: 10px; padding-left: 20px; padding-right: 20px; border-collapse: separate;\">                             <tbody><tr>                                 <td height=\"20\" style=\"font-size:1px; line-height:20px; mso-hide: all;\">&nbsp;</td>                             </tr>                             <tr>                                 <td valign=\"top\" class=\"rnb-container-padding\" align=\"left\">                                     <table width=\"100%\" cellpadding=\"0\" border=\"0\" align=\"center\" cellspacing=\"0\"><tbody><tr><td valign=\"top\" align=\"center\">                                                 <table cellpadding=\"0\" border=\"0\" align=\"center\" cellspacing=\"0\" class=\"logo-img-center\"><tbody><tr><td valign=\"middle\" align=\"center\" style=\"line-height: 1px;\"><div style=\"border-top:0px None #000;border-right:0px None #000;border-bottom:0px None #000;border-left:0px None #000;display:inline-block; \" cellspacing=\"0\" cellpadding=\"0\" border=\"0\"><div><img width=\"252\" vspace=\"0\" hspace=\"0\" border=\"0\" alt=\"iAudit\" style=\"float: left;max-width:252px;display:block;\" class=\"rnb-logo-img\" src=\"'.$src.'\" ></div></div></td>                                                     </tr>                                                 </tbody></table>                                                 </td>                                         </tr>                                     </tbody></table></td>                             </tr>                             <tr>                                 <td height=\"20\" style=\"font-size:1px; line-height:20px; mso-hide: all;\">&nbsp;</td>                             </tr>                         </tbody></table>                     </td>                 </tr>             </tbody></table>             <!--[if mso]>                 </td>                 <![endif]-->                                  <!--[if mso]>                 </tr>                 </table>                 <![endif]-->                      </div></td>     </tr><tr>          <td align=\"center\" valign=\"top\">              <div style=\"background-color: rgb(255, 255, 255); border-radius: 0px;\">                                  <!--[if mso]>                 <table align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\" style=\"width:100%;\">                 <tr>                 <![endif]-->                                  <!--[if mso]>                 <td valign=\"top\" width=\"590\" style=\"width:590px;\">                 <![endif]-->                              <table width=\"100%\" cellpadding=\"0\" border=\"0\" cellspacing=\"0\" name=\"Layout_12\" id=\"Layout_12\"><tbody><tr>                     <td align=\"center\" valign=\"top\"><a href=\"#\" name=\"Layout_12\"></a>                         <table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" class=\"rnb-container\" bgcolor=\"#ffffff\" style=\"height: 0px; background-color: rgb(255, 255, 255); border-radius: 0px; border-collapse: separate; padding-left: 20px; padding-right: 20px;\"><tbody><tr>                                 <td class=\"rnb-container-padding\" style=\"font-size: px;font-family: ; color: ;\">                                      <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" class=\"rnb-columns-container\" align=\"center\" style=\"margin:auto;\">                                         <tbody><tr>                                              <th class=\"rnb-force-col\" align=\"center\" style=\"text-align: center; font-weight: normal\">                                                  <table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"center\" class=\"rnb-col-1\">                                                      <tbody><tr>                                                         <td height=\"10\"></td>                                                     </tr>                                                      <tr>                                                         <td style=\"font-family:Arial,Helvetica,sans-serif; color:#3c4858; text-align:center;\">                                                              <span style=\"color:#3c4858;\"><span style=\"font-size: 24px;\"><b>'.$header.'</b></span></span>                                                         </td>                                                     </tr>                                                     <tr>                                                         <td height=\"10\"></td>                                                     </tr>                                                     </tbody></table>                                                 </th></tr>                                     </tbody></table></td>                             </tr>                          </tbody></table>                      </td>                 </tr>              </tbody></table><!--[if mso]>                 </td>                 <![endif]-->                                  <!--[if mso]>                 </tr>                 </table>                 <![endif]-->                      </div></td>     </tr><tr>          <td align=\"center\" valign=\"top\">              <div style=\"background-color: rgb(255, 255, 255); border-radius: 0px;\">                              <!--[if mso]>                 <table align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\" style=\"width:100%;\">                 <tr>                 <![endif]-->                                  <!--[if mso]>                 <td valign=\"top\" width=\"590\" style=\"width:590px;\">                 <![endif]-->                 <table class=\"rnb-del-min-width\" width=\"100%\" cellpadding=\"0\" border=\"0\" cellspacing=\"0\" style=\"min-width:100%;\" name=\"Layout_14\">                 <tbody><tr>                     <td class=\"rnb-del-min-width\" align=\"center\" valign=\"top\">                         <a href=\"#\" name=\"Layout_14\"></a>                         <table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" class=\"rnb-container\" bgcolor=\"#ffffff\" style=\"background-color: rgb(255, 255, 255); padding-left: 20px; padding-right: 20px; border-collapse: separate; border-radius: 0px; border-bottom: 0px none rgb(200, 200, 200);\">                                          <tbody><tr>                                             <td height=\"20\" style=\"font-size:1px; line-height:20px; mso-hide: all;\">&nbsp;</td>                                         </tr>                                         <tr>                                             <td valign=\"top\" class=\"rnb-container-padding\" align=\"left\">                                                  <table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" class=\"rnb-columns-container\">                                                     <tbody><tr>                                                         <th class=\"rnb-force-col\" style=\"text-align: left; font-weight: normal; padding-right: 0px;\" valign=\"top\">                                                              <table border=\"0\" valign=\"top\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\" align=\"left\" class=\"rnb-col-1\">                                                                  <tbody><tr>                                                                     <td style=\"font-size:14px; font-family:Arial,Helvetica,sans-serif, sans-serif; color:#3c4858;\"><div style=\"text-align: justify;\"><span style=\"font-size:16px;\">'.$content.'</span></div> </td></tr></tbody></table></th></tr></tbody></table></td></tr><tr><td height=\"20\" style=\"font-size:1px; line-height:20px; mso-hide: all;\">&nbsp;</td></tr>                                     </tbody></table>                     </td>                 </tr>             </tbody></table><!--[if mso]>                 </td>                 <![endif]-->                                  <!--[if mso]>                 </tr>                 </table>                 <![endif]-->              </div></td>     </tr><tr>          <td align=\"center\" valign=\"top\">              <div style=\"background-color: rgb(255, 255, 255); border-radius: 0px;\">                                  <!--[if mso]>                 <table align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\" style=\"width:100%;\">                 <tr>                 <![endif]-->                                  <!--[if mso]>                 <td valign=\"top\" width=\"590\" style=\"width:590px;\">                 <![endif]-->                              <table width=\"100%\" cellpadding=\"0\" border=\"0\" cellspacing=\"0\" name=\"Layout_15\" id=\"Layout_15\"><tbody><tr>                     <td align=\"center\" valign=\"top\"><a href=\"#\" name=\"Layout_15\"></a>                         <table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" class=\"rnb-container\" bgcolor=\"#ffffff\" style=\"height: 0px; background-color: rgb(255, 255, 255); border-radius: 0px; border-collapse: separate; padding-left: 20px; padding-right: 20px;\"><tbody><tr>                                 <td class=\"rnb-container-padding\" style=\"font-size: px;font-family: ; color: ;\">                                      <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" class=\"rnb-columns-container\" align=\"left\" style=\"margin:auto;\">                                         <tbody><tr>                                              <th class=\"rnb-force-col\" align=\"left\" style=\"text-align: center; font-weight: normal\">                                                  <table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"center\" class=\"rnb-col-1\"><tbody><tr><td height=\"10\"></td></tr>                                                      <tr><td style=\"font-family:Arial,Helvetica,sans-serif; color:#3c4858; text-align:left;\">                                                              <span style=\"color:#3c4858;\"><div><span style=\"font-size:18px;\">'.$regards.'</span></div> </span></td></tr><tr><td height=\"10\"></td></tr></tbody></table>                                                 </th></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table><!--[if mso]></td><![endif]--><!--[if mso]></tr></table><![endif]--></div></td</tr><tr><td align=\"center\" valign=\"top\"><table class=\"rnb-del-min-width\" width=\"100%\" cellpadding=\"0\" border=\"0\" cellspacing=\"0\" style=\"min-width:590px;\" name=\"Layout_\" id=\"Layout_\">                 <tbody><tr><td class=\"rnb-del-min-width\" valign=\"top\" align=\"center\" style=\"min-width:590px;\"><a href=\"#\" name=\"Layout_\"></a><table width=\"100%\" cellpadding=\"0\" border=\"0\" height=\"5\" cellspacing=\"0\"><tbody><tr><td valign=\"top\" height=\"5\"><img width=\"20\" height=\"5\" style=\"display:block; max-height:5px; max-width:20px;\" alt=\"\" src=\"https://img.mailinblue.com/new_images/rnb/rnb_space.gif\"></td></tr></tbody></table></td>                 </tr>             </tbody></table>             </td>     </tr><tr>          <td align=\"center\" valign=\"top\">              <div style=\"background-color: rgb(249, 250, 252);\">                                  <table class=\"rnb-del-min-width rnb-tmpl-width\" width=\"100%\" cellpadding=\"0\" border=\"0\" cellspacing=\"0\" style=\"min-width:590px;\" name=\"Layout_5\" id=\"Layout_5\">                     <tbody><tr>                         <td class=\"rnb-del-min-width\" align=\"center\" valign=\"top\" bgcolor=\"#f9fafc\" style=\"min-width: 590px; background-color: rgb(249, 250, 252);\">                             <a href=\"#\" name=\"Layout_5\"></a>                             <table width=\"590\" class=\"rnb-container\" cellpadding=\"0\" border=\"0\" align=\"center\" cellspacing=\"0\">                                 <tbody><tr>                                     <td height=\"20\" style=\"font-size:1px; line-height:20px; mso-hide: all;\">&nbsp;</td>                                 </tr>                                 <tr>                                     <td valign=\"top\" class=\"rnb-container-padding\" style=\"font-size: 14px; font-family: Arial,Helvetica,sans-serif; color: #888888;\" align=\"left\">                                          <table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" class=\"rnb-columns-container\">                                             <tbody><tr>                                                 <th class=\"rnb-force-col\" style=\"padding-right:20px; padding-left:20px; mso-padding-alt: 0 0 0 20px; font-weight: normal;\" valign=\"top\">                                                      <table border=\"0\" valign=\"top\" cellspacing=\"0\" cellpadding=\"0\" width=\"264\" align=\"left\" class=\"rnb-col-2 rnb-social-text-left\" style=\"border-bottom:0;\">                                                          <tbody><tr>                                                             <td valign=\"top\">                                                                 <table cellpadding=\"0\" border=\"0\" align=\"left\" cellspacing=\"0\" class=\"rnb-btn-col-content\">                                                                     <tbody><tr>                                                                         <td valign=\"middle\" align=\"left\" style=\"font-size:14px; font-family:Arial,Helvetica,sans-serif; color:#888888; line-height: 16px\" class=\"rnb-text-center\">                                                                             <div>'.$footer.'</div>                                                                         </td></tr>                                                                 </tbody></table>                                                             </td>                                                         </tr>                                                         </tbody></table>                                                     </th><th ng-if=\"item.text.align==left\" class=\"rnb-force-col rnb-social-width\" valign=\"top\" style=\"mso-padding-alt: 0 20px 0 0; padding-right: 15px;\">                                                      <table border=\"0\" valign=\"top\" cellspacing=\"0\" cellpadding=\"0\" width=\"246\" align=\"right\" class=\"rnb-last-col-2\">                                                          <tbody><tr>                                                             <td valign=\"top\">                                                                 <table cellpadding=\"0\" border=\"0\" cellspacing=\"0\" class=\"rnb-social-align\" style=\"float: right;\" align=\"right\"><tbody><tr><td valign=\"middle\" class=\"rnb-text-center\" ng-init=\"width=setSocialIconsBlockWidth(item)\" width=\"165\" align=\"right\"></td></tr>                                                                 </tbody></table>                                                             </td>                                                         </tr>                                                         </tbody></table></th></tr></tbody></table></td></tr><tr><td height=\"20\" style=\"font-size:1px; line-height:20px; mso-hide: all;\">&nbsp;</td></tr></tbody></table></td></tr></tbody></table></div></td></tr><tr><td align=\"center\" valign=\"top\"><div style=\"background-color: rgb(249, 250, 252);\"><table class=\"rnb-del-min-width rnb-tmpl-width\" width=\"100%\" cellpadding=\"0\" border=\"0\" cellspacing=\"0\" style=\"min-width:590px;\" name=\"Layout_8\" id=\"Layout_8\"><tbody><tr><td class=\"rnb-del-min-width\" valign=\"top\" align=\"center\" style=\"min-width: 590px;\"><a href=\"#\" name=\"Layout_8\"></a></td></tr></tbody></table></div></td>     </tr><tr>          <td align=\"center\" valign=\"top\">              <div style=\"background-color: rgb(249, 250, 252);\"><table class=\"rnb-del-min-width rnb-tmpl-width\" width=\"100%\" cellpadding=\"0\" border=\"0\" cellspacing=\"0\" style=\"min-width:590px;\" name=\"Layout_7\" id=\"Layout_7\"><tbody><tr><td class=\"rnb-del-min-width\" align=\"center\" valign=\"top\" style=\"min-width:590px;\">                             <a href=\"#\" name=\"Layout_7\"></a><table width=\"100%\" cellpadding=\"0\" border=\"0\" align=\"center\" cellspacing=\"0\" bgcolor=\"#f9fafc\" style=\"padding-right: 20px; padding-left: 20px; background-color: rgb(249, 250, 252);\">                                 <tbody><tr><td height=\"20\" style=\"font-size:1px; line-height:20px; mso-hide: all;\">&nbsp;</td>                                 </tr><tr><td style=\"font-size:14px; color:#888888; font-weight:normal; text-align:center; font-family:Arial,Helvetica,sans-serif;\"><div>© 2020 iAudit</div></td></tr><tr><td height=\"20\" style=\"font-size:1px; line-height:20px; mso-hide: all;\">&nbsp;</td></tr></tbody></table></td></tr></tbody></table></div></td></tr><tr><td align=\"center\" valign=\"top\"><div style=\"background-color: rgb(15, 123, 184);\"><table class=\"rnb-del-min-width rnb-tmpl-width\" width=\"100%\" cellpadding=\"0\" border=\"0\" cellspacing=\"0\" style=\"min-width:590px;\" name=\"Layout_17\" id=\"Layout_17\"><tbody><tr><td class=\"rnb-del-min-width\" align=\"center\" valign=\"top\" style=\"min-width:590px;\"><a href=\"#\" name=\"Layout_17\"></a><table width=\"100%\" cellpadding=\"0\" border=\"0\" align=\"center\" cellspacing=\"0\"  bgcolor=\"#0f7bb8\" style=\"padding-right: 20px; padding-left: 20px; background-color: rgb(15, 123, 184);\"><tbody><tr><td height=\"20\" style=\"font-size:1px; line-height:20px; mso-hide: all;\">&nbsp;</td></tr><tr><td style=\"font-size:14px; color:#888888; font-weight:normal; text-align:center; font-family:Arial,Helvetica,sans-serif;\"><div></div></td></tr><tr><td height=\"20\" style=\"font-size:1px; line-height:20px; mso-hide: all;\">&nbsp;</td></tr></tbody></table></td></tr></tbody></table></div></td></tr></tbody></table><!--[if gte mso 9]></td></tr></table><![endif]--></td></tr></tbody></table><!--[if gte mso 9]></td></tr></table><![endif]--></td></tr></tbody></table>  </body></html>';
    // echo $msg;
    $data_string = '{"sender":{"email":"iaudit.help@GMAIL.com","name":"iAudit Team"},"to":[{"email":"'.$email.'","name":"'.$name.'"}],"replyTo":{"email":"iaudit.help@gmail.com"},"subject":"'.$subject.'",
    "htmlContent": "'.$msg.'","textContent":"none"}';
    // $data_string=json_encode($data_string);
    $ch = curl_init('https://api.sendinblue.com/v3/smtp/email');                                                                      
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");                                                                     
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);                                                                  
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);                                                                      
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                  
        'Content-Type: application/json',                                                                                
        'Content-Length: ' . strlen($data_string),
    	'api-key: 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')                                                                       
    );         
     $result = curl_exec($ch);
    //  echo "Res = " . $result;
}
///////////////////////////////////////////////////////////////
function msgOutput($type, $page){
	$type = trim($type);		$page = trim($page);
	if($page == ''){
		$urlname = $_SERVER["REQUEST_URI"];
		$urlurl = explode("/",$urlname);
		$cnturl = count($urlurl);
		$finalpage = $urlurl[$cnturl-1];
		$page = trim($finalpage);
	}
	//echo $type;
	switch($type){
		case 1:	
			$title = "Added";
			$text = "Record Successfully Saved.";
			$type = "success";
			$msg = '<script> swal({
			  title: "'.$title.'",
			  text: "'.$text.'",
			  type: "'.$type.'",
			  closeOnConfirm: false
			},
			function(){
			  window.location="'.$page.'";
			});
			</script>'; 
		break;
		case 2:
			$title = "Duplicate";
			$text = "Record Already Exist.";
			$type = "error";
			$msg = '<script> swal({
			  title: "'.$title.'",
			  text: "'.$text.'",
			  type: "'.$type.'",
			  closeOnConfirm: false
			},
			function(){
			  window.location="'.$page.'";
			});
			</script>';  
			 
		break;
		case 3:
			$title = "Update";
			$text = "Record Successfully Updated.";
			$type = "success";
			$msg = '<script> swal({
			  title: "'.$title.'",
			  text: "'.$text.'",
			  type: "'.$type.'",
			  closeOnConfirm: false
			},
			function(){
			  window.location="'.$page.'";
			});
			</script>'; 
		break;
		case 4:
			$title = "Delete";
			$text = "Record Successfully Deleted.";
			$type = "success";
			$msg = '<script> swal({
			  title: "'.$title.'",
			  text: "'.$text.'",
			  type: "'.$type.'",
			  closeOnConfirm: false
			},
			function(){
			  window.location="'.$page.'";
			});
			</script>'; 
		break;
		case 6:
			$title = "Wrong";
			$text = "Old Password not match!";
			$type = "warning";
			$msg = '<script> swal({
			  title: "'.$title.'",
			  text: "'.$text.'",
			  type: "'.$type.'",
			  closeOnConfirm: true
			},
			function(){
			});
			</script>'; 
		break;
		case 7:
			$title = "Update";
			$text = "Password Updated.";
			$type = "success";
			$msg = '<script> swal({
			  title: "'.$title.'",
			  text: "'.$text.'",
			  type: "'.$type.'",
			  closeOnConfirm: false
			},
			function(){
			  window.location="'.$page.'";
			});
			</script>'; 
		break;
		case 8:
			$title = "";
			$text = "Password send to successfully to your Mobile and Email.";
			$type = "success";
			$msg = '<script> swal({
			  title: "'.$title.'",
			  text: "'.$text.'",
			  type: "'.$type.'",
			   
			},
			function(){
			  window.location="'.$page.'";
			});
			</script>'; 
		break; 
		default:
			$title = "Wrong";
			$text = "Something Wrong.";
			$type = "warning";
			$msg = '<script> swal({
			  title: "'.$title.'",
			  text: "'.$text.'",
			  type: "'.$type.'",
			  closeOnConfirm: true
			},
			function(){
			});
			</script>'; 
		break;
	}
	/*
	$msg = '<script> swal({
		  title: "'.$title.'",
		  text: "'.$text.'",
		  type: "'.$type.'",
		  closeOnConfirm: false
		},
		function(){
		  window.location="'.$page.'";
		});
		</script>'; 
	*/
	return $msg;	

}
function testInput($data) 
{
  $data = trim($data);
  $data = addslashes($data);
  $data = htmlspecialchars($data);
// $data = strip_tags($data);
  //echo $data ; die;
  return strtoupper($data);
}
function gen_password($size = 8) 
{
	$size = $size > 36 ? 30 : $size;
	$pool = array_merge(range(1, 9), range('A', 'Z'));
	$rand_keys = array_rand($pool, $size);

	$password = '';
	
	foreach ($rand_keys as $key) 
	{
		$password .= $pool[$key];
	}

	return $password;
}	
function showOutput($data) 
{
  $data = stripslashes($data);
  $data = htmlspecialchars_decode($data);
  return $data;
}
function useractivity_logs($con,$action_type,$page_name,$table_name,$column_id,$user_id)
{
	$date = date("Y-m-d H:i:s");
	$sql = "insert into useractivity_logs(action_type,page_name,table_name,column_id,user_id,createdate) 
	values ('$action_type', '$page_name', '$table_name', '$column_id', '$user_id','$date')";
	//echo $sql; die;
	mysqli_query($con,$sql);
}
// To encrypt data based on key //
function encrypt($string, $key)
{  
	$result = '';
	for($i=0; $i<strlen($string); $i++)
	{
		$char = substr($string, $i, 1);
		$keychar = substr($key, ($i % strlen($key))-1, 1);
		$char = chr(ord($char)+ord($keychar));
		$result.=$char;
	}
	return base64_encode($result);
}

// To decrypt data based on key //
function decrypt($string, $key)
{  
	$result = '';
	$string = base64_decode($string);
	for($i=0; $i<strlen($string); $i++)
	{
		$char = substr($string, $i, 1);
		$keychar = substr($key, ($i % strlen($key))-1, 1);
		$char = chr(ord($char)-ord($keychar));
		$result.=$char;
	}
	return $result;
}
function getmaxid($con,$id,$tab,$cond=1)
{
	//This module Generate id for online
	if($_SERVER["SERVER_NAME"]=="opencompas.com" || $_SERVER["SERVER_NAME"]=="www.opencompas.com")
	{
		
		$s="select Max($id) as max from $tab where $cond";
		$tabdata= mysqli_query( $con,$s);
		$tab1=mysqli_fetch_array($tabdata);
		$tab=$tab1['max'];
		if($tab!="")
		{
			if($tab%2==0)
			$nextid=$tab+1;
			else
			$nextid=$tab+2;
		}
		else
		{
			$nextid=1;
		}
		return $nextid;
	}
	else	//This module Generate id for off line
	{
		$s="select Max($id) as max from $tab where $cond";
		$tabdata= mysqli_query( $con,$s);
		$tab1=mysqli_fetch_array($tabdata);
		$tab=$tab1['max'];
		if($tab!="")
		{
			if($tab%2==0)
			$nextid=$tab+2;
			else
			$nextid=$tab+1;
		}
		else
		{
			$nextid=2;
		}
		return $nextid;
	}
} 

// To encrypt data based on key //


function reArrayFiles($file)
{
    $file_ary = array();
    $file_count = count($file['name']);
    $file_key = array_keys($file);
    
    for($i=0;$i<$file_count;$i++)
    {
        foreach($file_key as $val)
        {
            $file_ary[$i][$val] = $file[$val][$i];
        }
    }
    return $file_ary;
}


// to check if a parent table exist in child table
function deleteData($con,$query_string)
{
  try 
  {
	//echo $query_string;
	$resdel = mysqli_query($con,$query_string);
	if(!$resdel)
	{
	  throw new Exception("Data Cannot be Deleted");
	}
	else
	{
	  return true;
	}
  
  } 
  catch (Exception $e) {
		 echo $e->getMessage();
	}
}

//----------Get Voucher No----//
function getVoucherNo($con,$type)
{
	/*$sql = "select emplastcode from emp_count where cainfoid=$cainfoid";
	$getvalue = mysqli_query($con,$sql);
	$getval = mysqli_fetch_row($getvalue);*/
	
	echo $sql = "select series_start,session_end,prefix from voucher_series where voucher_type='$type' ";
	$getvalue = mysqli_query($con,$sql);
	$getval = mysqli_fetch_array($getvalue);
	
	//$id =0;
	/*if($getval[0] != "")
	{
		function int($s){return(int)preg_replace('/[^\-\d]*(\-?\d*).*//*','$1',$s);}
		$id = int($getval[0]);
	}
	*/
	$id = $getval['series_start']+1;
	$prefix = $getval['prefix'];
	return 33;
}
// get value if you know the primary key value //
function getvalMultiple($con,$table,$field,$where,$space)
{
	if($where != "")
	 $sql = "select $field from $table where $where";
	else
	 $sql = "select $field from $table";
	 
	//echo $sql;
	$getvalue = mysqli_query($con,$sql);
	$getval="";
	while($row = mysqli_fetch_row($getvalue))
	{
		if($getval == "")
		$getval = $row[0];
		else
		{
			if($space==true)
			$getval .= ", ". $row[0];
			else
			$getval .= ",". $row[0];
		}
	}
	return $getval;
}

function showData($con, $tableName , $where=1) {
        $query = "SELECT * FROM $tableName WHERE $where";
		//echo $query; die;
		 mysqli_set_charset($link,'utf8');
        $result = mysqli_query($con, $query);
        $num_rows = mysqli_num_rows($result);
        for ($i = 0; $i < $num_rows; $i++) {
            $data[] = mysqli_fetch_assoc($result);
        }
		if($num_rows==0)
		return array();
		//echo "hiiii";
		else
        return $data;
		
    }


// get value from any condition //
function getvalfield($con,$table,$field,$where)
{
	$sql = "select $field from $table where $where";
	//echo $sql; echo "<br>";
	$getvalue = mysqli_query($con,$sql);
	$getval = mysqli_fetch_row($getvalue);

	return $getval[0];
}

// get date format (01 march 2012) from 2012-03-01 //
function dateformat($date)
{
	if($date != "0000-00-00")
	{
	$ndate = explode("-",$date);
	$year = $ndate[0];
	$day = $ndate[2];
	$month = intval($ndate[1])-1;
	$montharr = array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
	$month1 = $montharr[$month];
	
	
	return $day . " " . $month1 . " " . $year;
	}
	else
	return "";
}

// get date format (01-03-2012) from (2012-03-01) //
function dateformatindia($date)
{
	$ndate = explode("-",$date);
	$year = $ndate[0];
	$day = $ndate[2];
	$month = $ndate[1];
	
	if($date == "0000-00-00" || $date =="")
	return "";
	else
	return $day . "-" . $month . "-" . $year;
	
}

// get date format (01-03-2012) from (2012-03-01 23:12:04) //
function dateFullToIndia($date,$full)
{
	$fdate = explode(" ",$date);
	
	$ndate = explode("-",$fdate[0]);
	$year = $ndate[0];
	$day = $ndate[2];
	$month = $ndate[1];
	
	$time = explode(":",$fdate[1]);
	$hour = $time[0];
	$minute = $time[1];
	$second = $time[2];
	if($hour > 12)
	{
		$h = $hour-12;
		if($h < 10)
		$h = "0" . $h;
		$fulltime = $h . ":" . $minute . ":" . $second . " PM";
	}
	else
	$fulltime = $hour . ":" . $minute . ":" . $second . " AM";
	
	
	if($full == "full")
	return $day . "-" . $month . "-" . $year . " " . $fdate[1];
	else if($full == "fullindia")
	return $day . "-" . $month . "-" . $year . " " . $fulltime;
	else if($full == "time")
	return $fulltime;
	else
	return $day . "-" . $month . "-" . $year;
}

// get date format (2012-03-01) from (01-03-2012) //
function dateformatusa($date)
{
	$ndate = explode("-",$date);
	$year = $ndate[2];
	$day = $ndate[0];
	$month = $ndate[1];
	
	return $year . "-" . $month . "-" . $day;
}



// get image in particular size. if you writ only width then it returns in ratio of height. and you can set width and height //
function convert_image($fname,$path,$wid,$hei)
{
	$wid = intval($wid); 
	$hei = intval($hei); 
	//$fname = $sname;
	$sname = "$path$fname";
	//echo $sname;
	//header('Content-type: image/jpeg,image/gif,image/png');
	//image size
	list($width, $height) = getimagesize($sname);
	
	if($hei == "")
	{
		if($width < $wid)
		{
			$wid = $width;
			$hei = $height;
		}
		else
		{
			$percent = $wid/$width;  
			$wid = $wid;
			$hei = round ($height * $percent);
		}
	}
	
	//$wid=469;
	//$hei=290;
	$thumb = imagecreatetruecolor($wid,$hei);
	//image type
	$type=exif_imagetype($sname);
	//check image type
	switch($type)
	{
	case 2:
	$source = imagecreatefromjpeg($sname);
	break;
	case 3:
	$source = imagecreatefrompng($sname);
	break;
	case 1:
	$source = imagecreatefromgif($sname);
	break;
	}
	// Resize
	imagecopyresized($thumb, $source, 0, 0, 0, 0,$wid,$hei, $width, $height);
	//echo "converted";
	//else
	//echo "not converted";
	// source filename
	$file = basename($sname);
	//destiantion file path
	//$path="uploaded/flashgallery/";
	$dname=$path.$fname;
	//display on browser
	//imagejpeg($thumb);
	//store into file path
	imagejpeg($thumb,$dname);
}

// for get mixed no. like password etc. //
function getmixedno($totalchar)
{
	$abc= array("A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "1", "2", "3", "4", "5", "6", "7", "8", "9");
	$mixedno = "";
	for($i=1; $i<=$totalchar; $i++)
	{
		$mixedno .= $abc[rand(0,33)];
	}
	return $mixedno;
}


// get total no. of rows //
function getTotalNum($con,$table,$where)
{
	$sql = "select * from $table where $where";
	//echo $sql;
	$getvalue = mysqli_query($con,$sql);
	$getval = mysqli_num_rows($getvalue);

	return $getval;
	//return $sql;
}


// for pagination //
function startPagination($con,$page_query, $data_in_a_page)
{
	$getrow = mysqli_query($con,$page_query);
	$count = mysqli_num_rows($getrow);
	
	$page_for_site = "";
	
	$page=1;
	if(isset($_REQUEST['page']))
	$page = $_REQUEST['page'];
	
	if($count > $data_in_a_page)
	{
		$cnt = ceil($count / $data_in_a_page);
		
		$page_for_site .= "<div style='float:left; padding-top:3px; color:#c0f;'>Page $page of $cnt &nbsp;&nbsp;&nbsp;</div>";
		
		for($i = 1; $i<= $cnt; $i++)
		{
			$class = " class='pagination' ";
			if($i == $page)
			$class = " class='pagination-current' ";
			
			$pu = $this->curPageURL();
			$cm = explode("/",$pu);
			$n = count($cm);
			$curl = $cm[$n-1];
			
			$qm_avail = strpos($curl,"?");
			if($qm_avail == "")
			$page_for_site .= "<a href='?page=$i' $class>$i</a>";
			else
			{
				$page_avail = strpos($curl,"page=");
				if($page_avail != "")
				{
					$pagevalue = $_REQUEST['page'];
					$past_page = "page=$pagevalue";
					$finalurl = str_replace($past_page,"page=$i",$curl);
					$page_for_site .= "<a href='$finalurl' $class>$i</a>";
				}
				else
				$page_for_site .= "<a href='$curl&page=$i' $class>$i</a>";
			}
		}
		$page_for_site .= "<div style='clear:both'></div>";
	}
	echo $page_for_site;
}


// return present page url //
function curPageURL()
{
	$pageURL = 'http';
	if ($_SERVER["HTTPS"] == "on") {$pageURL .= "s";}
	$pageURL .= "://";
	if ($_SERVER["SERVER_PORT"] != "80") 
	$pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
	else
	$pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
	return $pageURL;
}

// change number into word format //
function numtowords($num)
{
	$ones = array(
	1 => "one",
	2 => "two",
	3 => "three",
	4 => "four",
	5 => "five",
	6 => "six",
	7 => "seven",
	8 => "eight",
	9 => "nine",
	10 => "ten",
	11 => "eleven",
	12 => "twelve",
	13 => "thirteen",
	14 => "fourteen",
	15 => "fifteen",
	16 => "sixteen",
	17 => "seventeen",
	18 => "eighteen",
	19 => "nineteen"
	);
	$tens = array(
	2 => "twenty",
	3 => "thirty",
	4 => "forty",
	5 => "fifty",
	6 => "sixty",
	7 => "seventy",
	8 => "eighty",
	9 => "ninety"
	);
	$hundreds = array(
	"hundred",
	"thousand",
	"million",
	"billion",
	"trillion",
	"quadrillion"
	); //limit t quadrillion
	$num = number_format($num,2,".",",");
	$num_arr = explode(".",$num);
	$wholenum = $num_arr[0];
	$decnum = $num_arr[1];
	$whole_arr = array_reverse(explode(",",$wholenum));
	krsort($whole_arr);
	$rettxt = "";
	foreach($whole_arr as $key => $i)
	{
		if($i < 20)
		{
			$rettxt .= $ones[$i];
		}
		elseif($i < 100)
		{
			$rettxt .= $tens[substr($i,0,1)];
			$rettxt .= " ".$ones[substr($i,1,1)];
		}
		else
		{
			$rettxt .= $ones[substr($i,0,1)]." ".$hundreds[0];
			$rettxt .= " ".$tens[substr($i,1,1)];
			$rettxt .= " ".$ones[substr($i,2,1)];
		}
		
		if($key > 0)
		{
			$rettxt .= " ".$hundreds[$key]." ";
		}
	}
	if($decnum > 0)
	{
		$rettxt .= " and ";
		if($decnum < 20)
		{
			$rettxt .= $ones[$decnum];
		}
		elseif($decnum < 100)
		{
			$rettxt .= $tens[substr($decnum,0,1)];
			$rettxt .= " ".$ones[substr($decnum,1,1)];
		}
	}
	return $rettxt;
} 
function sendSmsdynamic($link,$msg, $mobile, $schedule="", $sentid="", $action=1,$lang=0)
{
		
		
	//$smsuname    = "crmprofs"; //$rowSms['smsuname'];   // sms user name 
	//$smspass     = "Right@12";//$rowSms['smspass'];    // sms password 
	//$smssender   = "PROSYS"; //$rowSms['smssender'];  // sms sender id	
	
	$smsuname    = "taurus"; //$rowSms['smsuname'];   // sms user name 
	$smspass     = "81636ca70eXX";//$rowSms['smspass'];    // sms password 
	$smssender   = "RELABL"; //$rowSms['smssender'];  // sms sender id
	$veruname    = "user"; //$rowSms['veruname'];   // variable name of user name
	$verpass     = "password";//$rowSms['verpass'];    // variable name of password
	$versender   = "senderid";//$rowSms['versender'];  // variable name of sender id
	$vermessage  = "sms";//$rowSms['vermessage']; // variable name of message
	$vermob      = "mobiles";//$rowSms['vermob'];     // variable name of to (mobile no)
	
	$verdate     = "dt";//$rowSms['verdate'];    // variable of date field for schedule sms
	$verpatter   = "yyyy-mm-dd hh:mm:ss";//$rowSms['verpatter'];  // pattern of date field e.g. ddmmyyyy
	$working_key = ""; //$rowSms['working_key'];// working key
	$verkey      = "workingkey";// $rowSms['verkey'];     // variable name of working key
	
	$api_url     = "dndsms.reliableindya.info";//"dndsms.reliableindya.info";//$rowSms['api_url'];    // API URL
	$send_api    = "sendsms.jsp";//$rowSms['send_api'];   // sending page name 
	
	$chk_bal_api = "getbalance.jsp";//$rowSms['chk_bal_api'];// balance check api
	$sch_api     = "getDLR.jsp";// $rowSms['sch_api'];    // schedule api
	$status_api  = "getDLR.jsp";//$rowSms['status_api']; // status api
	
	
	//echo "Called";
	$request = ""; //initialize the request variable
	if($api_url=="smsjust.com" )
	{
		$api_url='smsjust.com';
		$host='smsjust.com';
		$ch = curl_init();
	}
	
	if($working_key == "")
	{
		if(($action==2 && ($api_url == "smsjust.com" )))
		{
		}
		else
		{
			$param[$veruname] = $smsuname; //this is the username of our TM4B account
			$param[$verpass]  = $smspass; //this is the password of our TM4B account
			
			if($action==1)
			$param[$vermob]   = $mobile; //these are the recipients of the message
		}
	}
	else
	{
		if(($action==2 && ($api_url == "smsjust.com")))
		{
		}
		else
		{
			$param[$verkey] = $working_key; //this is the key of our TM4B account
			
			if($action==1)
			$param[$vermob] = "+91".$mobile; //these are the recipients of the message
		}
	}
	
	if($action==1)
	{
		$param[$versender]  = $smssender;//this is our sender 
		$param[$vermessage] = $msg; //this is the message that we want to send
	}
	else if($action==2)
	{
		if($api_url == "smsjust.com" )
		{
			$param['Scheduleid']  =$sentid;

		}
		else
		{
		$param['messageid']  = $sentid;//this is our sender 
		}
	}
	if(( $api_url=="smsjust.com") && $action!=2)
	{
		$param['response'] = 'Y';// variable name of responce  for websms
	}
	// for schedule //
	if($schedule!="")
	{
		$timearr = explode(" ",$schedule);
		
		$dateoftime = $timearr[0];
		$timeoftime = $timearr[1];
		
		$datearr = explode("-",$dateoftime); // explode Date //
		$yyyy = $datearr[0]; // year
		$mm   = $datearr[1]; // month
		$dd   = $datearr[2]; // day
		
		$datearr = explode(":",$timeoftime);
		$hh  = $datearr[0];
		$mmt = $datearr[1];
		$ss  = $datearr[2];
		
		$scdltime = strtolower($verpatter);
		$scdltime = str_replace("yyyy",$yyyy,$scdltime);
		$scdltime = str_replace("dd",$dd,$scdltime);
		$scdltime = str_replace("hh",$hh,$scdltime);
		$scdltime = str_replace("ss",$ss,$scdltime);
		$scdltime = preg_replace('/mm/i', $mm, $scdltime, 1);
		$scdltime = str_replace("mm",$mmt,$scdltime);
		if(($api_url=="smsjust.com"))
		{
			$param['dt'] = "$yyyy-$mm-$dd";
			$param['tm'] = "$hh-$mmt-$ss";
		}
		else
		{
			$param[$verdate] = $scdltime; //this is the schedule datetime //
		}
		
		
		
	}
	//print_r($param);	
	foreach($param as $key=>$val) //traverse through each member of the param array
	{ 
		$request.= $key."=".urlencode($val); //we have to urlencode the values
		$request.= "&"; //append the ampersand (&) sign after each paramter/value pair
	}
	if($lang!=0 && $api_url!="smsjust.com")
	{
		$request.="unicode=1&";
	}
	elseif($lang!=0 && ($api_url=="smsjust.com"))
	{
		$request.="msgtype=UNI&";
	}
	
	
	$request = substr($request, 0, strlen($request)-1); //remove the final ampersand sign from the request
	//echo $request;

	if($action=="1") // 1 for send sms //
	$process_api = trim($send_api,"/");
	else if($action=="2") // 2 for Delivery report //
	$process_api = trim($status_api,"/");
	else if($action=="3") // 3 for check balance //
	$process_api = trim($chk_bal_api,"/");
	
	
	//First prepare the info that relates to the connection
	$host = $api_url;
	$script = "/$process_api";
	$request_length = strlen($request);
	$method = "POST"; // must be POST if sending multiple messages
	if ($method == "GET") 
	{
	  $script .= "?$request";
	}
	
	if($api_url == "smsjust.com")
	{
		 $url="http://$host$script?$request";
		 curl_setopt($ch,CURLOPT_URL, $url);

		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

		$output= curl_exec($ch);
		
		curl_close($ch);
		
		//if($action == 1)die;
	}
	else
	{
		//Now comes the header which we are going to post. 
		$header = "$method $script HTTP/1.1\r\n";
		$header .= "Host: $host\r\n";
		$header .= "Content-Type: application/x-www-form-urlencoded\r\n";
		$header .= "Content-Length: $request_length\r\n";
		$header .= "Connection: close\r\n\r\n";
		$header .= "$request\r\n";
		
		//echo $header;
		//Now we open up the connection
		$socket = @fsockopen($host, 80, $errno, $errstr); 
		if ($socket) //if its open, then...
		{ 
		  fputs($socket, $header); // send the details over
		  while(!feof($socket))
		  {
			 $output[] = fgets($socket); //get the results 
					
		  }
		  fclose($socket); 
		}
	}
	//print_r($output);	
	if($action==1) // sent sms //
	{
		if($api_url=="alerts.reliableindya.info")
		{
			$cntOutput = count($output);
			$lastValue = $output[$cntOutput-1];
			
			$expLastValue = explode("=",$lastValue);
			$cntLastValue = count($expLastValue);
			$messageid = $expLastValue[$cntLastValue-1];
			
			return  $messageid;
		}
		else if($api_url=="dndsms.reliableindya.info" || $api_url=="bulk.reliableindya.info"  || $api_url=="dndsms.reliableservices.org")
		{
			//$messageid = trim($output[22])."||".trim($output[21]);
			$messageid = trim($output[19]);
			return $messageid; //substr($lastBal,4);
		}
		if($api_url=="smsjust.com")
		{
			return $output;
		}
		
	}
	else if($action==2) // delivery report //
	{
		return  $output;
	}
	else if($action==3) // check balance //
	{
		if($api_url=="alerts.reliableindya.info")
		{
			$balamount = "";
			//print_r($output);
			foreach($output as $op)
			{
				if(strpos($op,'trans')!==false)
				$balamount = $op;
			}
			//return preg_replace("/[^0-9]/","",$output[9]);
			return preg_replace("/[^0-9.]/","",$balamount);
		}
		else if($api_url=="smsjust.com" || $api_url == "dndsms.reliableindya.info")
		{
			$outArr = explode(":",$output);
			$output = trim($outArr[1]);
			return $output;
		}
	}
	
}
function sms_log($link,$type,$sentid,$msg,$mobile_no,$pagename,$created_by,$company_id=0,$company_name='Super Admin',$branch_id=0,$branch_name='')
{
  $date = date("Y-m-d H:i:s");
  
  $sql = "insert into sms_information(type,id,msg,mobile_no,pagename,created_by,company_id,company_name,branch_id,branch_name,createdate) 
  values ('$type','$sentid', '$msg', '$mobile_no','$pagename','$created_by','$company_id','$company_name','$branch_id','$branch_name','$date')";
  //echo $sql; 
   mysqli_query($link,$sql);
}
function getRealIpAddr()
{
    if (!empty($_SERVER['HTTP_CLIENT_IP']))   //check ip from share internet
    {
      $ip=$_SERVER['HTTP_CLIENT_IP'];
    }
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   //to check ip is pass from proxy
    {
      $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    else
    {
      $ip=$_SERVER['REMOTE_ADDR'];
    }
	
	
    return $ip;
}
function sendSmsDynamic1($con,$caid, $msg, $mobile, $schedule="", $sentid="", $action=1)
{
	
	/*-----to check if sms info exist in table----*/
    $sttSms = "select * from sms_info where caid='$caid'";
	$sqlSms = mysqli_query($con,$sttSms);
	$cntsms = mysqli_num_rows($sqlSms);
	if($cntsms==0)
	{
	  $caid=1;
	}
	$sttSms = "select * from sms_info where caid='$caid'";
	$sqlSms = mysqli_query($con,$sttSms);
	$rowSms = mysqli_fetch_assoc($sqlSms);
	//die;
	
	$smsuname    = $rowSms['smsuname'];   // sms user name 
	$smspass     = $rowSms['smspass'];    // sms password 
	$smssender   = $rowSms['smssender'];  // sms sender id
	$veruname    = $rowSms['veruname'];   // variable name of user name
	$verpass     = $rowSms['verpass'];    // variable name of password
	$versender   = $rowSms['versender'];  // variable name of sender id
	$vermessage  = $rowSms['vermessage']; // variable name of message
	$vermob      = $rowSms['vermob'];     // variable name of to (mobile no)
	
	$verdate     = $rowSms['verdate'];    // variable of date field for schedule sms
	$verpatter   = $rowSms['verpatter'];  // pattern of date field e.g. ddmmyyyy
	$working_key = $rowSms['working_key'];// working key
	$verkey      = $rowSms['verkey'];     // variable name of working key
	
	$api_url     = $rowSms['api_url'];    // API URL
	$send_api    = $rowSms['send_api'];   // sending page name 
	
	$chk_bal_api = $rowSms['chk_bal_api'];// balance check api
	$sch_api     = $rowSms['sch_api'];    // schedule api
	$status_api  = $rowSms['status_api']; // status api
	
	
	//echo "Called";
	$request = ""; //initialize the request variable
	
	if($working_key == "")
	{
		$param[$veruname] = $smsuname; //this is the username of our TM4B account
		$param[$verpass]  = $smspass; //this is the password of our TM4B account
		
		if($action==1)
		$param[$vermob]   = $mobile; //these are the recipients of the message
	}
	else
	{
		$param[$verkey] = $working_key; //this is the key of our TM4B account
		
		if($action==1)
		$param[$vermob] = "91".$mobile; //these are the recipients of the message
	}
	
	if($action==1)
	{
		$param[$versender]  = $smssender;//this is our sender 
		$param[$vermessage] = $msg; //this is the message that we want to send
	}
	else if($action==2)
	{
		$param['messageid']  = $sentid;//this is our sender 
	}
	
	// for schedule //
	if($schedule!="")
	{
		$timearr = explode(" ",$schedule);
		
		$dateoftime = $timearr[0];
		$timeoftime = $timearr[1];
		
		$datearr = explode("-",$dateoftime); // explode Date //
		$yyyy = $datearr[0]; // year
		$mm   = $datearr[1]; // month
		$dd   = $datearr[2]; // day
		
		$datearr = explode(":",$timeoftime);
		$hh  = $datearr[0];
		$mmt = $datearr[1];
		$ss  = $datearr[2];
		
		$scdltime = strtolower($verpatter);
		$scdltime = str_replace("yyyy",$yyyy,$scdltime);
		$scdltime = str_replace("dd",$dd,$scdltime);
		$scdltime = str_replace("hh",$hh,$scdltime);
		$scdltime = str_replace("ss",$ss,$scdltime);
		$scdltime = preg_replace('/mm/i', $mm, $scdltime, 1);
		$scdltime = str_replace("mm",$mmt,$scdltime);
		
		
		 $param[$verdate] = $scdltime; //this is the schedule datetime //
		
	}
	//print_r($param);	
	foreach($param as $key=>$val) //traverse through each member of the param array
	{ 
		$request.= $key."=".urlencode($val); //we have to urlencode the values
		$request.= "&"; //append the ampersand (&) sign after each paramter/value pair
	}
	$request = substr($request, 0, strlen($request)-1); //remove the final ampersand sign from the request
	//echo $request;

	if($action=="1") // 1 for send sms //
	$process_api = trim($send_api,"/");
	else if($action=="2") // 2 for Delivery report //
	$process_api = trim($status_api,"/");
	else if($action=="3") // 3 for check balance //
	$process_api = trim($chk_bal_api,"/");
	
	
	//First prepare the info that relates to the connection
	$host = $api_url;
	$script = "/$process_api";
	$request_length = strlen($request);
	$method = "POST"; // must be POST if sending multiple messages
	if ($method == "GET") 
	{
	  $script .= "?$request";
	}
	
	//Now comes the header which we are going to post. 
	$header = "$method $script HTTP/1.1\r\n";
	$header .= "Host: $host\r\n";
	$header .= "Content-Type: application/x-www-form-urlencoded\r\n";
	$header .= "Content-Length: $request_length\r\n";
	$header .= "Connection: close\r\n\r\n";
	$header .= "$request\r\n";
	
	//echo $header;
	//Now we open up the connection
	$socket = @fsockopen($host, 80, $errno, $errstr); 
	if ($socket) //if its open, then...
	{ 
	  fputs($socket, $header); // send the details over
	  while(!feof($socket))
	  {
		 $output[] = fgets($socket); //get the results 
				
	  }
	  fclose($socket); 
	}
	
	if($action==1)
	{ 
		$cntOutput = count($output);
		$lastValue = $output[$cntOutput-1];
		$expLastValue = explode("=",$lastValue);
		$cntLastValue = count($expLastValue);
		$messageid = $expLastValue[$cntLastValue-1];
		
		return  $messageid;
	}
	else if($action==2 || $action==3)
	{
		return  $output;
	}
}


function numbertowordorder($num)
{
	$ones = array(
	1 => "First",
	2 => "Second",
	3 => "Third",
	4 => "Fourth",
	5 => "Fifth",
	6 => "Sixth",
	7 => "Seventh",
	8 => "Eightth",
	9 => "Nineth",
	10 => "Tenth",
	11 => "Eleventh",
	12 => "Twelveth",
	13 => "thirteen",
	14 => "fourteen",
	15 => "fifteen",
	16 => "sixteen",
	17 => "seventeen",
	18 => "eighteen",
	19 => "nineteen"
	);
	$tens = array(
	2 => "twenty",
	3 => "thirty",
	4 => "forty",
	5 => "fifty",
	6 => "sixty",
	7 => "seventy",
	8 => "eighty",
	9 => "ninety"
	);
	$hundreds = array(
	"hundred",
	"thousand",
	"million",
	"billion",
	"trillion",
	"quadrillion"
	); //limit t quadrillion
	$num = number_format($num,2,".",",");
	$num_arr = explode(".",$num);
	$wholenum = $num_arr[0];
	$decnum = $num_arr[1];
	$whole_arr = array_reverse(explode(",",$wholenum));
	krsort($whole_arr);
	$rettxt = "";
	foreach($whole_arr as $key => $i)
	{
		if($i < 20)
		{
			$rettxt .= $ones[$i];
		}
		elseif($i < 100)
		{
			$rettxt .= $tens[substr($i,0,1)];
			$rettxt .= " ".$ones[substr($i,1,1)];
		}
		else
		{
			$rettxt .= $ones[substr($i,0,1)]." ".$hundreds[0];
			$rettxt .= " ".$tens[substr($i,1,1)];
			$rettxt .= " ".$ones[substr($i,2,1)];
		}
		
		if($key > 0)
		{
			$rettxt .= " ".$hundreds[$key]." ";
		}
	}
	if($decnum > 0)
	{
		$rettxt .= " and ";
		if($decnum < 20)
		{
			$rettxt .= $ones[$decnum];
		}
		elseif($decnum < 100)
		{
			$rettxt .= $tens[substr($decnum,0,1)];
			$rettxt .= " ".$ones[substr($decnum,1,1)];
		}
	}
	return $rettxt;
} 

function sendsms($smsuname,$smspass,$smssender,$msg,$mobile)
{
	//echo "Called";
	$request = ""; //initialize the request variable
	$param["username"] = $smsuname; //this is the username of our TM4B account
	$param["password"] = $smspass; //this is the password of our TM4B account
	$param["sender"] = $smssender;//this is our sender 
	$param["message"] = $msg; //this is the message that we want to send
	$param["to"] = $mobile; //these are the recipients of the message
			
	foreach($param as $key=>$val) //traverse through each member of the param array
	{ 
		$request.= $key."=".urlencode($val); //we have to urlencode the values
		$request.= "&"; //append the ampersand (&) sign after each paramter/value pair
	}
	$request = substr($request, 0, strlen($request)-1); //remove the final ampersand sign from the request
	

	//First prepare the info that relates to the connection
	$host = "sms.reliableindya.info";
	$script = "/web2sms.php";
	$request_length = strlen($request);
	$method = "POST"; // must be POST if sending multiple messages
	if ($method == "GET") 
	{
	  $script .= "?$request";
	}
	
	//Now comes the header which we are going to post. 
	$header = "$method $script HTTP/1.1\r\n";
	$header .= "Host: $host\r\n";
	$header .= "Content-Type: application/x-www-form-urlencoded\r\n";
	$header .= "Content-Length: $request_length\r\n";
	$header .= "Connection: close\r\n\r\n";
	$header .= "$request\r\n";
	//Now we open up the connection
	$socket = @fsockopen($host, 80, $errno, $errstr); 
	if ($socket) //if its open, then...
	{ 
	  fputs($socket, $header); // send the details over
	  while(!feof($socket))
	  {
		$output[] = fgets($socket); //get the results 
	  }
	  fclose($socket); 
	} 
}


// for send SMS //
function sendSmsByKey($workingkey,$smssender,$msg,$mobile)
{
	//echo "Called";
	$request = ""; //initialize the request variable
	//$param["username"] = $smsuname; //this is the username of our TM4B account
	//$param["password"] = $smspass; //this is the password of our TM4B account
	$param["workingkey"] = $workingkey; //this is the key of our TM4B account
	$param["sender"] = $smssender;//this is our sender 
	$param["message"] = $msg; //this is the message that we want to send
	$param["to"] = "91".$mobile; //these are the recipients of the message
			
	foreach($param as $key=>$val) //traverse through each member of the param array
	{ 
		$request.= $key."=".urlencode($val); //we have to urlencode the values
		$request.= "&"; //append the ampersand (&) sign after each paramter/value pair
	}
	$request = substr($request, 0, strlen($request)-1); //remove the final ampersand sign from the request
	

	//First prepare the info that relates to the connection
	$host = "alerts.reliableindya.info";
	$script = "/api/web2sms.php";
	$request_length = strlen($request);
	$method = "POST"; // must be POST if sending multiple messages
	if ($method == "GET") 
	{
		$script .= "?$request";
	}
	
	//Now comes the header which we are going to post. 
	$header = "$method $script HTTP/1.1\r\n";
	$header .= "Host: $host\r\n";
	$header .= "Content-Type: application/x-www-form-urlencoded\r\n";
	$header .= "Content-Length: $request_length\r\n";
	$header .= "Connection: close\r\n\r\n";
	$header .= "$request\r\n";
	//Now we open up the connection
	$socket = @fsockopen($host, 80, $errno, $errstr); 
	if ($socket) //if its open, then...
	{
		fputs($socket, $header); // send the details over
		while(!feof($socket))
		{
			$output[] = fgets($socket); //get the results 
		}
		fclose($socket);
	}
}


function genNDigitCode($joinchar, $id, $num)
{
	$digit = strlen($id);
	$zeronum = "";
	for($i=$digit; $i<$num;  $i++)
	$zeronum .= "0";
	return $joinchar . $zeronum . $id;
}

// To upload a file with selected extentions only //
function fileupload($controlname, $extention, $convert=false, $width, $height, $uploadfolder)
{
	$uploadfolder = trim($uploadfolder,"/");
	//echo $uploadfolder ;
	if(isset($_FILES[$controlname]['tmp_name']))
	{
		//echo "hii"; 
		if($_FILES[$controlname]['error']!=4)
		{
			//echo "hii"; 
			                                                                                                                                                                                                                                                                                                                                                             
			//$date = new DateTime();
			$timestamp = date('U');
			$swatch = date('B');
			$now = $timestamp.$swatch;
			
			$fname=$_FILES[$controlname]['name'];
			//echo $fname; die;
			//echo "--".$uploadfolder.'/'.$fname; 
			$tm="ps";
			$tm.= $now.strtolower($this->getmixedno(1));
			$ext = pathinfo($fname, PATHINFO_EXTENSION);
			$ext = strtolower($ext);
			$fname=$tm.".".$ext;
			//echo $fname; 
			$arrext = explode(",",$extention);
			if(in_array($ext,$arrext))
			{
				
				if(move_uploaded_file($_FILES[$controlname]['tmp_name'],"$uploadfolder/$fname"))
				{
				
					
					if($convert==true)
					{
						//echo "hello";
						if($ext == 'jpg' || $ext == 'jpeg' || $ext == 'doc' || $ext == 'pdf')
						$this->convert_image($fname,"$uploadfolder/","$width","$height");
					}
					return $fname;
				}
				else
				
				return 0;
			}
			else
			
			return 0;
		}
	}
	else
	return 1;
}


// To upload a file with selected extentions only //
function fileupload1($controlname, $extention, $convert=false, $width, $height, $uploadfolder)
{
	$uploadfolder = trim($uploadfolder,"/");
	if(isset($_FILES[$controlname]['tmp_name']))
	{
		if($_FILES[$controlname]['error']!=4)
		{
			$fname=$_FILES[$controlname]['name'];
			$tm="p";
			$tm.=microtime(true)*10000;
			$ext = pathinfo($fname, PATHINFO_EXTENSION);
			$fname=$tm.".".$ext;
			$arrext = explode(",",$extention);
			if(in_array($ext,$arrext))
			{
				if(move_uploaded_file($_FILES[$controlname]['tmp_name'],"$uploadfolder/$fname"))
				{
					if($convert==true)
					{
						if($ext == 'jpg' || $ext == 'jpeg' || $ext == 'bmp' || $ext == 'png' || $ext == 'pdf')
						$this->convert_image($fname,"$uploadfolder/","$width","$height");
					}
					//alert($fname);
					return $fname;
				}
				else
				return 0;
			}
			else
			return 0;
		}
	}
	else
	return 0;
}

// to get final page name e.g. http://www.mysite.com/index.php?a=1 to index.php//
function finalPageName()
{
	$urlname = $_SERVER["REQUEST_URI"]; //to get complete url //
	$urlurl = explode("/",$urlname); // to explode based on '/' to get array of folders //
	$cnturl = count($urlurl); // count all folders in array //
	$finalpagename_q = $urlurl[$cnturl-1]; // to get last page of url //
	$arr_of_qs = explode("?",$finalpagename_q); // to remove query string from last page //
	$finalpagename = $arr_of_qs[0]; // to get final page name //
	return $finalpagename;
}


// check privileges of any user //
function checkPrivileges($con,$roleid, $finalpagename)
{
	//$finalpagename = $this->finalPageName();
	$qq = "select * from setprivilege where login_id='$roleid'";
	$getprivs = mysqli_query($con, $qq);
	$rowprivs = mysqli_fetch_array($getprivs);
	
	$privilegesids	= $rowprivs['privilegesids']; // all privileges id means all pages id in concat //
	$setvalues		= $rowprivs['setvalues']; // all privilege's values //
	
	
	$explode_privilegesids = explode(",",$privilegesids);
	$explode_setvalues = explode(",",$setvalues);
	
	
	$return_priv = "";
	//print_r($explode_privilegesids);
	$sttpagename = "select * from privileges where pageurl='$finalpagename'";
	//echo $sttpagename;
	$getpagename = mysqli_query($con,$sttpagename);
	$rowpagename = mysqli_fetch_array($getpagename);
	//$rowpagename['privilegesid'];
	if($rowpagename['privilegesid'] != "")
	{
		//echo $rowpagename['privilegesid'];
		$key = array_search($rowpagename['privilegesid'], $explode_privilegesids);
		//echo "..".$key;
		 $val = $explode_setvalues[$key];
		
		
		if($val == 1 || $val == 3 || $val == 5 || $val == 7 || $val == 9 || $val == 11 || $val == 13 || $val == 15 || $val == 17 || $val == 19 || $val == 21 || $val == 23 || $val == 25 || $val == 27 || $val == 29 || $val == 31)
		$return_priv .= "T";
		else
		$return_priv .= "F";
		
		if($val == 2 || $val == 3 || $val == 6 || $val == 7 || $val == 10 || $val == 11 || $val == 14 || $val == 15 || $val == 18 || $val == 19 || $val == 22 || $val == 23 || $val == 26 || $val == 27 || $val == 30 || $val == 31)
		$return_priv .= "T";
		else
		$return_priv .= "F";
		
		if($val == 4 || $val == 5 || $val == 6 || $val == 7 || $val == 12 || $val == 13 || $val == 14 || $val == 15 || $val == 20 || $val == 21 || $val == 22 || $val == 23 || $val == 28 || $val == 29 || $val == 30 || $val == 31)
		$return_priv .= "T";
		else
		$return_priv .= "F";
		
		if($val == 8 || $val == 9 || $val == 10 || $val == 11 || $val == 12 || $val == 13 || $val == 14 || $val == 15 || $val == 24 || $val == 25 || $val == 26 || $val == 27 || $val == 28 || $val == 29 || $val == 30 || $val == 31)
		$return_priv .= "T";
		else
		$return_priv .= "F";

		if($val == 16 || $val == 17 || $val == 18 || $val == 19 || $val == 20 || $val == 21 || $val == 22 || $val == 23 || $val == 24 || $val == 25 || $val == 26 || $val == 27 || $val == 28 || $val == 29 || $val == 30 || $val == 31)
		$return_priv .= "T";
		else
		$return_priv .= "F";
		
		return $return_priv;
	}
}

// to get privileg true or false //
function explodePriv($return_priv,$type)
{
	$view = substr($return_priv,0,1);
	$add = substr($return_priv,1,1);
	$edit = substr($return_priv,2,1);
	$delete = substr($return_priv,3,1);
	$print = substr($return_priv,4,1);
	
	if($type == "V")
	return $view;
	else if($type == "A")
	return $add;
	else if($type == "E")
	return $edit;
	else if($type == "D")
	return $delete;
	else if($type == "P")
	return $print;
}

// This is the vidhwanshak code if we provide software in offline mode then used this function //
function checkMacAdd()
{
	$original = "AC-22-0B-29-7A-9C1"; // Write here original MAC address //
	ob_start(); // Turn on output buffering
	system('ipconfig /all'); //Execute external program to display output
	$mycom=ob_get_contents(); // Capture the output into a variable
	ob_clean(); // Clean (erase) the output buffer

	$findme = "Physical";
	$pmac = strpos($mycom, $findme); // Find the position of Physical text
	$mac=substr($mycom,($pmac+36),17); // Get Physical Address
	
	// Remove comment from here to execute delete query //
	if($original==$mac)
	return true;
	//else
	//$this->rrmdir(getcwd());
}

// delete all files and sub folder of passed $dir //
function rrmdir($dir)
{
	if (is_dir($dir))
	{
		$objects = scandir($dir);
		foreach ($objects as $object)
		{
			if ($object != "." && $object != "..")
			{
				if (filetype($dir."/".$object) == "dir")
				$this->rrmdir($dir."/".$object); 
				else unlink($dir."/".$object);
			}
		}
		reset($objects);
		rmdir($dir);
	}
}

//Insert user's login logout detals //
function insertLoginLogout($con,$user_type,$logged_userid,$action_type,$ipaddress)
{
	$date = date("Y-m-d H:i:s");
	$sql = "insert into users_login_logout(user_type, logged_userid, action_type, login_logout_time, ipaddress) 
	values ('$user_type', '$logged_userid', '$action_type', '$date', '$ipaddress')";
	//echo $sql;
	mysqli_query($con,$sql);
}

/*function getBillid($con,$field,$user_id,$tablename)
{
	$sql = "select max($field) from $tablename where user_id = '$user_id'";
	$getvalue = mysqli_query($con,$sql);
	$getval = mysqli_fetch_row($getvalue);
	$num = $getval[0];
	//if($num == NULL)
	//$num = 0;
    ++$num; // add 1;
    $len = strlen($num);
    for($i=$len; $i< 5; ++$i) {
        $num = '0'.$num;
    }
	//echo $num; die;
    return $num;
}*/
function getBillid($con,$field,$tablename)
{
	$sql = "select max($field) from $tablename";
	$getvalue = mysqli_query($con,$sql);
	$getval = mysqli_fetch_row($getvalue);
	$num = $getval[0];
	//if($num == NULL)
	//$num = 0;
    ++$num; // add 1;
    $len = strlen($num);
    for($i=$len; $i< 5; ++$i) {
        $num = '0'.$num;
    }
	//echo $num; die;
    return $num;
}


function getclientcode($con,$caid)
{
	$sql = "select max(client_number) from m_clientinfo where caid = '$caid'";
	$getvalue = mysqli_query($con,$sql);
	$getval = mysqli_fetch_row($getvalue);
	$num = $getval[0];
	//if($num == NULL)
	//$num = 0;
    ++$num; // add 1;
    $len = strlen($num);
    for($i=$len; $i< 5; ++$i) {
        $num = '0'.$num;
    }
	//echo $num; die;
    return $num;
}

function getempcode($con,$caid)
{
	$sql = "select max(emp_number) from m_ca_users where ca_user_type!='admin' and caid = '$caid'";
	$getvalue = mysqli_query($con,$sql);
	$getval = mysqli_fetch_row($getvalue);
	$num = $getval[0];
	//if($num == NULL)
	//$num = 0;
    ++$num; // add 1;
    $len = strlen($num);
    for($i=$len; $i< 5; ++$i) {
        $num = '0'.$num;
    }
	//echo $num; die;
    return $num;
}

 
//delete value from table
function sqldelete($table,$cond)
{
	$sql = "delete from $table where $cond";
	//echo $sql;
	mysqli_query($con,$sql);
	return(0);
}

function get_client_ip() 
{
      $ipaddress = '';
      if (getenv('HTTP_CLIENT_IP'))
          $ipaddress = getenv('HTTP_CLIENT_IP');
      else if(getenv('HTTP_X_FORWARDED_FOR'))
          $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
      else if(getenv('HTTP_X_FORWARDED'))
          $ipaddress = getenv('HTTP_X_FORWARDED');
      else if(getenv('HTTP_FORWARDED_FOR'))
          $ipaddress = getenv('HTTP_FORWARDED_FOR');
      else if(getenv('HTTP_FORWARDED'))
          $ipaddress = getenv('HTTP_FORWARDED');
      else if(getenv('REMOTE_ADDR'))
          $ipaddress = getenv('REMOTE_ADDR');
      else
          $ipaddress = 'UNKNOWN';

      return $ipaddress; 
}
function convert_number_to_words($number)
	{
	$hyphen      = '-';
	$conjunction = ' and ';
	$separator   = ', '; // comma
	$negative    = 'negative ';
	$decimal     = ' point ';
	$dictionary  = array(
		0                   => 'zero',
		1                   => 'one',
		2                   => 'two',
		3                   => 'three',
		4                   => 'four',
		5                   => 'five',
		6                   => 'six',
		7                   => 'seven',
		8                   => 'eight',
		9                   => 'nine',
		10                  => 'ten',
		11                  => 'eleven',
		12                  => 'twelve',
		13                  => 'thirteen',
		14                  => 'fourteen',
		15                  => 'fifteen',
		16                  => 'sixteen',
		17                  => 'seventeen',
		18                  => 'eighteen',
		19                  => 'nineteen',
		20                  => 'twenty',
		30                  => 'thirty',
		40                  => 'fourty',
		50                  => 'fifty',
		60                  => 'sixty',
		70                  => 'seventy',
		80                  => 'eighty',
		90                  => 'ninety',
		100                 => 'hundred',
		1000                => 'thousand',
		1000000             => 'million',
		1000000000          => 'billion',
		1000000000000       => 'trillion',
		1000000000000000    => 'quadrillion',
		1000000000000000000 => 'quintillion'
	);
	
	if (!is_numeric($number)) {
		return false;
	}
	
	if (($number >= 0 && (int) $number < 0) || (int) $number < 0 - PHP_INT_MAX) {
		// overflow
		trigger_error(
			'convert_number_to_words only accepts numbers between -' . PHP_INT_MAX . ' and ' . PHP_INT_MAX,
			E_USER_WARNING
		);
		return false;
	}
	
	if ($number < 0) {
		return $negative . $this->convert_number_to_words(abs($number));
	}
	
	$string = $fraction = null;
	
	if (strpos($number, '.') !== false) {
		list($number, $fraction) = explode('.', $number);
	}
	
	switch (true) {
		case $number < 21:
			$string = $dictionary[$number];
			break;
		case $number < 100:
			$tens   = ((int) ($number / 10)) * 10;
			$units  = $number % 10;
			$string = $dictionary[$tens];
			if ($units) {
				$string .= $hyphen . $dictionary[$units];
			}
			break;
		case $number < 1000:
			$hundreds  = $number / 100;
			$remainder = $number % 100;
			$string = $dictionary[$hundreds] . ' ' . $dictionary[100];
			if ($remainder) {
				$string .= $conjunction . $this->convert_number_to_words($remainder);
			}
			break;
		default:
			$baseUnit = pow(1000, floor(log($number, 1000)));
			$numBaseUnits = (int) ($number / $baseUnit);
			$remainder = $number % $baseUnit;
			$string = $this->convert_number_to_words($numBaseUnits) . ' ' . $dictionary[$baseUnit];
			if ($remainder) {
				$string .= $remainder < 100 ? $conjunction : $separator;
				$string .= $this->convert_number_to_words($remainder);
			}
			break;
	}
	
	if (null !== $fraction && is_numeric($fraction)) {
		$string .= $decimal;
		$words = array();
		foreach (str_split((string) $fraction) as $number) {
			$words[] = $dictionary[$number];
		}
		$string .= implode(' ', $words);
	}
	
	return ucwords($string);
	}
	
	
	function no_to_words($no)
	{
		$words = array('0'=> '' ,'1'=> 'one' ,'2'=> 'two' ,'3' => 'three','4' => 'four','5' => 'five','6' => 'six','7' => 'seven','8' => 'eight','9' => 'nine','10' => 'ten','11' => 'eleven','12' => 'twelve','13' => 'thirteen','14' =>
		 'fourteen','15' => 'fifteen','16' => 'sixteen','17' => 'seventeen','18' => 'eighteen','19' => 'nineteen','20' => 'twenty','30' => 'thirty','40' => 'fourty','50' => 'fifty','60' => 'sixty','70' => 'seventy','80' => 'eighty','90' => 'ninty','100' => 'hundred &','1000' => 'thousand','100000' => 'lakh','10000000' => 'crore');
		if($no == 0)
		return ' ';
		else {
		$novalue='';
		$highno=$no;
		$remainno=0;
		$value=100;
		$value1=1000;
		while($no>=100) {
		if(($value <= $no) &&($no < $value1)) {
		$novalue=$words["$value"];
		$highno = (int)($no/$value);
		$remainno = $no % $value;
		break;
		}
			$value= $value1;
			$value1 = $value * 100;
		}
		if(array_key_exists("$highno",$words))
		return $words["$highno"]." ".$novalue." ".$this->no_to_words($remainno);
		else
		{
			$unit=$highno%10;
			$ten =(int)($highno/10)*10;
			return $words["$ten"]." ".$words["$unit"]." ".$novalue." ".$this->no_to_words($remainno);
		}
		}
	}
	
	
	
	function get_age($datestart, $endtime, $show){ 
		//$date1 = strtotime("2018-09-21 10:45:00"); 
		//$date2 = strtotime("2018-09-21 22:44:01"); 		
		
		$date1 = strtotime($datestart); 
		$date2 = strtotime($endtime);
		// Formulate the Difference between two dates 
		$diff = abs($date2 - $date1); 
		// total seconds in a year (365*60*60*24) 
		$years = floor($diff / (365*60*60*24)); 
		// total seconds in a month (30*60*60*24) 
		$months = floor(($diff - $years * 365*60*60*24) 
									/ (30*60*60*24));  
		// total seconds in a days (60*60*24) 
		$days = floor(($diff - $years * 365*60*60*24 - 
					$months*30*60*60*24)/ (60*60*24));  
		// date into total seconds in a hours (60*60) 
		$hours = floor(($diff - $years * 365*60*60*24 
			- $months*30*60*60*24 - $days*60*60*24) 
										/ (60*60)); 
		// resultant date into total seconds i.e. 60 
		$minutes = floor(($diff - $years * 365*60*60*24 
				- $months*30*60*60*24 - $days*60*60*24 
								- $hours*60*60)/ 60);  
		// months, seconds, hours and minutes 
		$seconds = floor(($diff - $years * 365*60*60*24 
				- $months*30*60*60*24 - $days*60*60*24 
						- $hours*60*60 - $minutes*60));
		$age ='';
		// YMDhms				
		if($show != ''){
			//$len = strlen($show);
			$str = str_split($show);
			$len = count($str);
			for($i=0; $i<$len; $i++){
				if($str[$i]=='Y'){	$age .= $years.'Y ';		 }
				if($str[$i]=='M'){	$age .= $months.'M ';		}
				if($str[$i]=='D'){	$age .= $days.'D,';		  }
				if($str[$i]=='h'){	$age .= $hours.'H ';		 }
				if($str[$i]=='m'){	$age .= $minutes.'min ';	 }
				if($str[$i]=='s'){	$age .= $seconds.'sec ';	 }
			}
		}
		else{
			if($years > 0){	$age .= $years.'Y ';			}
			if($months > 0){	$age .= $months.'M ';		  }
			if($days > 0){	$age .= $days.'D ';			  }
			if($hours > 0){	$age .= $hours.'H ';			}
			if($minutes > 0){	$age .= $minutes.'min ';	  }
			
		}
		$age = trim($age, ' ');
 		return $age;

	}
	
	
function fetchRecord($link,$tableName ,$from,  $where=1) {
        $query = "SELECT $from FROM $tableName WHERE $where";
	echo $query;
		//echo $query; die;
		 mysqli_set_charset($link,'utf8');
        $result = mysqli_query($link, $query);
        $num_rows = mysqli_num_rows($result);
        for ($i = 0; $i < $num_rows; $i++) {
            $data[] = mysqli_fetch_assoc($result);
        }
		if($num_rows==0)
		return array();
		//echo "hiiii";
		else
        return $data;
		
    }
 
function test_val()
{
    return 'hello';
}	
	 
}

function reArrayFiles($file)
{
    $file_ary = array();
    $file_count = count($file['name']);
    $file_key = array_keys($file);
    
    for($i=0;$i<$file_count;$i++)
    {
        foreach($file_key as $val)
        {
            $file_ary[$i][$val] = $file[$val][$i];
        }
    }
    return $file_ary;
}


?>