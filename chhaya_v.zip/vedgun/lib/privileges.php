<?php
/*
*
*
*/
class setPriv {

function drawPrivForm($showSubMenu = false, $tblname,$con) 
{
	
	
// *********** save coding *********** //
if(isset($_POST['sub']))
{
	$date = date("Y-m-d H:i:s");
	$privid = implode(",",$_POST['privid']);
	$preval = implode(",",$_POST['preval']);
	$login_id = $_POST['login_id'];
	
	$getalready = mysqli_query($con,"select * from setprivilege where login_id='$login_id'");
	if(mysqli_num_rows($getalready) == 0)
	{
		$stt = "insert into setprivilege(login_id, privilegesids, setvalues, enable, createdate) values('$login_id','$privid', '$preval', 1, '$date')";
		mysqli_query($con,$stt);
	}
	else
	{
		$stt = "update setprivilege set privilegesids='$privid', setvalues='$preval' where login_id='$login_id'";
		mysqli_query($con,$stt);
	}
	echo "<script>location='privilege.php'</script>";
}

?>

<style>
.tdforhover {
    line-height: 2em;
    background-color: #FFF;
	border:1px solid #069;
	padding:5px;
}
/*.trhover:hover {
    color: #fff;
    background-color: #666;
}

.trhover:hover td {
    background-color: transparent;
}*/
</style>

<script>
function funCheckLine(modulename,checktype,num)
{
	var chkbox = document.getElementsByTagName('input');
	var totalnum = chkbox.length;

	if(document.getElementById(modulename+checktype+num).checked==true)
	{
		var trueorfalse = true;
		var totalval = 31;
	}
	else
	{
		var trueorfalse = false;
		var totalval = 0;
	}
	
	if(num == 0)
	{
		for(i=0; i<=totalnum; i++)
		{
			if(checktype=='l')
			{
				if(document.getElementById(modulename+'a'+i))
				document.getElementById(modulename+'a'+i).checked=trueorfalse;
				if(document.getElementById(modulename+'e'+i))
				document.getElementById(modulename+'e'+i).checked=trueorfalse;
				if(document.getElementById(modulename+'d'+i))
				document.getElementById(modulename+'d'+i).checked=trueorfalse;
				if(document.getElementById(modulename+'v'+i))
				document.getElementById(modulename+'v'+i).checked=trueorfalse;
				if(document.getElementById(modulename+'l'+i))
				document.getElementById(modulename+'l'+i).checked=trueorfalse;

				if(document.getElementById(modulename+'p'+i))
				document.getElementById(modulename+'p'+i).checked=trueorfalse;
				
				if(document.getElementById(modulename+'val'+i))
				document.getElementById(modulename+'val'+i).value=totalval;
			}
			else
			{
				if(document.getElementById(modulename+checktype+i))
				{
					if(document.getElementById(modulename+checktype+i).checked!=trueorfalse)
					{
						document.getElementById(modulename+checktype+i).checked=trueorfalse;
					
						if(document.getElementById(modulename+'val'+i))
						{
							var chkvalue = document.getElementById(modulename+checktype+i).value;
							var prevval = document.getElementById(modulename+'val'+i).value
						
							var lastvalue = 0;
							if(trueorfalse == true)
							lastvalue = parseInt(prevval) + parseInt(chkvalue);
							else
							lastvalue = parseInt(prevval) - parseInt(chkvalue);
							
							document.getElementById(modulename+'val'+i).value = lastvalue;
						}
					}
					
				}
			}
		}
	}
	else
	{
		if(checktype=='l')
		{
			document.getElementById(modulename+'a'+num).checked=trueorfalse;
			document.getElementById(modulename+'e'+num).checked=trueorfalse;
			document.getElementById(modulename+'d'+num).checked=trueorfalse;
			document.getElementById(modulename+'v'+num).checked=trueorfalse;
			document.getElementById(modulename+'p'+num).checked=trueorfalse;
			document.getElementById(modulename+'val'+num).value=totalval;
		}
		else
		{
			var chkvalue = document.getElementById(modulename+checktype+num).value;
			var prevval = document.getElementById(modulename+'val'+num).value
		
			var lastvalue = 0;
			if(trueorfalse == true)
			lastvalue = parseInt(prevval) + parseInt(chkvalue);
			else
			lastvalue = parseInt(prevval) - parseInt(chkvalue);
			
			document.getElementById(modulename+'val'+num).value = lastvalue;
		}
	}
}

</script>


<form action="" method="post">
<?php
if(isset($_REQUEST['login_id']))
{
	$login_id = $_REQUEST['login_id'];
	$usertype1=$_REQUEST['usertype'];
	$usertype=strtoupper($usertype1);

    //echo "select * from setprivilege where login_id = '$login_id'";
	$getsetpriv = mysqli_query($con,"select * from setprivilege where login_id ='$login_id'");
	$rowsetpriv = mysqli_fetch_array($getsetpriv);
	$privilegesids = explode(",",$rowsetpriv['privilegesids']);
	$setvalues = explode(",",$rowsetpriv['setvalues']);
	
	$combinearr = array_combine($privilegesids,$setvalues);

	
	 $sqlgetmaster="select * from $tblname order by menu, pagename";
	?><div class="row" align="center"><h1><?php echo $usertype; ?></h1></div><?php 
	
	//echo $sqlgetmaster;
	$resgetmaster=mysqli_query($con,$sqlgetmaster);
	
	$slno=1;
	$menu = "";
	$submenu = "";
	$showHeader = "yes";
	$alpha = "";
	while($allprev=mysqli_fetch_array($resgetmaster))
	{
		if($slno == 1)
		$menu = $allprev['menu'];
		
		if($menu == $allprev['menu'] and $slno == 1)
		{
			$showHeader = "yes";
			$alpha = "a";
		}
		else if($menu != $allprev['menu'])
		{
			echo "</table><br><br>";
			$showHeader = "yes";
			$menu = $allprev['menu'];
			$slno = 1;
			$alpha++;
		}
		else
		{
			$showHeader = "no";
		}
	
		
		if($showHeader == "yes")
		{
			if($showSubMenu == true)
			$colspan = 5;
			else
			$colspan = 4;
	?>
			<table id="example1" class="table table-bordered table-striped">
			<tr class="trhover">
			<th colspan="<?php echo $colspan; ?>" style="background-color:#0080C0; color:#FFF; font-weight:bold" class="tdforhover"><?php echo $menu; ?></th>
			</tr>
			
			<tr align="center">
			<th width="10%" class="tdforhover">Slno</th>
			<?php if($showSubMenu == true) { ?><th width="20%" class="tdforhover">Sub Menu</th><?php } ?>
			<th width="20%" class="tdforhover">Page Name</th>
			<th width="40%" align="left" class="tdforhover">
			<label style="float:left; width:16%; font-weight:bold">
			<input type="checkbox" id="<?php echo $alpha,'v0'; ?>" value="1" onClick="funCheckLine('<?php echo $alpha; ?>','v',0)"> View</label>
				
			<label style="float:left; width:16%; font-weight:bold">
			<input type="checkbox" id="<?php echo $alpha,'a0'; ?>" value="2" onClick="funCheckLine('<?php echo $alpha; ?>','a',0)"> Add</label>
			
			<label style="float:left; width:16%; font-weight:bold">
			<input type="checkbox" id="<?php echo $alpha,'e0'; ?>" value="4" onClick="funCheckLine('<?php echo $alpha; ?>','e',0)"> Edit</label>
			
			<label style="float:left; width:16%; font-weight:bold">
			<input type="checkbox" id="<?php echo $alpha,'d0'; ?>" value="8" onClick="funCheckLine('<?php echo $alpha; ?>','d',0)"> Delete</label>
			
			<label style="float:left; width:16%; font-weight:bold">
			<input type="checkbox" id="<?php echo $alpha,'p0'; ?>" value="16" onClick="funCheckLine('<?php echo $alpha; ?>','p',0)"> Print</label>

			<label style="float:left; width:16%; font-weight:bold">
			<input type="checkbox" id="<?php echo $alpha,'l0'; ?>" value="All" onClick="funCheckLine('<?php echo $alpha; ?>','l',0)"> All</label>

			<div style="clear:both"></div>
			</th>
			<th width="10%" style="display:none">Others</th>
			</tr>
	<?php 
		}
		
		// fetch and view records if already exists //
		$srchval = 0;
		
		$shv = 0;
		$sha = 0;
		$she = 0;
		$shd = 0;		
		$shp = 0;
		
		if(array_key_exists($allprev['privilegesid'],$combinearr))
		{
			$srchval = $combinearr[$allprev['privilegesid']];
		}
		
		//echo $srchval."-";
		
		switch ($srchval) 
		{
			case 1:
				$shp = 0;
				$shv = 1;
				$sha = 0;
				$she = 0;
				$shd = 0;
				break;
				
			case 2:
				$shp = 0;
				$shv = 0;
				$sha = 1;
				$she = 0;
				$shd = 0;
				break;
				
			case 3:
				$shp = 0;
				$shv = 1;
				$sha = 1;
				$she = 0;
				$shd = 0;
				break;
			
			case 4:
				$shp = 0;
				$shv = 0;
				$sha = 0;
				$she = 1;
				$shd = 0;
				break;
				
			case 5:
				$shp = 0;
				$shv = 1;
				$sha = 0;
				$she = 1;
				$shd = 0;
				break;
				
			case 6:
				$shp = 0;
				$shv = 0;
				$sha = 1;
				$she = 1;
				$shd = 0;
				break;
			
			case 7:
				$shp = 0;
				$shv = 1;
				$sha = 1;
				$she = 1;
				$shd = 0;
				break;
				
			case 8:
				$shv = 0;
				$sha = 0;
				$she = 0;
				$shd = 1;
				break;
				
			case 9:
				$shp = 0;
				$shv = 1;
				$sha = 0;
				$she = 0;
				$shd = 1;
				break;
			
			case 10:
				$shp = 0;
				$shv = 0;
				$sha = 1;
				$she = 0;
				$shd = 1;
				break;
				
			case 11:
				$shp = 0;
				$shv = 1;
				$sha = 1;
				$she = 0;
				$shd = 1;		
				break;
				
			case 12:
				$shp = 0;
				$shv = 0;
				$sha = 0;
				$she = 1;
				$shd = 1;		
				break;
			
			case 13:
				$shp = 0;
				$shv = 1;
				$sha = 0;
				$she = 1;
				$shd = 1;		
				break;
				
			case 14:
				$shp = 0;
				$shv = 0;
				$sha = 1;
				$she = 1;
				$shd = 1;		
				break;
				
			case 15:
				$shp = 0;
				$shv = 1;
				$sha = 1;
				$she = 1;
				$shd = 1;		
				break;
			case 16:
				$shp = 1;
				$shv = 0;
				$sha = 0;
				$she = 0;
				$shd = 0;		
				break;
			case 17:
				$shp = 1;
				$shv = 0;
				$sha = 0;
				$she = 0;
				$shd = 1;		
				break;
			case 18:
				$shp = 1;
				$shv = 0;
				$sha = 0;
				$she = 1;
				$shd = 0;		
				break;
			case 19:
				$shp = 1;
				$shv = 0;
				$sha = 0;
				$she = 1;
				$shd = 1;		
				break;
			case 20:
				$shp = 1;
				$shv = 0;
				$sha = 1;
				$she = 0;
				$shd = 0;		
				break;
			case 21:
				$shp = 1;
				$shv = 0;
				$sha = 1;
				$she = 0;
				$shd = 1;		
				break;
			case 22:
				$shp = 1;
				$shv = 0;
				$sha = 1;
				$she = 1;
				$shd = 0;		
				break;
			case 23:
				$shp = 1;
				$shv = 0;
				$sha = 1;
				$she = 1;
				$shd = 1;		
				break;
			case 24:
				$shp = 1;
				$shv = 1;
				$sha = 0;
				$she = 0;
				$shd = 0;		
				break;
			case 25:
				$shp = 1;
				$shv = 1;
				$sha = 0;
				$she = 0;
				$shd = 1;		
				break;
			case 26:
				$shp = 1;
				$shv = 1;
				$sha = 0;
				$she = 1;
				$shd = 0;		
				break;
			case 27:
				$shp = 1;
				$shv = 1;
				$sha = 0;
				$she = 1;
				$shd = 1;		
				break;
			case 28:
				$shp = 1;
				$shv = 1;
				$sha = 1;
				$she = 0;
				$shd = 0;		
				break;
			case 29:
				$shp = 1;
				$shv = 1;
				$sha = 1;
				$she = 0;
				$shd = 1;		
				break;
			case 30:
				$shp = 1;
				$shv = 1;
				$sha = 1;
				$she = 1;
				$shd = 0;		
				break;
			case 31:
				$shp = 1;
				$shv = 1;
				$sha = 1;
				$she = 1;
				$shd = 1;		
				break;			
					
		}
		
	?>
	
        <tr class="trhover">
        <td class="tdforhover" align="center"><?php echo $slno; ?></td>
       <?php if($showSubMenu == true) { ?><td class="tdforhover"><?php echo $allprev['submenu']; ?></td><?php } ?>
        <td class="tdforhover"><?php echo $allprev['pagename']; ?></td>
        <td class="tdforhover">
        <label style="float:left; width:16%;">
        <input type="checkbox" id="<?php echo $alpha,'v',$slno; ?>" value="1" onClick="funCheckLine('<?php echo $alpha; ?>','v',<?php echo $slno; ?>)" <?php if($shv==1) { ?>checked="checked" <?php } ?>> View</label>
            
        <label style="float:left; width:16%;">
        <input type="checkbox" id="<?php echo $alpha,'a',$slno; ?>" value="2" onClick="funCheckLine('<?php echo $alpha; ?>','a',<?php echo $slno; ?>)" <?php if($sha==1) { ?>checked="checked" <?php } ?>> Add</label>
        
        <label style="float:left; width:16%;">
        <input type="checkbox" id="<?php echo $alpha,'e',$slno; ?>" value="4" onClick="funCheckLine('<?php echo $alpha; ?>','e',<?php echo $slno; ?>)" <?php if($she==1) { ?>checked="checked" <?php } ?>> Edit</label>
        
        <label style="float:left; width:16%;">
        <input type="checkbox" id="<?php echo $alpha,'d',$slno; ?>" value="8" onClick="funCheckLine('<?php echo $alpha; ?>','d',<?php echo $slno; ?>)" <?php if($shd==1) { ?>checked="checked" <?php } ?>> Delete</label>

        <label style="float:left; width:16%; font-weight:bold">
			<input type="checkbox" id="<?php echo $alpha,'p',$slno; ?>" value="16" onClick="funCheckLine('<?php echo $alpha; ?>','p',<?php echo $slno; ?>)" <?php if($shp==1) { ?>checked="checked" <?php } ?>> Print</label>
        
        <label style="float:left; width:16%;">
        <input type="checkbox" id="<?php echo $alpha,'l',$slno; ?>" value="All" onClick="funCheckLine('<?php echo $alpha; ?>','l',<?php echo $slno; ?>)" <?php if($srchval==31) { ?>checked="checked" <?php } ?>> All</label>
        <div style="clear:both"></div>
        </td>
        <td style="display:none" class="tdforhover">
        <input type="text" name="privid[]" id="<?php echo $alpha,'pid',$slno; ?>" style="width:20px" value="<?php echo $allprev['privilegesid']; ?>" />
        <input type="text" name="preval[]" id="<?php echo $alpha,'val',$slno; ?>" style="width:20px" value="<?php echo $srchval; ?>" />
        </td>
        </tr>
	  
	<?php
		$slno++;
	}
	?>
	
    <tr class="trhover">
  <!--  <td class="tdforhover"></td>-->
    <?php if($showSubMenu == true) { ?><td class="tdforhover"></td><?php } ?>
    <td class="tdforhover"><input type="hidden" name="login_id" id="login_id" value="<?php echo $login_id; ?>" /></td>
    <td class="tdforhover"> </td>
    <td align="right" class="tdforhover">
    <input type="submit" name="sub" id="sub" value="Save" class="btn btn-primary" />
    </td>
    
    <td style="display:none" class="tdforhover"></td>
    </tr>

</table>
</form>


<?php
} // close if isset request roleid //
} // close function //

} // close class //

?>