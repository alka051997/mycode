<?php
 include('dbconnect.php');
  if($is_login){
    echo "<script> window.location='index.php';</script>";
  }
  if(isset($_POST['submit'])){
    $mobile=$_POST['mobile'];
    if($_POST['password'] != ''){
      $password=$_POST['password'];
      $qry = "SELECT * from ac_party_led where mobile='$mobile' and password = '$password' ";
    }else{
      $qry = "SELECT * from ac_party_led where (mobile='$mobile') ";
    }
    $rs=mysqli_query($con,$qry);
    if(mysqli_num_rows($rs)==1){
      $row = mysqli_fetch_array($rs);
      $_SESSION['username'] = $row['l_name'];
      $_SESSION['userid'] = $row['ledger_id'];
      $_SESSION['ref_sponsor_id'] = $row['ref_sponsor_id'];
      $_SESSION['mobile'] = $row['mobile'];
      $_SESSION['login'] = true;
      echo "<script> window.location='index.php';</script>";
    }else {
      echo "<script> window.location='login.php?error'</script>";
    }
  }
 ?>
<!Doctype html>
 <html lang="en-US"> 
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
  <head>
   <title>Buy Grocery Online | Daily Needs Supermarket - Vedgun</title> 
   <meta charset="utf-8"> <meta name="robots" content="INDEX,FOLLOW"> 
   <meta name="description" content="Vedgun - Choose and Buy Online Grocery from a wide range of fruits, vegetables, baby care products, personal care products and much more. Shop Now !" /> 
   <meta name="keywords" content="Online Grocery, Fruits &amp; Vegetables, Staples, Dairy, Packages Foods, Home care, Personal Care" />
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"> <meta property="og:site_name" content="Vedgun" /> 
    <meta property="og:type" content="website" /> 
    <meta property="og:title" content="Buy Grocery Online | Daily Needs Supermarket - Vedgun" />
     <meta property="og:description" content="Vedgun - Choose and Buy Online Grocery from a wide range of fruits, vegetables, baby care products, personal care products and much more. Shop Now !" />
      <meta property="og:url" content="index.php" /> 
      <meta property="og:image" content="assets/global/logo-fb.png" /> <!-- Appple Touch Icons --> 
     <meta name="google-play-app" content="app-id=com.jpl.Vedgun">
          <meta name="apple-itunes-app" content="app-id=1522085683">
           <meta name="theme-color" content="#ffffff"/> 
          <?php include('include/files.php');?>
<style> .multi-srch-hide{ display:none !important; } .ais-InfiniteHits-loadMore{ display:none; } .gift-page #saved_location{ display:none; } </style>
<link rel="manifest" href="manifest.json">
<style>
  .otc-product-page #first_desc h2 {display: none} .otc-product-page #first_desc h2.pname{display: block!important;}.catalog-category-view.level-3 .white-bg.msite-list, .catalog-category-view.level-0 .white-bg.msite-list{display:none !important} .cat-fashion .right-block .empty_listing {position:absolute;z-index:3} .compare_products{ display:none; }#bought_together{display:none !important}.prod-groceries #similar_products{display: none;} .prod-groceries .section-seperate1{display: none;} .prod-fashion .new_product #product_details #left_col .gallery-top,.prod-groceries .new_product #product_details #left_col .gallery-top{height: auto;} .gift-page .all-product .row product-list .col-md-3:last-child .price-box{display:none} .gift-page #free_gift_wrap{display:none !important} .best_deals .add_banner {margin: 0 auto;text-align: center;} .best_deals .add_banner img {width: auto;height: 100%;border-radius: 0;} .best_deals .section-seperate{display: none;} .prod-jewellery .brand_name{display:none !important} .prod-jewellery .prepaid_msg{display:block;font-size:14px;color:#dd0608;font-family: sans-serif;} .aa-dropdown-menu .aa-suggestions .aa-suggestion .product-item-info.search-jewellery a .drug_img { background: url(assets/version1605113383/smartweb/images/search_icons/search_jewellery.png) center no-repeat; background-size: 40px; } 
  .custreg-form  {
    background: #eee;
    border-radius: 16px;
    overflow: hidden;
    margin-top: 30px;
    padding: 20px;
}
  .ac-title{
    padding: 0;
    margin: 0 0 8px;
    font-family: sans-serif;
    font-size: 24px;
    color: #000;
  }
  .sign-txt{

    padding: 0 20px 16px!important;
    margin: 0!important;
  }
  .topcol{
    padding: 0 20px;
    
  }
  .md-form{
    margin: 1rem 0 24px;
    display: inline-block;
    width: 100%;
  }
  .singalotpcol{
    border: 1px solid rgba(0,0,0,.04);
    font-family: sans-serif;
    font-size: 14px;
    color: #000;
    padding: 9px 0 9px 12px;
    margin: 0;
    width: calc(100% - 3.5rem);
    border-radius: 4px;
  }
  .btn-login{
    background: #ff5722;
    font-family: sans-serif;
    font-size: 14px;
    color: #fff;
    line-height: 20px;
    border-radius: 4px;
    box-shadow: none!important;
    -webkit-box-shadow: none!important;
    -moz-box-shadow: none!important;
    letter-spacing: 1px;
    text-transform: capitalize;
    padding: 10px 6px;
    width: 100%;
    height: 100%;
    margin-top: 20;
    border: 0;
  }
  .left>h2{
    padding: 0;
    margin: 0 0 8px;
    font-family: sans-serif;
    font-size: 24px;
    color: #000;
    margin-bottom: 30px;
  }
   .content{
    background: #fff;
    width: 500px;
    padding: 20px;
  }
  .count-btn{
        background-color: #ff5722;
    padding: 10px;
    border-radius: 3px;
    margin-top: 20px;
    display: inline-block;
    color: #fff;
  }
  .regic{
    font-size: 16px;
    margin-top: 30px;
  }
</style>
</head>
<body class="cms-home Vedgun_home"> 
  <div class="page-wrapper"> 
    <?php include('include/header.php');?>
    <main>
      <div class="container">
        <div class="custloginmain"><!----><!----><!----><!---->
          <div class="custreg-form ">
            <div class="innermain row m-0">
              <div class="col-lg-6 leftcol p-0 d-none d-sm-block">

        <div class="left">
      <h2>New Customer</h2>
      <div class="content">
        <p><b>Register Account</b></p>
        <p class='regic'>By creating an account you will be able to shop faster, be up to date on an order's status, and keep track of the orders you have previously made.</p>
        <a class='count-btn' href="signup.php" class="button">Continue</a></div>
    </div>
              </div>
              <div class="col-lg-6 rightcol p-0 leftcol left">

                <h2 class="ac-title">Sign In</h2>
                <div class='content'>
                  <form method='POST' id="loginForm">
                    <div class="md-form position-relative">
                      <input autocomplete="off" class="form-control" name='mobile' id="mobile"  placeholder="Your Mobile No" type="text" maxlength="10" required >
                      <!-- <input autocomplete="off" class="form-control" name='mobile' id="mobile"  placeholder="Your Mobile No" onchange="validamobile();" type="text" maxlength="10" required > -->
                    </div>
                    <!-- <div class="md-form password-div position-relative">
                      <input autocomplete="off" class="form-control" name='password'  id="password"  placeholder="Enter Password" onchange="validamobile();" type="text" maxlength="10" required>
                    </div> -->
                    <div class="refotpbox password-div pt-0">
                      <div class="md-form otprow position-relative m-0">
                        <div class="otp-inputrow singalotp-inputrow">
                          <input autocomplete="off" class="form-control" name='password'  id="password"  placeholder="Enter Password" type="text" required>
                        </div>
                      </div>
                    </div>
                    <!---->
                    <div class="refotpbox otp-div pt-0" style="display: none">
                      <div class="md-form otprow position-relative m-0">
                        <div class="otp-inputrow singalotp-inputrow">
                          <input require class="form-control singalotpcol logotp ng-untouched ng-pristine ng-invalid" formcontrolname="regotp0" maxlength="6" numbersonly="" name='otp' id='otp' placeholder="Enter your OTP" type="tel">
                        </div>
                      </div>
                    </div>
                    <div class="actioncol text-center">
                      <div style="margin-top: 20px;margin-bottom: 18px;" class="form-check p-0">
                        <button class="btn-login" type="submit" name='submit' >verify</button>
                      </div>
                    </div>
                    <center><h4>OR</h4></center>
                    <div class="actioncol text-center">
                      <div style="margin-top: 20px; margin-bottom: 18px;" class="form-check p-0">
                        <button class="btn-login otp" type="button" name='submit' onclick="return loginWithOtp(event)" >Login With OTP</button>
                      </div>
                    </div>
                  </form>
                </div>
                </div>
              </div>
            </div>
            <div class="termsbox">
             <p _ngcontent-dxl-c9="" class="terms-service" style="margin-top: 30px;
    font-weight: 700;"> By continuing you agree to our <a style='color:#ff5722;' _ngcontent-dxl-c9="" href="terms_and_conditions.php">Terms of Service </a> & <a _ngcontent-dxl-c9="" href="" style='color:#ff5722;'>Privacy &amp; Legal Policy.</a></p>
            </div>
          </div><!---->
        </div>
      </div>
    </main>
<?php include('include/footer.php');?>
  </div>
</body> 
<script>
  $('#password, #confirm_password').on('keyup', function () {
    if ($('#password').val() == $('#confirm_password').val()) {
        $('#message').html('Matching').css('color', 'green');
    } else 
        $('#message').html('Not Matching').css('color', 'red');
});
</script>
<script>
  function loginWithOtp(e){
    var btn = e.target;
    var mobile = document.getElementById("mobile");
    var password = document.getElementById("password");
    console.log(btn.classList.contains("otp"));
    if(btn.classList.contains("otp")){
      $('.password-div').hide();
      $('.otp-div').show();
      btn.classList.remove("otp");
      btn.classList.add("password");
      // add eventlistener in mobile
      mobile.setAttribute("onchange", "validamobile()");
      if(mobile.value!=''){
        validamobile();
      }
      document.querySelector("#loginForm").addEventListener("submit",validateOtp);
      password.removeAttribute("required");
      btn.innerHTML = "Login With Password";
    }else if(btn.classList.contains("password")){
      $('.password-div').show();
      $('.otp-div').hide();
      btn.classList.add("otp");
      btn.classList.remove("password");
      // remove eventlistener in mobile
      mobile.removeAttribute("onchange");
      document.querySelector("#loginForm").removeEventListener("submit",validateOtp);
      password.setAttribute("required", "required");
      btn.innerHTML = "Login With OTP";
    }
  }
</script>
<script>
function validamobile(){
  var mobile = document.getElementById('mobile').value;
  var str = mobile; 
  var res = str.substring(0, 1);
  //document.getElementById("demo").innerHTML = res;
  if(res>5 && str.length == 10){
    $.ajax({
        type: "POST",
        url: "mobile.php",
        data:{
          login:1,
          mobile:mobile,
        },
        success: function(data1){
            console.log(data1)
            if(data1 == 'send'){
              alert('Otp Send Successfully');
            }else{
              alert("Your Mobile is not Registered please SignUp.....");
              window.location = 'signup.php';
            }
        }
      });
  }else {
    alert('Please enter valid mobile no.');
      document.getElementById('mobile').value='';
      document.getElementById('mobile').focus();
  }
}
function validateOtp(e){
  e.preventDefault()
  var otp = document.getElementById('otp').value;
  $.ajax({
      type: "POST",
      url: "mobile.php",
      data:{
        validateOtp:1,
        otp: otp
      },
      success: function(data){
        if(data=='false'){
          alert('Please enter correct otp..');
          document.getElementById('otp').value='';
          document.getElementById('otp').focus();
        }else if(data == 'verify'){
          document.querySelector("#loginForm").removeEventListener("submit",validateOtp);
          formSubmit();
          return false;
        }
      }
    });
}
function formSubmit(){
  $("#loginForm").submit();
}
</script>
<script type="text/javascript">
$(document).ready(function () {
    localStorage.removeItem('loginpage');
    window.user_id     = (localStorage.getItem('userid')!=null) ? localStorage.getItem('userid'):"" ;
    window.auth_token  = (localStorage.getItem('authtoken')!=null) ? localStorage.getItem('authtoken'):"";
    window.cust_dname  = (localStorage.getItem('displayname')!=null) ? localStorage.getItem('displayname'):"";
        window.login_session = {
      "async": true,
      "crossDomain": true,
      "url": "https://www.Vedgun.com/mst/rest/v1/entity/customer/get_details",
      "method": "GET",
      "headers": {
        "userid": window.user_id,
        "authtoken": window.auth_token
      }
    };
    if((user_id!="" && user_id != 0) && (cust_dname!="")){
        $('.login #logged_user').text("");
        $('.login #logged_user').append(cust_dname);
        $('.login a:first').hide();
        $('.login #logged_user').show();
        $("#customer-name").text("Hello, "+cust_dname);
        $("#profile-link").attr("href","/customer/account");
        $("#sign_in_out").text('Logout').attr("href","/customer/account/logout");
    } else {
        $('.login #logged_user').hide();
        $('.login a:first').show();
    }
        $('.logged').show();
});
</script>
</html>