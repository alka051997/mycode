<!doctype html>
<html lang="en">

<!-- Mirrored from www.Vedgun.com/customer/account by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 30 Nov 2020 05:08:45 GMT -->
<head>
  <meta charset="utf-8">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta http-equiv="ScreenOrientation" content="autoRotate:disabled">
  <title>Buy Grocery Online at Best Prices Pan India</title>
  <base >
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no">
  <link rel="icon" type="image/x-icon" href="../msassets/favicon1b26.svg?v2">
  <link rel="stylesheet" href="../../cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">  
  <script src="../msassets/env18c4.js?v10"></script>
  <script src="../msassets/client.min4b6d.js?v5"></script>
  <script src="../msassets/qrcode.js"></script>
  
  <!-- Google Tag Manager -->
  <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
  new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
  j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
  '../../www.googletagmanager.com/gtm5445.php?id='+i+dl;f.parentNode.insertBefore(j,f);
  })(window,document,'script','dataLayer',window.__env.googleTagManagerId);
  </script>
  <!-- End Google Tag Manager -->
  <!-- Anti-flicker snippet (recommended)  -->
  <style>.async-hide { opacity: 0 !important} </style>
  <script>
  var tagmid = window.__env.googleTagManagerId;
  (function(a,s,y,n,c,h,i,d,e){s.className+=' '+y;h.start=1*new Date;
  h.end=i=function(){s.className=s.className.replace(RegExp(' ?'+y),'')};
  (a[n]=a[n]||[]).hide=h;setTimeout(function(){i();h.end=null},c);h.timeout=c;
  })(window,document.documentElement,'async-hide','dataLayer',1000,
  {tagmid:true});</script>
<link rel="stylesheet" href="../smart-cdn/styles.9d6dc28d0888fc51301a.css"></head>
<body>
  <!-- Google Tag Manager (noscript) -->
  <script>
    document.write('<noscript><iframe id="tagmframe" src="https://www.googletagmanager.com/ns.php?id=' + window.__env.googleTagManagerId + '" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>');
  </script>
  <!-- End Google Tag Manager (noscript) -->
  <app-root></app-root>
  <!-- <script type="text/javascript" src="https://api.juspay.in/pay-v3.js"></script> -->
  <!-- <script type="text/javascript" src="https://sandbox.juspay.in/pay-v3.js"></script>  -->

  <script>
    (function(i, s, o, g, r, a, m) {
        i['GoogleAnalyticsObject'] = r;
        i[r] = i[r] || function() {
            (i[r].q = i[r].q || []).push(arguments)
        }, i[r].l = 1 * new Date();
        a = s.createElement(o),
            m = s.getElementsByTagName(o)[0];
        a.async = 1;
        a.src = g;
        m.parentNode.insertBefore(a, m)
    })(window, document, 'script', '../../www.google-analytics.com/analytics.js', 'ga');
    ga('create', window.__env.googleAnalyticsId, 'auto');
    function sendToApp(payload) {
        const encodedData = window.btoa(JSON.stringify(payload))
        if (window.android && window.android.__externalCall) window.android.__externalCall(encodedData)
        if (window.__externalCall) window.__externalCall(encodedData)
        if (this.isIOS() && window.webkit.messageHandlers && window.webkit.messageHandlers.callback) window.webkit.messageHandlers.callback.postMessage(encodedData)
    }
    function isIOS () {
    return (/iPad|iPhone|iPod/.test(window.navigator.userAgent));
    }



  </script>  
  <script>
    var ALGOLIA_INSIGHTS_SRC = "//cdn.jsdelivr.net/npm/search-insights@1.3.1";
  
    !function(e,a,t,n,s,i,c){e.AlgoliaAnalyticsObject=s,e[s]=e[s]||function(){
    (e[s].queue=e[s].queue||[]).push(arguments)},i=a.createElement(t),c=a.getElementsByTagName(t)[0],
    i.async=1,i.src=n,c.parentNode.insertBefore(i,c)
    }(window,document,"script",ALGOLIA_INSIGHTS_SRC,"aa");
  
    // Initialize library
    aa('init', {
      appId: window.__env.alappId,
      apiKey: window.__env.alapiKey
    });
  </script>
  <script>
    var client = new ClientJS();
  </script>
<script src="../smart-cdn/runtime.68971c3cd9e157abfe6e.js" defer></script><script src="../smart-cdn/polyfills-es5.8cfbcbf4f2997a2397f7.js" nomodule defer></script><script src="../smart-cdn/polyfills.9e7cd414fc5765b35cb9.js" defer></script><script src="../smart-cdn/scripts.ff3094d8b0c428924c4a.js" defer></script><script src="../smart-cdn/vendor.4d279ceddccdae8ab266.js" defer></script><script src="../smart-cdn/main.8b3f08528be2547ac05c.js" defer></script></body>

<!-- Mirrored from www.Vedgun.com/customer/account by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 30 Nov 2020 05:08:57 GMT -->
</html>
