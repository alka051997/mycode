<?php

if($_SERVER["SERVER_NAME"]=="localhost" || $_SERVER["SERVER_NAME"]=="192.168.1.102")
{
	$host_name="localhost";
	$db_name="i_audit_super";
	$db_user="root";
	$db_pwd="";
	if($_SERVER["SERVER_NAME"]=="localhost"){
	$imglink="http://localhost:8080/i_audit/i_audit/upload/";
	$imglink_cat="http://localhost:8080/i_audit/superlogin/upload/category_banner/";
}else{
	$imglink="http://192.168.1.102:8080/i_audit/i_audit/upload/";
	$imglink_cat="http://localhost:8080/i_audit/superlogin/upload/category_banner/";
}
}
else
{ 
	$host_name="localhost";
	$db_name="iauditne_superclient";
	$db_user="iauditne_super";
	$db_pwd="iAudit@#2019";
	$imglink="https://iaudit.net.in/iaudit/upload/";
	$imglink_cat="http://iaudit.net.in/superlogin/upload/category_banner/";
}
//echo "$host_name--$db_name--$db_user--$db_pwd";
$con_sup = mysqli_connect("$host_name","$db_user","$db_pwd");
$con_sup1=mysqli_select_db($con_sup,"$db_name");
if(!$con_sup1){
	echo "connection Error";
}

 // include("lib/getval.php");
 // $cmn = new Comman();
/*
include("lib/getval.php");


$cmn = new Comman();
$createdate = date("Y-m-d H:i:s");

$TitleName = "iAudit";
 
*/ 
?>