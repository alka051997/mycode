<?php
 include('dbconnect.php');
$sql_detail = mysqli_query($con,"select * from ac_party_led where ledger_id='$userid'");
$row_detail = mysqli_fetch_assoc($sql_detail);
$ledger_id = $row_detail['ledger_id'];
$l_name = $row_detail['l_name'];
$mobile = $row_detail['mobile'];
$email  = $row_detail['email'];
$state = $row_detail['state'];
$city = $row_detail['city'];
$pin_code = $row_detail['pin_code'];
$district = $row_detail['district'];
$address = $row_detail['address'];
$sup_ledger_id = $row_detail['sup_ledger_id'];
?>
<!doctype html> <html lang="en-US"> 
<!-- Mirrored from www.Vedgun.com/terms-and-conditions by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 30 Nov 2020 05:35:21 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
  <title>Terms and Condition - Buy Grocery Online at Best Prices Pan India</title>
  <meta charset="utf-8"> <meta name="robots" content="INDEX,FOLLOW">
  <meta name="description" content="Find the Terms and Condition stated by Reliancesmart.in." />
  <meta name="keywords" content="" />
  <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
  <meta property="og:site_name" content="Vedgun" />
  <meta property="og:type" content="website" />
  <meta property="og:title" content="Terms and Condition - Buy Grocery Online at Best Prices Pan India" />
  <meta property="og:description" content="Find the Terms and Condition stated by Reliancesmart.in." />
  <meta property="og:url" content="terms-and-conditions.php" />
  <meta property="og:image" content="assets/global/logo-fb.png" /> <!-- Appple Touch Icons -->

 <?php include('include/files.php');?>
  <style>
    .multi-srch-hide{ display:none !important; } .ais-InfiniteHits-loadMore{ display:none; } .gift-page #saved_location{ display:none; }
  </style>
  <link rel="manifest" href="manifest.json">
  <!-- <script>
    (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
        new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
        j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
        '../www.googletagmanager.com/gtm5445.php?id='+i+dl;f.parentNode.insertBefore(j,f);
        })(window,document,'script','dataLayer','GTM-NQLHTD8');
  </script> -->
<style>
  .otc-product-page #first_desc h2 {display: none} .otc-product-page #first_desc h2.pname{display: block!important;}.catalog-category-view.level-3 .white-bg.msite-list, .catalog-category-view.level-0 .white-bg.msite-list{display:none !important} .cat-fashion .right-block .empty_listing {position:absolute;z-index:3} .compare_products{ display:none; }#bought_together{display:none !important}.prod-groceries #similar_products{display: none;} .prod-groceries .section-seperate1{display: none;} .prod-fashion .new_product #product_details #left_col .gallery-top,.prod-groceries .new_product #product_details #left_col .gallery-top{height: auto;} .gift-page .all-product .row product-list .col-md-3:last-child .price-box{display:none} .gift-page #free_gift_wrap{display:none !important} .best_deals .add_banner {margin: 0 auto;text-align: center;} .best_deals .add_banner img {width: auto;height: 100%;border-radius: 0;} .best_deals .section-seperate{display: none;} .prod-jewellery .brand_name{display:none !important} .prod-jewellery .prepaid_msg{display:block;font-size:14px;color:#dd0608;font-family: sans-serif;} .aa-dropdown-menu .aa-suggestions .aa-suggestion .product-item-info.search-jewellery a .drug_img { background: url(assets/version1605113383/smartweb/images/search_icons/search_jewellery.png) center no-repeat; background-size: 40px; }
  .point{
    padding-top: 20px;
  }
.point li{
    list-style-type: none;
    float: left;
    margin-right: 20px;
}
.line{
        height: 2px;
    background: #8ec63f;
    width: 100px;
    margin-top: 9px;
}
.input-group {
    position: relative;
    display: inline-flex !important;
    border-collapse: separate;
}
.ttr{

    background-color: #ececed;
    padding: 20px;

}
.totalamt-col{
  display: inline-block;
  background: #ececed;
  padding: 24px;
  width: 100%;
  margin-bottom: 16px;
  border-radius: 4px;
}
.mycart_head{
  font-family: sans-serif;
}
.btn.disabled, .btn[disabled], fieldset[disabled] .btn {
  opacity:1 !important;
}
.glyphicon {
  font-family: sans-serif !important;
}
.cart-head,.order-head,.payment-head{
  cursor: pointer;
}
</style>
</head> 
<body class="static-page cms-terms-and-conditions">
<div class="page-wrapper"> 
  <div class="top-section"> 
    <?php include('include/header.php');?>
    <main id="maincontent" class=" static-content"> 
      <div class="breadcrumbs d-none d-sm-block">
        <ul class="items">
          <li class="home"> <a href="index.php" title="Go to Home"> Home </a> </li>
          <li class="home"> <span>Cart</span> </li>
        </ul>
      </div>
      <div class='col-md-12'>
        <div class='col-md-3'><h2 class="mycart_head">My Cart</h2></div>
        <div class='col-md-9'>
            <ul style=''class="point float-right">
              <li class="active">
                <span class="icon cart"></span>
                <span style="color: red" class="glyphicon glyphicon-shopping-cart cart-head"> Your Cart </span>
              </li>
              <li><p class="line"></p></li>
              <li class="">
                <span class="icon review"></span>
                <span class="glyphicon glyphicon-folder-close order-head">&nbsp;Order Summary </span>
              </li>
              <li><p class="line"></p></li>
              <li class="">
                <span class="icon placeorder"></span>
                <span class="glyphicon glyphicon-folder-close payment-head">&nbsp;Payment </span>
              </li>
             <div class='clearfix'></div>
            </ul>
        </div>
        <div class='clearfix'></div>
      </div>
      <div class='clearfix'></div>
      <div class='col-md-12'>
        <div class='col-md-12'>
          <div class='col-md-7'>
          <!-- Address Detail -->
          <div class='col-md-12 address-div' style="margin: 10px 0;padding: 10px 0;  box-shadow: 5px 5px 5px #eee, -5px -5px 5px #eee;display:none;">
            <div class="proditem" style="padding: 10px;width: 70%">
              <h4> Select Delivery Address</h4>
              <div class="col-md-12">
                <div class="leftside-icons col-md-12"style="background: #eee;padding: 10px;">
                  <?php 
                  echo "<h4 style='text-transform: capitalize;line-height:1rem'><input type='radio' checked> $l_name </h4>";
                  echo "<span id='address'>$address</span><br>";
                  echo "<span id='city'>$city</span> - ";
                  echo "<span id='pin_code'>$pin_code</span><br>";
                  echo "<span id='state'>$state</span>";
                  echo "<br>$mobile"
                  ?>
                </div>
                <div class='clearfix'></div>
              </div>
            </div>
            <button type="button" class="btn btn-primary" style="float:right;"> Change/Add Address </button>
          </div>
          <!-- Cart Detail -->
          <div class='col-md-12 ttr' style="margin: 10px 0;padding: 10px 0;background: #eee;padding: 10px;box-shadow: 5px 5px 5px #eee, -5px -5px 5px #eee;">
            <div class="proditem" style="">
              <div class="col-md-12">
                <div class="leftside-icons col-md-2">
                  <a class="product-item-photo" href="#" title="item name">
                  <img class="pro-img mylistimg" src="#">
                  </a>
                </div>
                <div class='clearfix'></div>
              </div>
            </div>
            <br>
          </div>
          <!-- Payment Detail -->
          <div class='col-md-12 payment-div' style="margin: 10px 0;padding: 10px 0; box-shadow: 5px 5px 5px #eee, -5px -5px 5px #eee;display:none;">
            <div class="proditem" style="padding: 10px;width: 70%">
              <h4> Select Payment Method</h4>
              <div class="col-md-12">
                <div class="leftside-icons col-md-12"style="background: #eee;padding: 10px;">
                  <div class="form-group">
                    <label><input type="radio" name="payment_method" value="cod"> Pay On Delivery</label>
                  </div>

                  <div class="form-group">
                    <label> <input type="radio" name="payment_method" value="online" placeholder=""> Online Payment</label>
                  </div>
                </div>
              </div>
            </div>
            <button type="button" class="btn btn-primary" style="float:right;"> Change/Add Address </button>
                <div class='clearfix'></div>
          </div>
        </div>
          <div class='col-md-5'>
            <div class="totalamt-col">
              <h4 class="paymentdetails-title" style="border-bottom: 2px solid #ffff;padding-bottom: 20px;">Payment Details</h4>
              <div class="allcalculation">
                <div class="subtoal" style="border-bottom: 2px solid #ffff;padding-bottom: 40px; padding-top: 10px;">
                  <div class='col-md-12'>
                    <div class='col-md-6'>
                  <label>MRP Total</label>
                </div>
                <div class='col-md-1'>
                  :
                </div>
                <div class='col-md-5'>
                  <i class="fa fa-rupee-sign"></i>
                  <span id="cart_sub_total">0</span>
                </div>
                </div>
                </div><!----><!----><!----><!----><!---->
                <div class="discount cart-discount" style="border-bottom: 2px solid #ffff;padding-bottom: 40px;padding-top: 10px;">
                  <div class='col-md-12'>
                    <div class='col-md-6'>
                      <label>Product Discount</label>
                    </div>
                    <div class='col-md-1'>:</div>
                    <div class='col-md-5'>
                      <i class="fa fa-rupee-sign"></i>
                      <span id="cart_total_disc1">- <i class="fa fa-rupee-sign"></i>0</span>
                    </div>
                  </div>
                </div><!---->
                <div class="extra-discount" style="border-bottom: 2px solid #ffff;padding-bottom: 40px;padding-top: 10px;display: none">
                  <div class='col-md-12'>
                    <div class='col-md-6'>
                      <label>Vedgun Money Earn</label>
                    </div>
                    <div class='col-md-1'>:</div>
                    <div class='col-md-5'>
                      <span id="vedgun_money">- <i class="fa fa-rupee-sign"></i>0</span>
                    </div>
                  </div>
                </div><!---->
                <div class="net-amount" style="border-bottom: 2px solid #ffff;padding-bottom: 40px;padding-top: 10px;">
                  <div class='col-md-12'>
                    <div class='col-md-6'>
                      <b><label>Total Amount</label></b>
                    </div>
                    <div class='col-md-1'>:</div>
                    <div class='col-md-5'>
                      <i class="fa fa-rupee-sign"></i>
                    <b>  <span id="cart_netpay_amt1"><i class="fa fa-rupee-sign"></i>0</span></b>
                    </div>
                  </div>
                </div><!---->
                <div class="save-amount" style="margin-bottom: 40px;margin-top: 10px;display: none">
                  <div class='col-md-12'>
                    <div class='col-md-6'>
                      <label>You Save </label>
                    </div>
                    <div class='col-md-1'>:</div>
                    <div class='col-md-5'>
                      <span id="cart_savings"><i class="fa fa-rupee-sign"></i>0</span>
                    </div>
                  </div>
                </div>
                <br>
                <button class="btn-checkout btn btn-primary btn_to_checkout m-0" type="button" style="padding: 10px;margin-top: 20px;" onclick="orderFun()"> Checkout </button>
              </div><!----><!----><!---->
            </div>
          </div>
        </div>
      </div>
      <div class='clearfix'></div>
    </main>
    <?php include('include/footer.php');?>
  </div>
<script>
  function orderFun(){
    $(".btn_to_checkout").attr("disabled","disabled");
    if(!isLogin()){
      $(".btn_to_checkout").removeAttr("disabled");
      return window.location = 'login.php';
    }else{
      $(".mycart_head").html("Order Summary");
      $(".cart-head").attr("onclick","showCart()")
      $(".order-head").css("color","red");
      $(".address-div").fadeIn();
      $(".ttr").fadeIn();
      $(".plusminus .btn").hide();
      $(".payment-div").fadeOut();
      $(".payment-head").css("color","black");
      $(".btn_to_checkout").attr("onclick","orderPay()");
      $(".btn_to_checkout").html(" Make Payment");
    }
    $(".btn_to_checkout").removeAttr("disabled");

  }
  function showCart(){
    $(".btn_to_checkout").attr("disabled","disabled");
    $(".mycart_head").html("My Cart");
    $(".order-head").css("color","black")
    $(".address-div").fadeOut();
    $(".plusminus .btn").show();
    $(".btn_to_checkout").attr("onclick","orderFun()");
    $(".btn_to_checkout").html("Checkout");
    $(".btn_to_checkout").removeAttr("disabled");
  }
  function orderPay(){
    $(".btn_to_checkout").attr("disabled","disabled");
    if(!isLogin()){
      $(".btn_to_checkout").removeAttr("disabled");
      return window.location = 'login.php';
    }else{
      $(".mycart_head").html("Payment Detail");
      $(".order-head").attr("onclick","orderFun()")
      $(".payment-head").css("color","red");
      $(".address-div").fadeOut();
      $(".ttr").fadeOut();
      $(".payment-div").fadeIn();
      $(".btn_to_checkout").attr("onclick","makePay()");
      $(".btn_to_checkout").html("Pay");
    }
    $(".btn_to_checkout").removeAttr("disabled");
  }
   
  function makePay(){
    $(".btn_to_checkout").attr("disabled","disabled");
    var address = $("#address").text();
    var pin_code = $("#pin_code").text();
    var city = $("#city").text();
    var district = $("#district").text();
    var state = $("#state").text();
    var sub_total = $("#cart_netpay_amt1").text();
    var vedgun_money = $("#vedgun_money").text();
    var payment_method = $("input[name='payment_method']:checked").val();
    if(payment_method == '' || payment_method == undefined){
      alert("Please select a payment method first")
      $(".btn_to_checkout").removeAttr("disabled");
    }else{
      var shoppingCartData = shoppingCart.listCart();
      $.ajax({
        type:"post",
        url:"ajax.php",
        data:{
          shoppingCartData:shoppingCartData,
          address:address,
          pin_code:pin_code,
          city:city,
          district:district,
          state:state,
          payment_method:payment_method,
          sub_total:sub_total,
          vedgun_money:vedgun_money,
        },
        success:function(data) {
          console.log(data);
          $(".btn_to_checkout").removeAttr("disabled");
        }
      }) 
    }
  }
</script>
</body>

</html>