
<?php

 include('dbconnect.php');
 $pro_name=$_REQUEST['pro_name'];

 $pro_main_cat_data=mysqli_query($con_sup,"select * from item_master where item_name='$pro_name' group by sup_category_id");
 $pro_main_cat_data_row11=mysqli_fetch_array($pro_main_cat_data);

  $pro_main_cat_data_row=$pro_main_cat_data_row11['sup_category_id'];


 ?>

<!doctype html>
 <html lang="en-US"> 
<!-- Mirrored from www.Vedgun.com/c/groceries/fruits-vegetables/fresh-fruits/220 by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 30 Nov 2020 05:09:24 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head> 
  <title>Fresh Fruits - Vedgun</title> 
  <meta charset="utf-8"> 
  <meta name="robots" content="INDEX,FOLLOW"> 
  <meta name="description" content="Buy Grocery Online in Mumbai, Pune, Bangalore at Vedgun online grocery store. Best price on fresh fruits &amp; vegetables, dairy &amp; bakery, packaged food." /> <meta name="keywords" content="" />
   <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <meta property="og:site_name" content="Vedgun" /> 
    <meta property="og:type" content="website" />
     <meta property="og:title" content="Fresh Fruits - Vedgun" /> 
     <meta property="og:description" content="Buy Grocery Online in Mumbai, Pune, Bangalore at Reliance Smart online grocery store. Best price on fresh fruits & vegetables, dairy & bakery, packaged food." /> 
     <meta property="og:url" content="220.php" /> 
     <meta property="og:image" content="../../../../assets/global/logo-fb.png" /> <!-- Appple Touch Icons --> 
     <link rel="apple-touch-icon" sizes="48x48" href="../../../../assets/global/new_toch_Vedgun_icon/apple-touch-icon-48x48.png"> 
     <link rel="apple-touch-icon" sizes="72x72" href="../../../../assets/global/new_toch_Vedgun_icon/apple-touch-icon-72x72.png"> 
     <link rel="apple-touch-icon" sizes="128x128" href="../../../../assets/global/new_toch_Vedgun_icon/apple-touch-icon-128x128.png">
      <link rel="apple-touch-icon" sizes="256x256" href="../../../../assets/global/new_toch_Vedgun_icon/apple-touch-icon-256x256.png">
       <link rel="apple-touch-icon" href="../../../../assets/global/new_toch_Vedgun_icon/apple-touch-icon-48x48.png">
        <meta name="google-play-app" content="app-id=com.jpl.Vedgun"> <meta name="apple-itunes-app" content="app-id=1522085683"> 
        <meta name="theme-color" content="#ffffff"/> 
<link rel="stylesheet"  href="assets/version1605113383/smartweb/css/product.min.css"> 
<?php include('include/files.php');?>
    <style>

  #product_details{
    height:300px; 
  }
  .new_product .feat_detail {
    margin: 0 0 16px;
    border-radius: 0;
    padding: 0 0 16px;
    border-bottom: 2px solid #ececec;
    position: relative;
}
      .multi-srch-hide{ display:none !important; } .ais-InfiniteHits-loadMore{ display:none; } .gift-page #saved_location{ display:none; } </style> <link rel="manifest" href="../../../../manifest.json"> <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
		new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
		j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
		'../../../../../www.googletagmanager.com/gtm5445.php?id='+i+dl;f.parentNode.insertBefore(j,f);
		})(window,document,'script','dataLayer','GTM-NQLHTD8');</script> <style> .otc-product-page #first_desc h2 {display: none} .otc-product-page #first_desc h2.pname{display: block!important;}.catalog-category-view.level-3 .white-bg.msite-list, .catalog-category-view.level-0 .white-bg.msite-list{display:none !important} .cat-fashion .right-block .empty_listing {position:absolute;z-index:3} .compare_products{ display:none; }#bought_together{display:none !important}.prod-groceries #similar_products{display: none;} .prod-groceries .section-seperate1{display: none;} .prod-fashion .new_product #product_details #left_col .gallery-top,.prod-groceries .new_product #product_details #left_col .gallery-top{height: auto;} .gift-page .all-product .row product-list .col-md-3:last-child .price-box{display:none} .gift-page #free_gift_wrap{display:none !important} .best_deals .add_banner {margin: 0 auto;text-align: center;} .best_deals .add_banner img {width: auto;height: 100%;border-radius: 0;} .best_deals .section-seperate{display: none;} .prod-jewellery .brand_name{display:none !important} .prod-jewellery .prepaid_msg{display:block;font-size:14px;color:#dd0608;font-family: sans-serif;} .aa-dropdown-menu .aa-suggestions .aa-suggestion .product-item-info.search-jewellery a .drug_img { background: url(../../../../assets/version1605113383/smartweb/images/search_icons/search_jewellery.png) center no-repeat; background-size: 40px; }.drug-list-page .right-block .white-bg .all-product .product-list .cat-item .price-box strike {
    text-decoration: line-through;
    padding-right: 4px;
    color: #000;
} 
   .price {
        font-weight: bold;
    color: #faa200;
   }
   .fea_details{
    margin-top: 51px;
   }
   .re_head{
    font-family: sans-serif;
    font-size: 16px;
    font-stretch: normal;
    font-style: normal;
    line-height: 20px;
    letter-spacing: 1px;
    color: #000;
   }
   .tab-pane{
    padding:20px;
   }
   .feat_detail h1{
        font-family: sans-serif;
    font-size: 16px;
    font-stretch: normal;
    font-style: normal;
    line-height: 20px;
    letter-spacing: 1px;
    color: #000;
    margin: 0 0 12px;
    float: left;
   }
   .prodDetTable{
        width: 47%;
    float: left;
    margin-right: 3%;
    border-bottom: .1rem solid #e7e7e7;
    font-family: sans-serif;
    font-size: 14px;
    margin-bottom: 8px;
   }
.prodDetTable tr th {
   border-top: .1rem solid #e7e7e7;
    background-color: #f3f3f3;
    color: #000;
    padding: 12px;
    width: 21.25%;
    font-family: sans-serif;
    font-weight: 400;
  }

.prodDetTable tr td {
  width: 73.75%;
    padding: 12px;
    border-top: .1rem solid #e7e7e7;
    word-wrap: break-word;
    word-break: break-word;
  }
</style> <script>
        window.default_pin = '400020';
        window.algolia_filter = false;
        window.algolia_app_id = "3YP0HP3WSH";
        window.algolia_api_key = "aace3f18430a49e185d2c1111602e4b1";
        //window.algolia_index_name = "";
        window.algolia_suffix = 'prod_mart';
                window.product_image_path = "../../../../index.php";
                window.location_api = "AIzaSyBfquJmLRraJi0sNjV14BQWqGlMAEzqAIw";
        window.default_vertical_city_code = JSON.parse('{"ELECTRONICS": "null","FASHION": null,"GROCERIES": "6221", "JEWELLERY": "PANINDIAJEWEL"}');
        window.inventory_store_code = JSON.parse('{"GROCERIES":["6210"],"FASHION":null,"ELECTRONICS":null}');
    </script> </head> <body class="otc-category-page catalog-category-view cat-groceries level-3"> <noscript><iframe src="https://www.googletagmanager.com/ns.php?id=GTM-NQLHTD8" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript> <div class="page-wrapper"> <div class="top-section">
        <?php include('include/header.php');?>
          
       </div>
        <main id="maincontent" class="main-section full-width">
         <div class="breadcrumbs d-none d-sm-block">
        <ul class="items">
          <li class="home"> <a href="index.php" title="Go to Home"> Home </a> </li> 
          <li class="home"> <a href="all-category" title="Go to All Categories"> All Categories </a> </li>
         <li class="home"> <span><?php echo $pro_name;?></span> </li>
        </ul> 
      </div>
      <div class="new_product">
       <section id="product_details"> 
        <div id="left_col">
         <div class="swiper-container gallery-top swiper-container-initialized swiper-container-horizontal">
          <div class="swiper-wrapper" style="transform: translate3d(0px, 0px, 0px);">
                <?php
               $pro_data_que=mysqli_query($con_sup,"SELECT ROUND(((item_master.`mrp`-item_master.`offer_price`)*100)/item_master.`mrp`) as per,item_master.* FROM `item_master`  where item_name='$pro_name' and status='0' ORDER BY `sup_category_name` ASC");   
                  $row_pro=mysqli_fetch_array($pro_data_que);
                 $com_id=$row_pro['sup_company_id'];
                  $pro_image1=strtolower($row_pro['image1']);
                  $pro_image2=strtolower($row_pro['image2']);
                  $pro_image3=strtolower($row_pro['image3']);
                  $item_id=$row_pro['item_id'];
                  $pro_name=$row_pro['item_name'];
                  $pro_mrp=$row_pro['mrp'];
                  $per=$row_pro['per'];
                  $pro_offer_price=$row_pro['offer_price'];
                  $pro_save=$pro_offer_price-$pro_mr;
                  $pro_shipping_cost=$row_pro['shipping_cost'];
                  $pro_color=$row_pro['color'];
                  $pro_size=$row_pro['size'];
                  $pro_brand_name=$row_pro['prod_company_name'];
                  $pro_key_feature=$row_pro['key_feature'];
                    $con_stock=$row_pro['mrp_from_stock'];
                    $stock=$row_pro['stock'];
                      $item_stock=$row_pro['item_stock'];
                      if($con_stock=='1'){
                        $mystock=$stock;
                      }else{
                        $mystock=$item_stock;
                       
                      }

                  if($pro_offer_price!='' && $pro_offer_price!='0'){
                    $final_price = $pro_offer_price;
                    $pro_del_save = $pro_mrp - $pro_offer_price;
                  }else{
                    $final_price = $pro_mrp;
                  }

                ?>

           <div class="swiper-slide swiper-slide-active" style="width: 421px;">
            <img class="largeimage" src="<?php echo $imglink.'comp'.$sup_companyid.'/'.'item_image'.'/'.$pro_image1; ?>" alt="<?php echo $pro_name;?>" title='<?php echo $pro_name;?>' data-index="0">
          </div>
         
             </div>
             <?php if($per!="" && $per!='0' && $per!='100'){?>
              <div class="dis_section"> <span><?php echo $per;?></span>%<div class="clearfix"></div>OFF </div>
            <?php } ?>

               <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span></div>
              <div class="thumbs_img">
               <div class="swiper-container gallery-thumbs swiper-container-initialized swiper-container-vertical swiper-container-free-mode swiper-container-thumbs"> 
<div class="swiper-wrapper" style="transform: translate3d(0px, 0px, 0px);"> 
  
      <?php if($pro_image1!='' && $pro_image1!='0' && !(file_exists($imglink.'comp'.$sup_companyid.'/'.'item_image'.'/'.$pro_image1))){?>
       <div class="swiper-slide swiper-slide-visible"> 
        
        <img src="<?php echo $imglink.'comp'.$sup_companyid.'/'.'item_image'.'/'.$pro_image1; ?>" alt="<?php echo $pro_name;?>" title='<?php echo $pro_name;?>'> 

      </div>
    <?php }?>
          <?php if($pro_image2!='' && $pro_image2!='0' && !(file_exists($imglink.'comp'.$sup_companyid.'/'.'item_image'.'/'.$pro_image2))){?>

       <div class="swiper-slide">
        <img src="<?php echo $imglink.'comp'.$sup_companyid.'/'.'item_image'.'/'.$pro_image2; ?>" alt="<?php echo $pro_name;?>" title='<?php echo $pro_name;?>'>
         </div>
       <?php }?>
             <?php if($pro_image3!='' && $pro_image3!='0' && !(file_exists($imglink.'comp'.$sup_companyid.'/'.'item_image'.'/'.$pro_image3))){?>

          <div class="swiper-slide">
           <img src="<?php echo $imglink.'comp'.$sup_companyid.'/'.'item_image'.'/'.$pro_image3; ?>" alt="<?php echo $pro_name;?>" title='<?php echo $pro_name;?>'> 
         </div>
       <?php }?>
       </div>


               <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span>
             </div>
              </div>
               <div class="clearfix"></div>
          </div> 
              <div id="center_col"> 

                <div class="title-section">
               <h1><?php echo $pro_name;?></h1>
               </div>
                <div class="clearfix"></div>
                 <div class="clearfix"></div>
                  <a href="#" title="<?php echo $pro_brand_name; ?>"> <div class="brand_name">
                    <?php echo $pro_brand_name; ?>
                   </div>
                 </a> 
                 <div class="clearfix"></div>
                  <section id="price_section"> 
                    <div class="price-box">
                      <?php if($pro_offer_price!='' && $pro_offer_price!='0'){?>
                     <span class="price">M.R.P: <strike><i class="fa fa-rupee-sign"></i> <?php echo $pro_mrp;?></strike></span>
                       <span class="final-price">Price: <span><i class="fa fa-rupee-sign"></i> <?php echo $pro_offer_price;?></span></span>
                    <div class="clearfix"></div>
                        <span class="disc-price">You Save: <span><i class="fa fa-rupee-sign"></i> <?php echo $pro_save; ?>.00</span></span> 
                   <?php } else{?>
                       <span class="price">M.R.P: <i class="fa fa-rupee-sign"></i> <?php echo $pro_mrp;?></span>

                   <?php } ?>
                       
                          <input type="hidden" value="440675812002" id="alt_sku"> 
                          <input type="hidden" value="224" id="selling_price_val"> 
                          <input type="hidden" value="590009326" id="sku_val"> 
                          <input type="hidden" value="FASHION" id="vertical_code">
                          <input type="hidden" value="0" id="emi_status">
                          <input type="hidden" value="/platform/logistics/api/v1/promise" id="fynd_api_url">
                          <div class="clearfix"></div>
                     </div>
                   </section> 
                   <div class="clearfix"></div> 
                   <div class="stock_details"><span>Availibilty: </span> In Stock <?php if($myscript!=''){  ?>
                    [<?php echo $mystock;?>]

                   <?php } ?>
                   </div>
                    <div class="clearfix"></div> 
                    
                     <div class="clearfix"></div>
                      <div class="del_info" id="prod_delivery_details">
                        <?php if($pro_shipping_cost!=''){?>
                        <div class="long_msg"><?php if($pro_shipping_cost!='0' && $pro_shipping_cost!=''){?><span>Shipping Charge :<?php echo $pro_shipping_cost;?></span><?php } ?>
                        </div>
                      <?php } ?>
                      </div> 
                      <div class="clearfix"></div>
                       <div class="clearfix"></div>
                           <div class="clearfix"></div> 
                            <div class="clearfix"></div> <div class="clearfix"></div> <div class="clearfix"></div> <div class="product-add-form"> <div class="cart_btn">

 
                              <button data-name="<?php echo $pro_name;?>" data-price="<?php echo $final_price;?>" data-discount="<?php echo $pro_del_save;?>" data-id='<?php echo $item_id ?>' data-image='<?php echo $pro_image1 ?>' class="add-to-cart btn btn-primary">Add to Basket</button>


                              </div> <div class="clearfix"></div> <div id="cart_form_message"></div> <div class="clearfix"></div> </div> <div class="clearfix"></div> 

                            <div class="clearfix"></div>  <div class="clearfix"></div> <!-- <section id="product_identy"> <div id="text-veg" class="vnv-text"> This is a <b>Vegetarian</b> product. </div> <div id="text-nonveg" class="vnv-text"> This is a <b>Non-Vegetarian</b> product. </div> </section> <div class="clearfix"></div> --> </div> <div class="clearfix"></div> </section> <div class="clearfix"></div> <style> .toggle-btn{ cursor:pointer; } </style>
                             <section id="manu_description"> 
                               <ul class="nav nav-tabs">
    <li class="active"><a data-toggle="tab" href="#home">Features & Details</a></li>
    <li><a data-toggle="tab" href="#menu1">Return Policy</a></li>
   
  </ul>

  <div class="tab-content">
    <div id="home" class="tab-pane fade in active" >
  
      <?php if($pro_key_feature!=''){?>
      <p><?php echo html_entity_decode(strtolower($pro_key_feature));?></p>
    <?php }else{?>
      <p>No Records Found</p>
    <?php } ?>
    </div>
    <div id="menu1" class="tab-pane fade">
  
       <?php 
                                        $data_return=mysqli_query($con_sup,"select return_policy from e_commerce_details where sup_company_id='$sup_companyid'");
                                        $row_return=mysqli_fetch_array($data_return);
                                        $data_return_content=html_entity_decode(strtolower($row_return['return_policy']));
                                        if($data_return_content=''){

                                        ?>
                                         <div class="content_txt">
                                        <?php if(strlen($data_return_content)>1000){

                         echo substr($data_return_content,0,1000)."....."; 

                                         echo '<a href="return_policy.php" class="clsviewall external_link" style="color: #e11500 !important;" target="_blank" rel="noopener">Know More</a> 

                                        ';

                    }else

                    {

                        echo $data_return_content;

                    }
                  }else{

                  ?>    

                  <p>No Records Founds...</p>
                  <?php } ?>  
    </div>
   
  </div>
                                    <div class="clearfix"></div>
                                   </div>
                                    </section>
                                     <div class="clearfix"></div><div class="clearfix"></div>


                                      <section id="fea_details"> <div class="feat_detail"> <h1>Product Information</h1> <div class="clearfix"></div> <div class="content_txt"> <table class="prodDetTable"> <tbody><tr> <th> Brand </th> <td> <a href="#" title="<?php echo $pro_brand_name; ?>"> <?php echo $pro_brand_name; ?>  </a> </td> </tr> <tr> <th> Country of origin </th> <td> India </td> </tr> <tr> <th> Net Quantity </th> <td> </td> </tr></tbody></table> <table class="prodDetTable"> <tbody><tr> <th> Manufacturer </th> <td> Farm</td> </tr> </tbody></table> <div class="clearfix"></div> </div> <div class="clearfix"></div> </div> </section> <div class="clearfix"></div> <section id="similar_products"> <div class="new_arrival_section"> <h1 class="title_section"> Similar Products <!-- <a href="/category/all" class="clsviewall">SEE ALL</a> --> </h1> 

                                            <div class="clearfix"></div> 

                                            <div class="similar_products_swiper swiper-container products_swipe swiper-container-initialized swiper-container-horizontal"> <div class="swiper-wrapper" style="transform: translate3d(0px, 0px, 0px);">

                                              <?php 
                                              // echo "select * from item_master where sub_category_id='$pro_main_cat_data_row'";
                                              // die;
                                              $data_sim=mysqli_query($con_sup,"select * from item_master where sup_category_id='$pro_main_cat_data_row' limit 4");
                                              while ($row_sim=mysqli_fetch_array($data_sim)) {
                                                $row_sim_img=strtolower($row_sim['image1']);
                                                 $row_sim_item_name=$row_sim['item_name'];
                                                 $row_sim_item_mrp=$row_sim['mrp'];
                                                  $row_sim_item_offer_price=$row_sim['offer_price'];
                        $row_sim_item_save=$row_sim_item_mrp=$row_sim_item_offer_price;

                                   
                                              ?>
                                         <div class="swiper-slide swiper-slide-active">
                                          <div class="pro_items">
                                          <!--  <div class="offer_bade"> 
                                            <span class="offer_value">10</span>% OFF </div> -->
                                                         <?php if($row_sim_img!='' && $row_sim_img!='0' && !(file_exists($imglink.'comp'.$sup_companyid.'/'.'item_image'.'/'.$row_sim_img))){?>

                                             <a href="pro_details.php?pro_name=<?php echo $row_sim_item_name;?>">

                                              <span class="cat-img"> 
                                                <img class="product-image-photo" src="<?php echo $imglink.'comp'.$sup_companyid.'/'.'item_image'.'/'.$row_sim_img; ?>" title="<?php echo $row_sim_item_name;?>" alt="<?php echo $row_sim_item_name;?>"> 
                                              </span>
                                            </a>
                                          <?php } ?>
                                             <div class="clearfix"></div>
                                              <div class="pro_detail"> 
                                                <div class="clearfix"></div> 
                                                <div class="price_box">
                                                  <?php
                                                  if($row_sim_item_offer_price!='' && $row_sim_item_offer_price='0'){
                                                    ?>
                                                 <span class="final_price"><i class="fa fa-rupee-sign"></i> <strike><?php echo $row_sim_item_name.''.$row_sim_item_mrp;?>.00</strike></span> 
                                                 <div class="clearfix"></div>
                                                   <span class="save_price"> Save <i class="fa fa-rupee-sign"></i> <?php echo $row_sim_item_save;?>.00 </span>
                                                
                                               <?php }else{?>
                                                  <span class="final_price"><i class="fa fa-rupee-sign"></i> <?php echo $row_sim_item_name;?>.00</span> 
                                             
                                                <?php }?>
                                                    </div>
                                                   
                                                   </div>
                                                    </div> 

                                                  </div> 
                                                <?php } ?>

                                             
                                             
                                      </div></div>

                                                        
                                                        </div> </section>
                                                        <div class="section-seperate1">
                                                       </div>

                                        <div class="clearfix"></div> <input type="hidden" name="cat_ids" id="cat_ids" value="1"> <input type="hidden" name="product_id" id="product_id" value="590009326"> <input type="hidden" name="manu_id" id="manu_id" value="1249"> </div> <div id="sizechart_dialog" class="modal fade" role="dialog"> <div class="modal-dialog"> <div class="modal-content dialog_content"> </div> </div> </div> <script>
window.tenant_id = [];
window.tenant_id.push('1002');

window.available_at_3p_seller = false;
window.available_at_1p_kirana = false;
window.available_at_rrl_fc = false;
window.available_at_rrl_store = true;
window.available_at_3p_kirana = false;

window.fynd_token = 'cU8ycF93UWtx';
window.fynd_app_id = 'NWVhNjgyMWIzNDI1YmIwN2M4MmEyNWMx';
</script></main>
        </div>  


           <?php include('include/footer.php');?>
             <!-- Copyright Section -->  </div> <div class="modal fade" id="rel_pincode_popup" data-easein="slideUpBigIn" tabindex="-1" role="dialog"> <div class="modal-dialog" role="document"> <div class="modal-content"> <div class="modal-header"> <h5 class="modal-title"><span>Happiness</span> Home Delivered...</h5> <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button></div> <div class="clearfix"></div> <div id="delivery_details"> <form id="rel_pincode_form"> <div class="lblock"> <label>Where do you want us to deliver your grocery?</label> <input type="text" class="inp_text" name="rel_pincode" id="rel_pincode" placeholder="Enter your Pincode" autocomplete="off" maxlength="6" /> <div id="rel_pin_msg"></div> <button type="submit" class="shopping_btn">Start Shopping</button> </div> <div class="rblock"> <img src="../../../../assets/smartweb/images/delivery_popup_jio.png" alt="Vedgun, Online Groceries Shop"> </div> <div class="clearfix"></div> </form> </div> </div> </div> </div>
             <?php include('include/myscript.php');?> 
              </body> 
<!-- Mirrored from www.Vedgun.com/c/groceries/fruits-vegetables/fresh-fruits/220 by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 30 Nov 2020 05:09:35 GMT -->
</html>