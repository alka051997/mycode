
<?php

 include('dbconnect.php');
 if(isset($_POST['submit'])){
    $name=$_POST['name'];
    $mobile=$_POST['mobile'];
    $email=$_POST['email'];
    $password=$_POST['password'];
    echo "insert into ac_party_led (l_name,mobile,email,password) values ('$name','$mobile','$email','$password')";
     $datamy=mysqli_query($con,"insert into ac_party_led (l_name,mobile,email,password) values ('$name','$mobile','$email','$password')");
     echo "<script>alert('Thank you for Registration....');</script>";
 }

 ?>
<!Doctype html>
 <html lang="en-US"> 
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
  <head>
   <title>Buy Grocery Online | Daily Needs Supermarket - Vedgun</title> 
   <meta charset="utf-8"> <meta name="robots" content="INDEX,FOLLOW"> 
   <meta name="description" content="Vedgun - Choose and Buy Online Grocery from a wide range of fruits, vegetables, baby care products, personal care products and much more. Shop Now !" /> 
   <meta name="keywords" content="Online Grocery, Fruits &amp; Vegetables, Staples, Dairy, Packages Foods, Home care, Personal Care" />
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"> <meta property="og:site_name" content="Vedgun" /> 
    <meta property="og:type" content="website" /> 
    <meta property="og:title" content="Buy Grocery Online | Daily Needs Supermarket - Vedgun" />
     <meta property="og:description" content="Vedgun - Choose and Buy Online Grocery from a wide range of fruits, vegetables, baby care products, personal care products and much more. Shop Now !" />
      <meta property="og:url" content="index.php" /> 
      <meta property="og:image" content="assets/global/logo-fb.png" /> <!-- Appple Touch Icons --> 
     <meta name="google-play-app" content="app-id=com.jpl.Vedgun">
          <meta name="apple-itunes-app" content="app-id=1522085683">
           <meta name="theme-color" content="#ffffff"/> 
          <?php include('include/files.php');?>
             <style> .multi-srch-hide{ display:none !important; } .ais-InfiniteHits-loadMore{ display:none; } .gift-page #saved_location{ display:none; } </style> <link rel="manifest" href="manifest.json"> <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
    new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
    j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
    '../www.googletagmanager.com/gtm5445.php?id='+i+dl;f.parentNode.insertBefore(j,f);
    })(window,document,'script','dataLayer','GTM-NQLHTD8');</script> <style> .otc-product-page #first_desc h2 {display: none} .otc-product-page #first_desc h2.pname{display: block!important;}.catalog-category-view.level-3 .white-bg.msite-list, .catalog-category-view.level-0 .white-bg.msite-list{display:none !important} .cat-fashion .right-block .empty_listing {position:absolute;z-index:3} .compare_products{ display:none; }#bought_together{display:none !important}.prod-groceries #similar_products{display: none;} .prod-groceries .section-seperate1{display: none;} .prod-fashion .new_product #product_details #left_col .gallery-top,.prod-groceries .new_product #product_details #left_col .gallery-top{height: auto;} .gift-page .all-product .row product-list .col-md-3:last-child .price-box{display:none} .gift-page #free_gift_wrap{display:none !important} .best_deals .add_banner {margin: 0 auto;text-align: center;} .best_deals .add_banner img {width: auto;height: 100%;border-radius: 0;} .best_deals .section-seperate{display: none;} .prod-jewellery .brand_name{display:none !important} .prod-jewellery .prepaid_msg{display:block;font-size:14px;color:#dd0608;font-family: sans-serif;} .aa-dropdown-menu .aa-suggestions .aa-suggestion .product-item-info.search-jewellery a .drug_img { background: url(assets/version1605113383/smartweb/images/search_icons/search_jewellery.png) center no-repeat; background-size: 40px; } 
     .custreg-form  {
    background: #eee;
    border-radius: 16px;
    overflow: hidden;

    margin-top: 30px;
    padding: 20px;

}
  .ac-title{
    padding: 0;
    margin: 0 0 8px;
    font-family: sans-serif;
    font-size: 24px;
    color: #000;
  }
  .sign-txt{

    padding: 0 20px 16px!important;
    margin: 0!important;
  }
  .topcol{
    padding: 0 20px;
    
  }
  .md-form{
    margin: 1rem 0 24px;
    display: inline-block;
    width: 100%;
  }
  .singalotpcol{
    border: 1px solid rgba(0,0,0,.04);
    font-family: sans-serif;
    font-size: 14px;
    color: #000;
    padding: 9px 0 9px 12px;
    margin: 0;
    width: calc(100% - 3.5rem);
    border-radius: 4px;
  }
  .btn-login{
        background: #073a09;
    font-family: sans-serif;
    font-size: 14px;
    color: #fff;
    line-height: 20px;
    border-radius: 4px;
    box-shadow: none!important;
    -webkit-box-shadow: none!important;
    -moz-box-shadow: none!important;
    letter-spacing: 1px;
    text-transform: capitalize;
    padding: 10px 6px;
    width: 100%;
    height: 100%;
    margin-top: 20;
    border: 0;
  }
    </style> <script>
        window.default_pin = '400020';
        window.algolia_filter = false;
        window.algolia_app_id = "3YP0HP3WSH";
        window.algolia_api_key = "aace3f18430a49e185d2c1111602e4b1";
        //window.algolia_index_name = "";
        window.algolia_suffix = 'prod_mart';
                window.product_image_path = "index.php";
                window.location_api = "AIzaSyBfquJmLRraJi0sNjV14BQWqGlMAEzqAIw";
        window.default_vertical_city_code = JSON.parse('{"ELECTRONICS": "null","FASHION": null,"GROCERIES": "6221", "JEWELLERY": "PANINDIAJEWEL"}');
        window.inventory_store_code = JSON.parse('{"GROCERIES":["6210"],"FASHION":null,"ELECTRONICS":null}');
    </script> </head> <body class="cms-home Vedgun_home"> <noscript><iframe src="https://www.googletagmanager.com/ns.php?id=GTM-NQLHTD8" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript> <div class="page-wrapper"> 

     <?php include('include/header.php');?>
<main _ngcontent-dxl-c2=""><div _ngcontent-dxl-c2="" class="container"><router-outlet _ngcontent-dxl-c2=""></router-outlet><app-login _nghost-dxl-c9=""><!----><div _ngcontent-dxl-c9="" class="custloginmain"><!----><!----><!----><!----><div _ngcontent-dxl-c9="" class="custreg-form "><div _ngcontent-dxl-c9="" class="innermain row m-0"><div _ngcontent-dxl-c9="" class="col-lg-6 leftcol p-0 d-none d-sm-block"><img _ngcontent-dxl-c9="" class="pro-img" src="images/login-banner.jpg"></div><div _ngcontent-dxl-c9="" class="col-lg-6 rightcol p-0"><h2 _ngcontent-dxl-c9="" class="ac-title">Sign up</h2><div _ngcontent-dxl-c9="" class="innercol"><p _ngcontent-dxl-c9="" class="sign-txt">Please enter your details.</p>

  <form  action='' method='POST'>

    <div _ngcontent-dxl-c9="" class="topcol">
      <div _ngcontent-dxl-c9="" class="md-form position-relative">
        <input _ngcontent-dxl-c9="" autocomplete="off" class="form-control" id="name" name='name' placeholder="Your First Name" type="text" required>
      </div>
      <div _ngcontent-dxl-c9="" class="md-form position-relative">
        <input _ngcontent-dxl-c9="" autocomplete="off" class="form-control" name='name'  id="mobile"  placeholder="Your Mobile No" onchange="validamobile();" type="text" required onchange='return validate'>
      </div>
      <div _ngcontent-dxl-c9="" class="md-form position-relative">
        <input  autocomplete="off" class="form-control" id="email" name="email" placeholder="Enter your Email Id" type="email" required>
      </div>
    </div>
    <div _ngcontent-dxl-c9="" class="topcol">
      <div _ngcontent-dxl-c9="" class="md-form position-relative">
        <input _ngcontent-dxl-c9="" autocomplete="off" class="form-control" id="password" name='password' placeholder="Enter your Password" type="password" required>
       
      </div>
    </div>
    <span id='message'></span>
    <div _ngcontent-dxl-c9="" class="topcol">
      <div _ngcontent-dxl-c9="" class="md-form position-relative">
        <input _ngcontent-dxl-c9="" appblockcopypaste="" class="form-control"  id="cpassword" placeholder="Enter your Password" type="password" name='cpassword' required>
        
      </div>
    </div>
    <!---->
    <div _ngcontent-dxl-c9="" class="refotpbox pt-0">
      <h2 _ngcontent-dxl-c9="" class="ac-title">Verify</h2>
      <div _ngcontent-dxl-c9="" class="md-form otprow position-relative m-0">
        <div _ngcontent-dxl-c9="" class="otp-inputrow singalotp-inputrow">
          <input _ngcontent-dxl-c9="" class="singalotpcol logotp ng-untouched ng-pristine ng-invalid" formcontrolname="regotp0" onchange="return validaotp();" maxlength="4" numbersonly="" name='otp' id='otp' placeholder="Enter your OTP" type="tel">
        </div>
      </div>
    </div>
    <div _ngcontent-dxl-c9="" class="actioncol text-center"><div _ngcontent-dxl-c9="" style="margin-top: 20px;" class="form-check p-0">

      <button _ngcontent-dxl-c9="" class="btn-login" type="submit" type='submit' name='submit'>verify</button>

    </div></div></form></div></div></div><div _ngcontent-dxl-c9="" class="termsbox"><p _ngcontent-dxl-c9="" class="terms-service"> By continuing you agree to our <a _ngcontent-dxl-c9="" href="/terms-and-conditions">Terms of service</a><br _ngcontent-dxl-c9=""> and <a _ngcontent-dxl-c9="" href="/privacy-policy">Privacy &amp; Legal Policy.</a></p></div></div><!----></div><div _ngcontent-dxl-c9="" aria-hidden="true" aria-labelledby="myModalLabel" class="modal fade addressmodal" mdbmodal="" role="dialog" tabindex="-1"><div _ngcontent-dxl-c9="" class="modal-dialog modal-dialog-centered" role="document"><div _ngcontent-dxl-c9="" class="modal-content"><div _ngcontent-dxl-c9="" class="modal-header text-center"><button _ngcontent-dxl-c9="" aria-label="Close" class="close" data-dismiss="modal" type="button"><span _ngcontent-dxl-c9="" aria-hidden="true"></span></button></div><div _ngcontent-dxl-c9="" class="modal-body"><div _ngcontent-dxl-c9="" class="modalinner"><!----><div _ngcontent-dxl-c9="" class="entermobilno"><h4 _ngcontent-dxl-c9="" class="modal-title">Phone Number</h4>
  <div _ngcontent-dxl-c9="" class="innercol"><p _ngcontent-dxl-c9="" class="sign-txt">Enter your phone number to access your orders, special offers, health tips and more!</p><div _ngcontent-dxl-c9="" class="mobibox"><div _ngcontent-dxl-c9="" class="mobilabel">PHONE NUMBER</div><div _ngcontent-dxl-c9="" class="mobiinput"><span _ngcontent-dxl-c9="" class="mobipre">+91</span><input _ngcontent-dxl-c9="" id="socialloginMobileno" name="socialloginMobileno" placeholder="Enter Mobile Number" type="text" value=""></div></div></div></div><!----><div _ngcontent-dxl-c9="" class="action"><button _ngcontent-dxl-c9="" class="btn" type="button">Submit</button></div></div></div><div _ngcontent-dxl-c9="" class="modal-footer"></div></div></div></div></app-login></div></main>

<?php include('include/footer.php');?>

    
      </div> <div class="modal fade" id="rel_pincode_popup" data-easein="slideUpBigIn" tabindex="-1" role="dialog"> <div class="modal-dialog" role="document"> <div class="modal-content"> <div class="modal-header"> <h5 class="modal-title"><span>Happiness</span> Home Delivered...</h5> <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button></div> <div class="clearfix"></div> <div id="delivery_details"> <form id="rel_pincode_form"> <div class="lblock"> <label>Where do you want us to deliver your grocery?</label> <input type="text" class="inp_text" name="rel_pincode" id="rel_pincode" placeholder="Enter your Pincode" autocomplete="off" maxlength="6" /> <div id="rel_pin_msg"></div> <button type="submit" class="shopping_btn">Start Shopping</button> </div> <div class="rblock"> <img src="assets/smartweb/images/delivery_popup_jio.png" alt="Vedgun, Online Groceries Shop"> </div> <div class="clearfix"></div> </form> </div> </div> </div> </div>
</body> 
<script>
  $('#password, #confirm_password').on('keyup', function () {
    if ($('#password').val() == $('#confirm_password').val()) {
        $('#message').html('Matching').css('color', 'green');
    } else 
        $('#message').html('Not Matching').css('color', 'red');
});
</script>
 <script>
    function validamobile(){
      

var mobile = document.getElementById('mobile').value;
 
  var str = mobile; 
  var res = str.substring(0, 1);
  //document.getElementById("demo").innerHTML = res;

    if(res>5 && str.length == 10){
      // alert(mobile);
    $.ajax({
        type: "POST",
        url: "mobile.php",
        data:'mobile='+mobile,        
        success: function(data1){
            alert(data1);
            
          
        }
        });
  } else {

alert('Please enter valid mobile no.');
              document.getElementById('mobile').value='';
               document.getElementById('mobile').focus();

  }

            }
  function validaotp(){

 var otp = document.getElementById('otp').value;
 // alert(otp);
  
    $.ajax({
        type: "POST",
        url: "otp.php",
        data:'otp=' +otp,
        
        success: function(data){
           //alert(data);
            if(data=='false'){

              alert('Please enter correct otp..');
              document.getElementById('otp').value='';
               document.getElementById('otp').focus();
               return false;
            } else {

              
       $('.submitotp').removeAttr("disabled");
              //alert('OTP is sent to - ' +data);

            }
             
          
        }
        });
  }
    
</script>   


       <script type="application/ld+json">
{ 
    "@context" : "http://schema.org",
    "@type" : "WebSite",
    "url" : "https://www.Vedgun.com/",
    "logo": "https://www.Vedgun.com/assets/smartweb/images/Vedgun_logo.svg",
    "potentialAction": {
        "@type": "SearchAction",
        "target": "https://www.Vedgun.com/catalogsearch/result?q={search_term_string}",
        "query-input": "required name=search_term_string"
    },
    "sameAs": [
        "https://www.facebook.com/VedgunOfficial/",
        "https://twitter.com/Vedgun",
        "https://www.instagram.com/Vedgunofficial"
    ],
    "contactPoint" : [
        { "@type" : "ContactPoint",
        "telephone" : "18008901222",
        "email":"cs@Vedgun.com", 
        "contactType":"customer service" 
        }
    ]
}
 </script> <input type="hidden" id="mstar_api_baseurl" value="https://www.Vedgun.com/mst/rest/v1/" /> <input type="hidden" id="gift_api_url" value="/api/v1/myorders/giftbulkordersubmit" /> <input type="hidden" id="gift_auth" value="Z2lmdGJ1bGtvcmRlcjpVMnBZVVNaaUpXaEtka2xuWVZsNA==" /> <script type="text/javascript" src="assets/smartweb/js/lazysizes-umd.min.js" async></script> <script type="text/javascript" src="assets/smartweb/js/jquery-3.4.1.min.js" crossorigin="anonymous"></script> <script type="text/javascript" src="assets/smartweb/js/jquery-ui.min.js" defer crossorigin="anonymous"></script> <script src="assets/smartweb/js/bootstrap.min.js" defer crossorigin="anonymous"></script> <script type="text/javascript" src="assets/smartweb/js/clipboard.min.js" defer crossorigin="anonymous"></script> <script type="text/javascript" src="assets/smartweb/js/swiper.min.js" defer crossorigin="anonymous"></script> <script src="assets/smartweb/js/algolia-autocomplete.min.js" defer crossorigin="anonymous"></script> <script src="../cdn.jsdelivr.net/algoliasearch/3/algoliasearch.min.js" defer crossorigin="anonymous"></script> <script src="assets/smartweb/js/jquery.cookie.min.js" defer crossorigin="anonymous"></script> <script type="text/javascript" src="assets/smartweb/js/bootstrap.notify.min.js" defer crossorigin="anonymous"></script> <script type="text/javascript" src="assets/smartweb/js/jquery.validate.min.js" defer crossorigin="anonymous"></script> <script type="text/javascript" src="assets/smartweb/js/jquery.md5.min.js" defer crossorigin="anonymous"></script> <script>
    $(document).ready(function () {
        $('.combo-view-more').click(function(){
            var target = $(this).attr("data-target");
            $(target).modal();
        });
    });
</script> <script>
    $(document).ready(function(){
        var userId = localStorage.getItem('userid');
        var authToken = localStorage.getItem('authtoken');
        var displayName = localStorage.getItem('displayname');
        var login_pincode = localStorage.getItem('nms_mgo_pincode');
                if(login_pincode && (login_pincode !="")) {
            $.cookie("nms_mgo_pincode", login_pincode, { expires : 1, path    : '/' });
        }
    });
</script> <script type="text/javascript">
$(document).ready(function () {
    localStorage.removeItem('loginpage');
    window.user_id     = (localStorage.getItem('userid')!=null) ? localStorage.getItem('userid'):"" ;
    window.auth_token  = (localStorage.getItem('authtoken')!=null) ? localStorage.getItem('authtoken'):"";
    window.cust_dname  = (localStorage.getItem('displayname')!=null) ? localStorage.getItem('displayname'):"";
        window.login_session = {
      "async": true,
      "crossDomain": true,
      "url": "https://www.Vedgun.com/mst/rest/v1/entity/customer/get_details",
      "method": "GET",
      "headers": {
        "userid": window.user_id,
        "authtoken": window.auth_token
      }
    };
    if((user_id!="" && user_id != 0) && (cust_dname!="")){
        $('.login #logged_user').text("");
        $('.login #logged_user').append(cust_dname);
        $('.login a:first').hide();
        $('.login #logged_user').show();
        $("#customer-name").text("Hello, "+cust_dname);
        $("#profile-link").attr("href","/customer/account");
        $("#sign_in_out").text('Logout').attr("href","/customer/account/logout");
    } else {
        $('.login #logged_user').hide();
        $('.login a:first').show();
    }
        $('.logged').show();
});
</script> <input type="hidden" name="enable_fbpixel" id="enable_fbpixel" value="0" /> <script type="text/javascript" src="assets/version1605113383/smartweb/js/main.min.js" defer crossorigin="anonymous"></script> <script type="text/javascript" src="assets/version1605113383/smartweb/js/cart.min.js" defer crossorigin="anonymous"></script> <script src="assets/version1605113383/smartweb/js/search_autocomplete.min.js" defer crossorigin="anonymous"></script> <script type="text/javascript" src="assets/smartweb/js/url.min.js" defer crossorigin="anonymous"></script> <script>
$(document).ready(function(){
    var custEmail = (localStorage.getItem('displayemail')!=undefined) ? localStorage.getItem('displayemail'):"";
    var custNew = (localStorage.getItem('new_customer')!=undefined) ? localStorage.getItem('new_customer'):"";
    var cityName = (localStorage.getItem('nms_mgo_city')!=undefined) ? localStorage.getItem('nms_mgo_city').toUpperCase() : "NA";
                if((user_id!="") && (custEmail!="")){
            dataLayer.push({"ecommerce":{"currencyCode":"INR"},"customer":{"isLoggedIn":true,"id":user_id,"email":$.md5(custEmail),"new_customer":custNew,"city":cityName},"pageType":"homepage"});
        } else {
        dataLayer.push({"ecommerce":{"currencyCode":"INR"},"customer":{"isLoggedIn":false,"city":cityName},"pageType":"homepage"});
        }
         });
</script> <script>
        $(document).ready(function(){
            if((localStorage.getItem('paynowID')) && (localStorage.getItem('paynowID')!=='')){
                localStorage.removeItem('paynowID');
                localStorage.removeItem('m2_errlist');      
            }
        });    
    </script> <script>
function getPageType(){
    var pageType = 'other pages';
    if($("body").hasClass("cms-home")){
        pageType = "Home Page";
    }else if($("body").hasClass("catalog-category-view")){
        pageType = "category page";
    }else if($("body").hasClass("catalog-product-view")){
        pageType = "Product Details Page";
    }
    else if($("body").hasClass("search-result-page")){
        pageType = "Search Page";
    }            
    return pageType;
}   

function trackGoogleEvents(category,action,label){
    if("ga"in window){
        tracker=ga.getAll()[0];
        if(tracker){
            tracker.send("event",category,action,label);
        }
    }
}



$(document).ready(function(){  
    $('#size_chart_btn').on('click',function(){
        var dataURL = $(this).attr('data-href');
        $('#sizechart_dialog .dialog_content').load(dataURL,function(){
            $('#sizechart_dialog').modal({show:true,backdrop:'static'});
        });
    });
    $(".add_to_cart_fixed .cartbag").click(function(){
        trackGoogleEvents("New Click actions","Add to cart button","Product Holder");
    });

    $("#search").focus(function(){
        trackGoogleEvents("New Click actions","Search","");
    });

    $(".mini-cart").click(function(){
        var pageType = 'other pages';
        if($("body").hasClass("cms-home")){
            pageType = "home page";
        }
        else if($("body").hasClass("catalog-category-view")){
            pageType = "category page";
        }
        else if($("body").hasClass("catalog-product-view")){
            pageType = "product page";
        }
        trackGoogleEvents("New Click actions","Cart",pageType);
    });  

             
    $(".home-slides .swiper-slide").click(function(){
        trackGoogleEvents("Home Banner","Primary Banners","Home Page");                
    });

    $(".home-category-swipe .swiper-slide").click(function(){
        var catname = $(this).find(".clsgetname").text();
        trackGoogleEvents("Home Explore Categories",catname,"Home Page");                
    }); 

    $(".home-best-seller .swiper-slide").click(function(){
        var prodname = $(this).find(".clsgetname").text();
        trackGoogleEvents("Home Best Sellers",prodname,"Home Page");                
    });
    });
</script> <script>
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('service-worker.js', {
          scope: '/'
        });
    });
}
</script> <script>
  var ALGOLIA_INSIGHTS_SRC = "//cdn.jsdelivr.net/npm/search-insights@1.3.1";

  !function(e,a,t,n,s,i,c){e.AlgoliaAnalyticsObject=s,e[s]=e[s]||function(){
  (e[s].queue=e[s].queue||[]).push(arguments)},i=a.createElement(t),c=a.getElementsByTagName(t)[0],
  i.async=1,i.src=n,c.parentNode.insertBefore(i,c)
  }(window,document,"script",ALGOLIA_INSIGHTS_SRC,"aa");


  // Initialize library
  aa('init', {
    appId: window.algolia_app_id,
    apiKey: window.algolia_api_key
  });
</script> <script>
if($("body").hasClass("gift-page")){
    $(".pages-items a").each(function(i,el){
        var href = $(el).attr("href");
        if (href.indexOf('/gifting/page/2') > -1) {
            $(el).attr("href",href+"?prod_mart_master_vertical_products_popularity");
        }
    });
}
</script> <script>
if($("body").hasClass("prod-jewellery")){
$( "#price_section" ).after( "<div class='clearfix'></div><p class='prepaid_msg'>Only Prepaid Orders Allowed</p>" );
}
</script> 
<!-- Mirrored from www.Vedgun.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 30 Nov 2020 05:08:16 GMT -->
</html>