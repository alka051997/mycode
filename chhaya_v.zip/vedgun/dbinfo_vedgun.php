<?php

if($_SERVER["SERVER_NAME"]=="localhost" || $_SERVER["SERVER_NAME"]=="192.168.1.102")
{
	$host_name="localhost";
	$db_name="vedgun_web";
	$db_user="root";
	$db_pwd="";
	$imglink="http://localhost:8080/i_audit/i_audit/upload/";
}
else
{ 
	$host_name="localhost";
	$db_name="dial3z5z_superclient";
	$db_user="dial3z5z_super";
	$db_pwd="iAudit@#2019";
	$imglink="http://localhost:8080/i_audit/i_audit/upload/";
}
//echo "$host_name--$db_name--$db_user--$db_pwd";
$con_sup = mysqli_connect("$host_name","$db_user","$db_pwd");
$con_sup1=mysqli_select_db($con_sup,"$db_name");
if(!$con_sup1){
	echo "connection Error";
}

/*
include("lib/getval.php");


$cmn = new Comman();
$createdate = date("Y-m-d H:i:s");

$TitleName = "iAudit";
 
*/ 
?>