
<?php

 include('dbconnect.php');

 ?>
<!doctype html> <html lang="en-US"> 
<!-- Mirrored from www.Vedgun.com/terms-and-conditions by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 30 Nov 2020 05:35:21 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head> <title>Return Plicy - Buy Grocery Online at Best Prices Pan India</title> <meta charset="utf-8"> <meta name="robots" content="INDEX,FOLLOW"> <meta name="description" content="Find the Terms and Condition stated by Reliancesmart.in." /> <meta name="keywords" content="" /> <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"> <meta property="og:site_name" content="Vedgun" /> <meta property="og:type" content="website" /> <meta property="og:title" content="Terms and Condition - Buy Grocery Online at Best Prices Pan India" /> <meta property="og:description" content="Find the Terms and Condition stated by Reliancesmart.in." /> <meta property="og:url" content="terms-and-conditions.php" /> <meta property="og:image" content="assets/global/logo-fb.png" /> <!-- Appple Touch Icons -->
 <?php include('include/files.php');?>
 <style> .multi-srch-hide{ display:none !important; } .ais-InfiniteHits-loadMore{ display:none; } .gift-page #saved_location{ display:none; } </style> <link rel="manifest" href="manifest.json"> <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
		new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
		j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
		'../www.googletagmanager.com/gtm5445.php?id='+i+dl;f.parentNode.insertBefore(j,f);
		})(window,document,'script','dataLayer','GTM-NQLHTD8');</script> <style> .otc-product-page #first_desc h2 {display: none} .otc-product-page #first_desc h2.pname{display: block!important;}.catalog-category-view.level-3 .white-bg.msite-list, .catalog-category-view.level-0 .white-bg.msite-list{display:none !important} .cat-fashion .right-block .empty_listing {position:absolute;z-index:3} .compare_products{ display:none; }#bought_together{display:none !important}.prod-groceries #similar_products{display: none;} .prod-groceries .section-seperate1{display: none;} .prod-fashion .new_product #product_details #left_col .gallery-top,.prod-groceries .new_product #product_details #left_col .gallery-top{height: auto;} .gift-page .all-product .row product-list .col-md-3:last-child .price-box{display:none} .gift-page #free_gift_wrap{display:none !important} .best_deals .add_banner {margin: 0 auto;text-align: center;} .best_deals .add_banner img {width: auto;height: 100%;border-radius: 0;} .best_deals .section-seperate{display: none;} .prod-jewellery .brand_name{display:none !important} .prod-jewellery .prepaid_msg{display:block;font-size:14px;color:#dd0608;font-family: sans-serif;} .aa-dropdown-menu .aa-suggestions .aa-suggestion .product-item-info.search-jewellery a .drug_img { background: url(assets/version1605113383/smartweb/images/search_icons/search_jewellery.png) center no-repeat; background-size: 40px; } </style> <script>
        window.default_pin = '400020';
        window.algolia_filter = false;
        window.algolia_app_id = "3YP0HP3WSH";
        window.algolia_api_key = "aace3f18430a49e185d2c1111602e4b1";
        //window.algolia_index_name = "";
        window.algolia_suffix = 'prod_mart';
                window.product_image_path = "index.php";
                window.location_api = "AIzaSyBfquJmLRraJi0sNjV14BQWqGlMAEzqAIw";
        window.default_vertical_city_code = JSON.parse('{"ELECTRONICS": "null","FASHION": null,"GROCERIES": "6221", "JEWELLERY": "PANINDIAJEWEL"}');
        window.inventory_store_code = JSON.parse('{"GROCERIES":["6210"],"FASHION":null,"ELECTRONICS":null}');
    </script> </head> 
    <body class="static-page cms-terms-and-conditions"> <noscript><iframe src="https://www.googletagmanager.com/ns.php?id=GTM-NQLHTD8" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript> <div class="page-wrapper"> <div class="top-section"> 
    <?php include('include/header.php');?> 
    </div>
     <main id="maincontent" class=" static-content"> 
        <div class="breadcrumbs d-none d-sm-block">
         <ul class="items"> 
            <li class="home"> <a href="index.php" title="Go to Home"> Home </a> </li> 
            <li class="home"> <span>Return Policy</span> </li> 
         </ul>
       </div> 
<div class='container'>
        <div class='col-md-12'>
           <?php 
         $data_about=mysqli_query($con_sup,"select return_policy from e_commerce_details  where sup_company_id='$sup_companyid'");
         $row_about=mysqli_fetch_array($data_about);
         $return_privacy=$row_about['return_policy'];
         


         ?>
           <?php echo $return_privacy;?>

   
         
        </div> 
    </div></main>
        
         <?php include('include/footer.php');?>
          </div> <div class="modal fade" id="rel_pincode_popup" data-easein="slideUpBigIn" tabindex="-1" role="dialog"> <div class="modal-dialog" role="document"> <div class="modal-content"> <div class="modal-header"> <h5 class="modal-title"><span>Happiness</span> Home Delivered...</h5> <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button></div> <div class="clearfix"></div> <div id="delivery_details"> <form id="rel_pincode_form"> <div class="lblock"> <label>Where do you want us to deliver your grocery?</label> <input type="text" class="inp_text" name="rel_pincode" id="rel_pincode" placeholder="Enter your Pincode" autocomplete="off" maxlength="6" /> <div id="rel_pin_msg"></div> <button type="submit" class="shopping_btn">Start Shopping</button> </div> <div class="rblock"> <img src="assets/smartweb/images/delivery_popup_jio.png" alt="Vedgun, Online Groceries Shop"> </div> <div class="clearfix"></div> </form> </div> </div> </div> </div> <script type="application/ld+json">
            {        
                "@context": "https://schema.org",
                "@type": "BreadcrumbList",
                "itemListElement": [
    {
        "@type": "ListItem",
        "position": 0,
        "name": "Home",
        "item": "https://www.Vedgun.com/"
    },
    {
        "@type": "ListItem",
        "position": 1,
        "name": "Terms and Conditions",
        "item": "https://www.Vedgun.com/terms-and-conditions"
    }
]            }
        </script> <input type="hidden" id="mstar_api_baseurl" value="https://www.Vedgun.com/mst/rest/v1/" /> <input type="hidden" id="gift_api_url" value="/api/v1/myorders/giftbulkordersubmit" /> <input type="hidden" id="gift_auth" value="Z2lmdGJ1bGtvcmRlcjpVMnBZVVNaaUpXaEtka2xuWVZsNA==" /> <script type="text/javascript" src="assets/smartweb/js/lazysizes-umd.min.js" async></script> <script type="text/javascript" src="assets/smartweb/js/jquery-3.4.1.min.js" crossorigin="anonymous"></script> <script type="text/javascript" src="assets/smartweb/js/jquery-ui.min.js" defer crossorigin="anonymous"></script> <script src="assets/smartweb/js/bootstrap.min.js" defer crossorigin="anonymous"></script> <script type="text/javascript" src="assets/smartweb/js/clipboard.min.js" defer crossorigin="anonymous"></script> <script type="text/javascript" src="assets/smartweb/js/swiper.min.js" defer crossorigin="anonymous"></script> <script src="assets/smartweb/js/algolia-autocomplete.min.js" defer crossorigin="anonymous"></script> <script src="../cdn.jsdelivr.net/algoliasearch/3/algoliasearch.min.js" defer crossorigin="anonymous"></script> <script src="assets/smartweb/js/jquery.cookie.min.js" defer crossorigin="anonymous"></script> <script type="text/javascript" src="assets/smartweb/js/bootstrap.notify.min.js" defer crossorigin="anonymous"></script> <script type="text/javascript" src="assets/smartweb/js/jquery.validate.min.js" defer crossorigin="anonymous"></script> <script type="text/javascript" src="assets/smartweb/js/jquery.md5.min.js" defer crossorigin="anonymous"></script> <script>
    $(document).ready(function () {
        $('.combo-view-more').click(function(){
            var target = $(this).attr("data-target");
            $(target).modal();
        });
    });
</script> <script>
    $(document).ready(function(){
        var userId = localStorage.getItem('userid');
        var authToken = localStorage.getItem('authtoken');
        var displayName = localStorage.getItem('displayname');
        var login_pincode = localStorage.getItem('nms_mgo_pincode');
                if(login_pincode && (login_pincode !="")) {
            $.cookie("nms_mgo_pincode", login_pincode, { expires : 1, path    : '/' });
        }
    });
</script> <script type="text/javascript">
$(document).ready(function () {
    localStorage.removeItem('loginpage');
    window.user_id     = (localStorage.getItem('userid')!=null) ? localStorage.getItem('userid'):"" ;
    window.auth_token  = (localStorage.getItem('authtoken')!=null) ? localStorage.getItem('authtoken'):"";
    window.cust_dname  = (localStorage.getItem('displayname')!=null) ? localStorage.getItem('displayname'):"";
        window.login_session = {
      "async": true,
      "crossDomain": true,
      "url": "https://www.Vedgun.com/mst/rest/v1/entity/customer/get_details",
      "method": "GET",
      "headers": {
        "userid": window.user_id,
        "authtoken": window.auth_token
      }
    };
    if((user_id!="" && user_id != 0) && (cust_dname!="")){
        $('.login #logged_user').text("");
        $('.login #logged_user').append(cust_dname);
        $('.login a:first').hide();
        $('.login #logged_user').show();
        $("#customer-name").text("Hello, "+cust_dname);
        $("#profile-link").attr("href","/customer/account");
        $("#sign_in_out").text('Logout').attr("href","/customer/account/logout");
    } else {
        $('.login #logged_user').hide();
        $('.login a:first').show();
    }
        $('.logged').show();
});
</script> <input type="hidden" name="enable_fbpixel" id="enable_fbpixel" value="0" /> <script type="text/javascript" src="assets/version1605113383/smartweb/js/main.min.js" defer crossorigin="anonymous"></script> <script type="text/javascript" src="assets/version1605113383/smartweb/js/cart.min.js" defer crossorigin="anonymous"></script> <script src="assets/version1605113383/smartweb/js/search_autocomplete.min.js" defer crossorigin="anonymous"></script> <script type="text/javascript" src="assets/smartweb/js/url.min.js" defer crossorigin="anonymous"></script> <script>
function getPageType(){
    var pageType = 'other pages';
    if($("body").hasClass("cms-home")){
        pageType = "Home Page";
    }else if($("body").hasClass("catalog-category-view")){
        pageType = "category page";
    }else if($("body").hasClass("catalog-product-view")){
        pageType = "Product Details Page";
    }
    else if($("body").hasClass("search-result-page")){
        pageType = "Search Page";
    }            
    return pageType;
}   

function trackGoogleEvents(category,action,label){
    if("ga"in window){
        tracker=ga.getAll()[0];
        if(tracker){
            tracker.send("event",category,action,label);
        }
    }
}



$(document).ready(function(){  
    $('#size_chart_btn').on('click',function(){
        var dataURL = $(this).attr('data-href');
        $('#sizechart_dialog .dialog_content').load(dataURL,function(){
            $('#sizechart_dialog').modal({show:true,backdrop:'static'});
        });
    });
    $(".add_to_cart_fixed .cartbag").click(function(){
        trackGoogleEvents("New Click actions","Add to cart button","Product Holder");
    });

    $("#search").focus(function(){
        trackGoogleEvents("New Click actions","Search","");
    });

    $(".mini-cart").click(function(){
        var pageType = 'other pages';
        if($("body").hasClass("cms-home")){
            pageType = "home page";
        }
        else if($("body").hasClass("catalog-category-view")){
            pageType = "category page";
        }
        else if($("body").hasClass("catalog-product-view")){
            pageType = "product page";
        }
        trackGoogleEvents("New Click actions","Cart",pageType);
    });  

    });
</script> <script>
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('service-worker.js', {
          scope: '/'
        });
    });
}
</script> <script>
  var ALGOLIA_INSIGHTS_SRC = "//cdn.jsdelivr.net/npm/search-insights@1.3.1";

  !function(e,a,t,n,s,i,c){e.AlgoliaAnalyticsObject=s,e[s]=e[s]||function(){
  (e[s].queue=e[s].queue||[]).push(arguments)},i=a.createElement(t),c=a.getElementsByTagName(t)[0],
  i.async=1,i.src=n,c.parentNode.insertBefore(i,c)
  }(window,document,"script",ALGOLIA_INSIGHTS_SRC,"aa");


  // Initialize library
  aa('init', {
    appId: window.algolia_app_id,
    apiKey: window.algolia_api_key
  });
</script> <script>
if($("body").hasClass("gift-page")){
    $(".pages-items a").each(function(i,el){
        var href = $(el).attr("href");
        if (href.indexOf('/gifting/page/2') > -1) {
            $(el).attr("href",href+"?prod_mart_master_vertical_products_popularity");
        }
    });
}
</script> <script>
if($("body").hasClass("prod-jewellery")){
$( "#price_section" ).after( "<div class='clearfix'></div><p class='prepaid_msg'>Only Prepaid Orders Allowed</p>" );
}
</script> </body> </html>