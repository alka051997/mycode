<?php
$tokencode="i_audit";
include("lib/enc.php");
ini_set('memory_limit', '-1');
date_default_timezone_set('Asia/Calcutta');
error_reporting('NOTICE');

if($_SERVER["SERVER_NAME"]=="localhost" || $_SERVER["SERVER_NAME"]=="i_audit" || $_SERVER["SERVER_NAME"]=="192.168.1.102")
{
	$host_name="localhost";
	$db_name="i_audit";
	$db_user="root";
	$db_pwd="";	
	 $sup_companyid = 2;
}
else
{ 
	 $sup_companyid = 16;
   	 $sttDatabase = "select databasedetails.*,databasedetails.companyid  from databasedetails left join sup_company on sup_company.companyid=databasedetails.companyid  where sup_company.enable=1 and sup_company.companyid='$sup_companyid'";
	$getDatabase = mysqli_query($con,$sttDatabase);
	while($rowDatabase = mysqli_fetch_array($getDatabase))
	{
		// connect to selected database to update schoolregmaster //
		if($rowDatabase['databasename'] != "" && $rowDatabase['databaseuser'] != "")
		{
			$key = "!N0H@ck#";
			$host_name = decrypt($rowDatabase['servername'], $key);
			$db_user = decrypt($rowDatabase['databaseuser'], $key);
			$db_pwd = decrypt($rowDatabase['dbpassword'], $key);
			$db_name = decrypt($rowDatabase['databasename'], $key);
		}
	}
}
//echo "$host_name--$db_name--$db_user--$db_pwd";
$con = mysqli_connect("$host_name","$db_user","$db_pwd");
mysqli_select_db($con,"$db_name");

include("lib/getval.php");
$cmn = new Comman();
$createdate = date("Y-m-d H:i:s");

$TitleName = "iAudit";
 
 
?>