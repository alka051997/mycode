<style type="text/css">
    
    #social img{
        width: 40px;
    }
    .pay{
        font-size: 15px;
    }
</style>
<!-- Modal -->
<div class="modal fade" id="cart" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content" style="padding: 10px;">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Cart</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <table class="modal-body show-cart">
       
        <div style="color: red;
    font-weight: 800;
    margin-bottom: 20px;
    margin-top: 20px;
    font-size: 18px;">Total price: $<span class="total-cart"></span></div>
      </table>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary"><a href='cart.php' style="color: #fff">Order now</a></button>
      </div>
    </div>
  </div>
</div> 

     <footer> <div class="footer-container"> 

     	<ul>
			<li> <h2>Most Popular Categories</h2> </li>
		  <?php 
            // echo "select * from item_master where sup_company_id='$sup_companyid    ' and delete_data='0' group by sup_category_name order by cat_id";
            // die;
                 $data_foot=mysqli_query($con_sup,"select * from item_master where sup_company_id='$sup_companyid' and delete_data='0' group by sup_category_name order by cat_id");
                 while($row_foot=mysqli_fetch_array($data_foot)){
                  $category_name_foot=$row_foot['sup_category_name'];
                    $category_id=$row_foot['cat_id'];
			  ?> 
			<li><a href="c/groceries/staples/13.php"><?php echo $category_name_foot;?></a></li>
			<?php } ?> 
     	  </ul> 
     	  <ul> 
			<li> <h2>Customer Services</h2> </li>
			<li><a href="about-us.php">About Us</a></li> 
			<li><a href="faqs.php">FAQ</a></li>
            <li><a href="at_your_service.php">At your service</a></li> 
			<li><a href="terms_and_conditions.php">Terms and conditions</a></li> 
			<li><a href="privacy_policy.php" target="_blank" rel="noopener">Privacy policy</a></li>
			<li><a href="return_policy.php" target="_blank" rel="noopener">Return policy</a></li>
            
     	  </ul>
            <ul> 
            <li> <h2>Download App</h2> </li> 
            <li><a href="#"><img ng-if="!vm.VERSIONED_STATIC" alt="AppStore-BB" data-src="images/google_play.png" class="ng-scope" src="images/google_play.png"></a></li>

            <li><a href="#"><img ng-if="!vm.VERSIONED_STATIC" alt="GooglePlay-vedgun" data-src="images/app_store.png" class="ng-scope" src="images/app_store.png"></a></li>
            
          </ul>
         <ul> 
            <li> <h2>Get Social With Us</h2> </li>
          <div id="social">
            <a class="facebookBtn smGlobalBtn" href="#" target="_blank"><img src="images/fb.png"></a> 
            <a class="pinterestBtn smGlobalBtn" href="#" target="_blank"><img src="images/pin.png"></a>
             <a class="twitterBtn smGlobalBtn" href="#" target="_blank"><img src="images/tw.png"></a> 
            <a class="instagramBtn smGlobalBtn" href="#" target="_blank"><img src="images/insta.png"></a>
        </div>  
          </ul>
        
     	  <div class="subscribe">
     	   <h2>Contact Us</h2> 
            <?php 
         $data_foot_con=mysqli_query($con_sup,"select * from e_commerce_details  where sup_company_id='$sup_companyid'");
         $row_foot_con=mysqli_fetch_array($data_foot_con);
         $whatsapp=$row_foot_con['whatsapp'];
         $mobile=$row_foot_con['mobile'];
         $email=$row_foot_con['email'];
          $content=$row_foot_con['content'];



         ?>
     	   WhatsApp us : <span style="display: inline-block; margin-bottom: 1rem;">
     	   	<a href="https://wa.me/917000370003?text=Hi" target="_blank" rel="noopener"><?php echo $whatsapp;?></a>
     	   </span>
     	   <br />
     	   Call Us : <span style="display: inline-block;"><a href="tel:1800 890 1222" target="_blank" rel="noopener"><?php echo $mobile;?></a></span><br />
     	    
     	     <p><?php echo html_entity_decode(strtolower($content));?> <a href="mailto:<?php echo $email;?>"><?php echo strtolower($email); ?></a></p> 
     	  </div> </div> 
          <br>
<div class="col-md-12 hidden-sm hidden-xs payment-opt">
    <div class='row'>
    <div class="col-md-2 col-sm-12">
        <div class="row" style="margin-left: 0px;margin-right: 0px;">
            <h4 class="pay" style="padding-top: 26px;">PAYMENT OPTIONS:</h4>
        </div>
    </div>
    <div class="col-md-10">

        <div class="row">

    
     <div class="col-md-3">
       <span style="font-size: 15px; font-weight:bold; display: inline-flex;vertical-align: super;        padding-top: 26px;">CASH ON DELIVERY</span>

</div>
   <div class="col-md-9">
    

        <span style="font-size: 10px; font-weight:bold; display: inline-flex;vertical-align: super; "><img src='images/payment.png'></span></li>
</div>
    
    </div>
</div>
</div>

</div>
        </footer>

      <!-- Copyright Section --> <small class="copyright"> <div class="copyblock"> <ul><li>© 2021 All rights reserved. <b><a target="_blank" href='https://reliableservices.org/'> Reliable Services.</a></b></li> </ul> </div> </small>
      <script>
  // ************************************************
// Shopping Cart API
// ************************************************

var shoppingCart = (function() {
  // =============================
  // Private methods and propeties
  // =============================
  cart = [];
  
  // Constructor
  function Item(name, price, count) {
    this.name = name;
    this.price = price;
    this.count = count;
  }
  
  // Save cart
  function saveCart() {
    sessionStorage.setItem('shoppingCart', JSON.stringify(cart));
  }
  
  // Load cart
  function loadCart() {
    cart = JSON.parse(sessionStorage.getItem('shoppingCart'));
  }
  if (sessionStorage.getItem("shoppingCart") != null) {
    loadCart();
  }
  
  // =============================
  // Public methods and propeties
  // =============================
  var obj = {};
  
  // Add to cart
  obj.addItemToCart = function(name, price, count) {
   
    for(var item in cart) {
      if(cart[item].name === name) {
        cart[item].count ++;
        saveCart();
        return;
      }
    }
    var item = new Item(name, price, count);
    cart.push(item);
    saveCart();
  }
  // Set count from item
  obj.setCountForItem = function(name, count,price) {
    
    for(var i in cart) {
      if (cart[i].name === name) {

        cart[i].count = count;
        cart[i].price = price;
      //  alert(count);

        break;
      }
    }
  };
  // Remove item from cart
  obj.removeItemFromCart = function(name) {
      for(var item in cart) {
        if(cart[item].name === name) {
          cart[item].count --;
          if(cart[item].count === 0) {
            cart.splice(item, 1);
          }
          break;
        }
    }
    saveCart();
  }

  // Remove all items from cart
  obj.removeItemFromCartAll = function(name) {
    for(var item in cart) {
      if(cart[item].name === name) {
        cart.splice(item, 1);
        break;
      }
    }
    saveCart();
  }

  // Clear cart
  obj.clearCart = function() {
    cart = [];
    saveCart();
  }

  // Count cart 
  obj.totalCount = function() {
    var totalCount = 0;
    for(var item in cart) {
      totalCount += cart[item].count;
    }
    return totalCount;
  }

  // Total cart
  obj.totalCart = function() {
    var totalCart = 0;
    for(var item in cart) {
      totalCart += cart[item].price * cart[item].count;
    }
    return Number(totalCart.toFixed(2));
  }

  // List cart
  obj.listCart = function() {
    var cartCopy = [];
    for(i in cart) {
      item = cart[i];

      itemCopy = {};
      for(p in item) {
        itemCopy[p] = item[p];

      }
      var i_num=item.price;

      itemCopy.total = Number(item.price * item.count).toFixed(2);

      cartCopy.push(itemCopy)
    }
    return cartCopy;
  }

  // cart : Array
  // Item : Object/Class
  // addItemToCart : Function
  // removeItemFromCart : Function
  // removeItemFromCartAll : Function
  // clearCart : Function
  // countCart : Function
  // totalCart : Function
  // listCart : Function 
  // saveCart : Function
  // loadCart : Function
  return obj;
})();


// *****************************************
// Triggers / Events
// ***************************************** 
// Add item
$('.add-to-cart').click(function() {
 window.location.reload();
  // event.preventDefault();
  var name = $(this).data('name');
  var price = Number($(this).data('price'));
  shoppingCart.addItemToCart(name, price, 1);
  displayCart();
  
});

// Clear items
$('.clear-cart').click(function() { 
  window.location.reload();
  shoppingCart.clearCart();
  displayCart();
  window.location.reload();

});


function displayCart() {
  var cartArray = shoppingCart.listCart();

  var output = "";

  for(var i in cartArray) {
    output += "<tr id='tr_cart_"+i+"' style='margin-bottom:20px;'>"
  
      + "<td width='30%'><input type='text' name='item_name[]' class='item_"+i"'  value='"+ cartArray[i].name + "'></td>" 
      + "<td width='10%'><input type='text' class='price_"+i"'  name='item_price[]' value='("+ cartArray[i].price + ")'></td>"
      + "<td width='30%'><div class='input-group'>"
      + "<input type='number' style='width:150px;' name='inputno[]' id='item_"+i+"' class=' item-count form-control' data-name='" + cartArray[i].name + "' onkeyup='calculate(this)' data-price='" + cartArray[i].price + "' value='" + cartArray[i].count + "'>"
      + "</div></td>"
      + "<td><input type='button' style='height: 34px;' class='delete-item btn btn-danger' data-name=" + cartArray[i].name +"   value='X' data-remove='tr_cart_"+i+"'></td>"
    
      + "<td><input type='text' name='total[]' class='total_"+i"' value='"+ cartArray[i].total + "'></td>" 
      +  "</tr><br>";
  }
  
  // alert(output);
  $('.show-cart').html(output);
  $('.total-cart').html(shoppingCart.totalCart());
  $('.total-count').html(shoppingCart.totalCount());
}

// Delete item button

$('.show-cart').on("click", ".delete-item", function(event) {
var remove = $(this).data('remove');
 
   $('#'+remove).remove();
   e.preventDefault();

  // var name = $(this).data('name');
  // alert(name);
 // shoppingCart.removeItemFromCartAll(remove);
  displayCart();
})


// -1
$('.show-cart').on("click", ".minus-item", function(event) {
  var name = $(this).data('name')
  shoppingCart.removeItemFromCart(name);
  displayCart();
})
// +1
$('.show-cart').on("click", ".plus-item", function(event) {
  var name = $(this).data('name')
  shoppingCart.addItemToCart(name);
  displayCart();
})

// Item count input
function calculate(thiss){
  var id=thiss.id;
id=id.split("_");
var r = id[1];
alert(r);
var price = $(this).data('price');
   var name = $(this).data('name');
   var count = Number($(this).val());
  var a=price*count;
}
$('.show-cart').on("keyup", ".item-count", function(event) {
 var price = $(this).data('price');
   var name = $(this).data('name');
   var count = Number($(this).val());
  var a=price*count;
  $('.total')

  shoppingCart.setCountForItem(name,count,price);
      ev.preventDefault();

  displayCart();


});

displayCart();

  

      </script>
