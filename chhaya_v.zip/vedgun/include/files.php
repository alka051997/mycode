
<link rel="apple-touch-icon" sizes="48x48" href="assets/global/new_toch_Vedgun_icon/apple-touch-icon-48x48.png">
<link rel="apple-touch-icon" sizes="72x72" href="assets/global/new_toch_Vedgun_icon/apple-touch-icon-72x72.png"> 
<link rel="apple-touch-icon" sizes="128x128" href="assets/global/new_toch_Vedgun_icon/apple-touch-icon-128x128.png">
<link rel="apple-touch-icon" sizes="256x256" href="assets/global/new_toch_Vedgun_icon/apple-touch-icon-256x256.png"> 
<link rel="apple-touch-icon" href="assets/global/new_toch_Vedgun_icon/apple-touch-icon-48x48.png">

<link rel="preload" href="assets/smartweb/images/Vedgun_logo_beta.svg" as="image">
<link rel="preload" crossorigin="anonymous" href="assets/smartweb/fonts/jio/JioTypeW04-Light.woff2" as="font"> 
<link rel="preload" crossorigin="anonymous" href="assets/smartweb/fonts/jio/JioTypeW04-Bold.woff2" as="font"> 
<link rel="preload" crossorigin="anonymous" href="assets/smartweb/fonts/jio/JioTypeW04-Medium.woff2" as="font"> 
<link rel="preload" crossorigin="anonymous" href="assets/smartweb/fonts/Blank-Theme-Icons/Blank-Theme-Icons.woff2" as="font"> 
<!--    <link rel="shortcut icon" type="image/x-icon" href="assets/smartweb/favicon.svg" /> -->
<link rel="stylesheet" type="text/css" media="all" href="assets/smartweb/css/main.min.css" />
<link rel="stylesheet" type="text/css" media="all" href="assets/version1605113383/smartweb/css/style.min.css" /> 
<link rel="stylesheet" type="text/css" media="all" href="assets/version1605113383/smartweb/css/layout.min.css" />
<link rel="stylesheet" type="text/css" media="all" href="assets/version1605113383/smartweb/css/offers.min.css" />
<link rel="stylesheet" type="text/css" media="all" href="assets/version1605113383/smartweb/css/home.min.css" /> 
<link rel="stylesheet" type="text/css" media="all" href="assets/version1605113383/smartweb/css/searchpage.min.css" />
<link rel="stylesheet" type="text/css" media="all" href="assets/smartweb/css/jquery-ui.min.css" /> 
<link rel="stylesheet" type="text/css" media="all" href="assets/version1605113383/smartweb/css/static.min.css" /> 
<link rel="stylesheet" type="text/css" media="all" href="assets\smartweb\css/custom.css" />
<link rel="icon" type="image/x-icon" href="images/logofev.png">