<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style>
  .top-section header .panel-header .logo {
    max-width: 116px;
    margin:0px;
  }
  .top-section .menu_delivery_section .explorer-menu ul {
    float:right !important;
  }
  .top-section .menu_delivery_section .explorer-menu ul li{
    margin-right:30px;
  }
  .cart_text:hover .minicart_container{
    display: block;
  }
  .top-section header .panel-header .search-bar .block-search #search_form .input-text {
{
    width:92% !important;
  }
  .top-section header .panel-header .login {
    max-width: 140px;
    margin-right: 83px !important;
}
.srch{
    width: 84%;
    height: 40px;
}
.clear-cart{
  position: absolute;
    top: 19px;
    right: -44px;
}
.cart_btn{
    margin-top: 20px;
    width: 50%;
}
.mylogo{
      padding: 0px;
}
.my_log{
      display: block;
    width: 87%;
    height: 104px;
    padding: 10px;
}
.search-bar{
  background-color: none !important;
}
.img_logo{
  background: white;
    margin-top: 4px;
    border-radius: 5px;
}
.loginak{
  text-align: right;
    display: block;

}
.order_now{
background: #ff5722;
    padding: 7px 5px;
    border-radius: 0px;
}

footer .footer-container .subscribe a {
    color: #ffffff !important;
}
.autocomplete-items {
    background-color: #000; 
  position: absolute;
  border: 1px solid #d4d4d4;
  border-bottom: none;
  border-top: none;
  z-index: 99;
  /*position the autocomplete items to be the same width as the container:*/
  top: 100%;
  left: 0;
  right: 0;
}

.autocomplete-items div {
  padding: 10px;
  cursor: pointer;
  background-color: #000; 
  border-bottom: 1px solid #d4d4d4; 
}


/*when navigating through the items using the arrow keys:*/
.autocomplete-active {
 
  color: #000; 
}
.ui-menu .ui-menu-item-wrapper {
  padding: 15px !important;
}
}
.modal-header {
    padding: 15px;
    border-bottom: 1px solid #e5e5e5;
    background-color: #ff5722;
    color: #ffff;
    margin-bottom: 30px;
}

</style>
<div class="top-section">
 <header> 
  <div class="panel-header">
   <div class=" col-md-1 col-sm-1 col-xs-1 col-lg-1" onclick="openNav()"><i style='color:#fff;font-size:30px;' class="fa fa-align-justify"></i></div> 
	<div id="mySidenav">
	 <div class="sidenav"> <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a> <a id="profile-link" href="login.php"> 
	 <div id="customer-profile"> 
	 <div id="customer-profile-left" class="avatar-icon"> 
	    <div id="customer-avatar-icon" class="nav-sprite"></div> 
	 </div> 
	 <div id="customer-profile-right">

    <div id="customer-name">
     <?php
     if($is_login){
        echo $username;
      }
      else{
        echo 'Hello, Sign in';
      } 
      ?> 
   </div> </div> </div> </a> <div id="ham_menu_content"> <div id="hmenu-top-section" style="padding-top: 0px;">
    <ul> 
      <li><a class="redirectLogin" href="myaccount.php">Account</a></li>
      </ul> </div> <div class="hmenu_content" style="height: calc(100% - 155px); overflow: auto; background: #fff;"> <ul> <li><a href="index.php" style="font-family: sans-serif; padding-left: 16px;">Home</a></li> <li><a href="all-category.php" style="font-family: sans-serif; padding-left: 16px;">Shop by Category</a></li> <li class="myjiohide"><a href="mylist.php" style="font-family: sans-serif; padding-left: 16px;">My List</a></li> <li><a href="offers.php" style="font-family: sans-serif; padding-left: 16px;">All Offers</a></li> <li class="hmenu-separator"></li> <li><a class="redirectLogin" href="myaccount.php" style="font-family: sans-serif; padding-left: 16px;">My Account</a></li> <li><a href="faqs.php" style="font-family: sans-serif; padding-left: 16px;">Need Help</a></li> <li><a href="about-us.php" style="font-family: sans-serif; padding-left: 16px;">About us</a></li> <li><a href="faqs.php" style="font-family: sans-serif; padding-left: 16px;">Guide</a></li> <li class="hmenu-separator"></li> </ul> 
   <?php 
         $data_foot_con_left=mysqli_query($con_sup,"select * from e_commerce_details  where sup_company_id='$sup_companyid'");
         $row_foot_con_left=mysqli_fetch_array($data_foot_con_left);
         $whatsapp_left=$row_foot_con_left['whatsapp'];
         $mobile_left=$row_foot_con_left['mobile'];
         $email_left=$row_foot_con_left['email'];
        $content=$row_foot_con_left['content'];



         ?>
	 	<div class="hmenu_contact" style="font-family: sans-serif; padding-top: 0px; padding-bottom: 45px;"> <h1>Contact Us</h1>


	 	<span class="mail_txt">WhatsApp us : <a href="https://wa.me/7508080826" target="_blank" rel="noopener"><?php echo $whatsapp_left; ?></a></span><br /><span class="mail_txt"><span class="mail_txt">Call Us : <a href="tel:1800 890 1222" target="_blank" rel="noopener"><?php echo $mobile_left; ?></a><br /></span></span><p><?php echo html_entity_decode(strtolower($content));?></p></div> </div> </div> </div> </div>
     

     <div class="logo col-lg-2 col-sm-2 col-md-2 col-xs-2" style="padding: 0px;">
       <h1 class='company_name'><a href='index.php' style="    display: block;
    width: 81%;
    height: 104px;
    padding: 10px;"><img style="background: white;
    margin-top: 4px;
    border-radius: 5px;width: 81px;" class='img_logo' src='images/logo.png'></a></h1>
     </div> 
     <div class="search-bar col-lg-5 col-sm-5 col-md-5 col-xs-5 p-0" style="background: none;">
       <div class="block-search">
<?php 
if(isset($_POST['submit1'])){
  $search=$_POST['search'];
  if($search!=""){
    echo "<script> location='all_top_deals.php?search_id=$search'; </script>";
  }
}
?>
  <form  action="#" method="POST" name='form'> 
  <div class='autocomplete'>   
    <input id="myInput"  type="text" name="search" onkeyup="mysearch(this);" class="input-text algolia-search-input aa-input srch" autocomplete="off" spellcheck="false" autocorrect="on" autocapitalize="off" placeholder="Search Here.....">
    <button type="submit" style="padding: 9px 17px;"  class="button-search btn btn-primary" name="submit1"><i class="fa fa-search"></i></button>
  </div>
  </form> 
 </div>  </div> <div class="login col-lg-4 col-sm-4 col-md-4 col-xs-4 p-0 "> 
      <div class="logged row"> 
        <div class='col-md-12'>
         <div class='col-md-6 col-sm-6 col-xs-6 col-lg-6' style="padding: 0px;">
          <a href='https://wa.me/7508080826'style=""><span class='order_now' style="    background: #ff5722;
    padding: 10px 5px;
    border-radius: 0px;
    font-size: 15px;
">Order Now : 7508080826</span></a>
         </div>
        <div class='col-md-3 col-sm-3 col-lg-3 col-xs-3' style="    margin-top: 16px;
">
                 <button type="button" class="btn btn-primary cart_btn" data-toggle="modal" data-target="#cart">
          <span class="glyphicon glyphicon-shopping-cart"> 
            (<span class="total-count"></span>)
        </button>
      </div>
        <div class='col-md-3 col-sm-3 col-lg-3 col-xs-3'>
          <?php 
            if($is_login){
                
              echo "<a href='myaccount.php' class='loginak' style='line-height: 16px;font-weight: bold; margin-top: 17px;'>   <span class='glyphicon glyphicon-user'></span> $username </a>";
            }else{
              echo "<a href='login.php' class='loginak'><span class='order_now' style='background: #ff5722;
    padding: 10px 5px;
    border-radius: 0px;'><span class='glyphicon glyphicon-user'></span> Login</span></a>";
            }
           ?>
      <!-- <a href='' class="pull-right">
    <button class="clear-cart btn btn-danger">
      <span class="glyphicon glyphicon-trash"></span>
    </button> 
  </a> -->
</div>
  </div>
   </div> 
</div>
</header>
       
  <div class="menu_delivery_section">
		<div class="explorer-menu"> 
			<ul>
			  <?php
            $data=mysqli_query($con_sup,"SELECT  ct.priority, item_master.* from item_master JOIN (SELECT category_master.cat_id,category_master.priority FROM category_master) AS ct ON ct.cat_id = item_master.sup_category_id where sup_company_id='$sup_companyid' and delete_data='0' group by sup_category_name order by ct.priority");
                while($row=mysqli_fetch_array($data)){
                  $category_name=$row['sup_category_name'];
                  $category_id=$row['sup_category_id'];
                  $ccat_name=$row['cat_name'];
			  ?>
			    <li class="o-menu">
			     <a href="#"> <?php echo $category_name;?></a>
			      <ul>
			        <?php 
              if($ccat_name!='0' || $ccat_name=''){
               // echo "select * from  item_master where sup_category_id='$category_id' and sup_company_id='$sup_companyid' and publish_status='1' group by cat_name  order by item_id";
               // die;
			         $data_cat=mysqli_query($con_sup,"select * from  item_master where sup_category_id='$category_id' and sup_company_id='$sup_companyid' and publish_status='1' group by cat_name  order by cat_id");
                 while($row_cat=mysqli_fetch_array($data_cat)){
                  $item_cat_name=$row_cat['cat_name'];
                   ?>
			           <li> 
			           	<a href="220.php?sub_cat=<?php echo $item_cat_name;?>"><?php echo $item_cat_name; ?></a> </li>
			        <?php } }?>
	          </ul>
	      </li> 
			  <?php } ?>
      </ul> 
    </div>
  </div>
</div>

<script>
			       	             	   	
 function openNav(){
    document.getElementById('mySidenav').style.width='100%';
 }
</script>

<script>
			       	             	   	
 function closeNav(){

    document.getElementById('mySidenav').style.width='0px';
 }

</script>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>


.autocomplete-items {
  position: absolute;
  border: 1px solid #d4d4d4;
  border-bottom: none;
  border-top: none;
  z-index: 99;
  /*position the autocomplete items to be the same width as the container:*/
  top: 100%;
  left: 0;
  right: 0;
}

.autocomplete-items div {
  padding: 10px;
  cursor: pointer;
  background-color: #fff; 
  border-bottom: 1px solid #d4d4d4; 
}
.ui-menu-item-wrapper:hover{
  border-bottom: 1px solid #eee!important;
  color: #fff !important;
  background-color: #ff5722;

   padding: 10px !important;
}
.ui-menu-item-wrapper{
  border: none !important;
  color: #000 !important; 
  border-bottom: 1px solid #eee!important;
  padding: 10px;
  color: #fff;
}
</style>
</head>     
<body>




</body>
</html>

<script>


function mysearch(thiss){
  var data=thiss.value;
if(data!='')
{
$("#myInput").autocomplete({
minLength: 0,
    search: function () {},
source: function( request, response) {
     $.ajax({
      url:"item_search.php",
      type:"post",
      data:{
        item:data,
      },
      success: function(mydata){
            console.log(mydata);
          //  $('#myInput').val('');
            //  $("#myInput").val('');
              $("#myInput").focus();
             response($.map($.parseJSON(mydata), function(obj){
             return {
               label: obj['item_name'].toUpperCase(),
               // value: obj['l_name'],
               // id: obj['ledger_id'],
               // state: obj['state'],
               // city: obj['city'],
               // cr_mob: obj['mobile'],
               // cr_days: obj['cr_days'],
               // cr_limit: obj['cr_limit']
             }    
           }));
      
       }
   })
},
select: function( event, ui ){
            $('#myInput').val(ui.item.value);
            $('#myInput').val(ui.item.id);
            window.location='all_top_deals.php?search_id='+ui.item.value;
},
   autoFocus: true,
   change: function (event, ui){
       if(!ui.item){
            $('#myInput').val('');
            $('#myInput').val('');
       }
   }
}).focus(function(){            
           // $(this).data("uiAutocomplete").search($(this).val());
    });

  } 
 }

      
        
</script>
