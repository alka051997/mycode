<style type="text/css">
  .pro-img{
    width: 100px;
    height: 100px;
  }

    #social img{
        width: 40px;
    }
    .pay{
        font-size: 15px;
    }
    .modal-title{
      font-size: 23px; 
    font-family: 'sans-serif';
    font-weight: 600;

    }
    footer{
      height:100%;
      font-size: 16px;
    }
    .pay{
      padding-top: 19px;
    font-weight: 700;
    font-size: 15px;
    }
.product-item-name>a{
  color:#000 !important;
  margin-bottom: 20px;
  font-size: 18px;
}
.price_main{
  display: block;
  margin-bottom: 10px;
  margin-top: 10px;
}

</style>
<!-- Modal -->
<div class="modal fade" id="cart" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content" style="padding: 10px;">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">My Cart</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <table class="modal-body show-cart table">
        <div style="color: red;font-weight: 800;margin-top: 0px;font-size: 18px;">Total Price:<i class="fa fa-rupee-sign"></i> <span class="total-cart"></span></div>
        <div style="color: green;font-weight: 700;margin-bottom: 20px;margin-top: 5px;font-size: 16px;" style="display: none">Total Save: <i class="fa fa-rupee-sign"></i> <span class="total-disc"></span></div>
      </table>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary"><a href='cart.php' style="color: #fff">Order now</a></button>
      </div>
    </div>
  </div>
</div> 

<footer> 
  <div class="footer-container"> 
   	<ul>
			<li> <h2>Most Popular Categories</h2> </li>
		  <?php 
            // echo "select * from item_master where sup_company_id='$sup_companyid    ' and delete_data='0' group by sup_category_name order by cat_id";
            // die;
                 $data_foot=mysqli_query($con_sup,"select * from item_master where sup_company_id='$sup_companyid' and delete_data='0' group by sup_category_name order by cat_id");
                 while($row_foot=mysqli_fetch_array($data_foot)){
                  $category_name_foot=$row_foot['sup_category_name'];
                           $cat_category_id=$row_foot['sup_category_id'];
			  ?> 
			<li><a href="all-category.php"><?php echo $category_name_foot;?></a></li>
			<?php } ?> 
 	  </ul> 
 	  <ul> 
			<li> <h2>Customer Services</h2> </li>
			<li><a href="about-us.php">About Us</a></li> 
			<li><a href="faqs.php">FAQ</a></li>
      <li><a href="at_your_service.php">At your service</a></li> 
			<li><a href="terms_and_conditions.php">Terms and conditions</a></li> 
			<li><a href="privacy_policy.php" target="_blank" rel="noopener">Privacy policy</a></li>
			<li><a href="return_policy.php" target="_blank" rel="noopener">Return policy</a></li>
      <li><a href="e_waste.php" target="_blank" rel="noopener">E-waste Policy</a></li>
 	  </ul>
    <ul>
      <li> <h2>Download App</h2> </li> 
      <li><a href="#"><img ng-if="!vm.VERSIONED_STATIC" alt="AppStore-BB" data-src="images/google_play.png" class="ng-scope" src="images/google_play.png"></a></li>      
    </ul>
    <ul> 
      <li> <h2>Get Social With Us</h2> </li>
      <div id="social">
        <a class="facebookBtn smGlobalBtn" href="#" target="_blank"><img src="images/fb.png"></a> 
        <a class="instagramBtn smGlobalBtn" href="#" target="_blank"><img src="images/insta.png"></a>

        <a class="instagramBtn smGlobalBtn" href="https://wa.me/7508080826" target="_blank"><img src="images/whatsapp.png"></a>
      </div>  
    </ul>    
    <div class="subscribe">
     	<h2>Contact Us</h2> 
      <?php 
         $data_foot_con=mysqli_query($con_sup,"select * from e_commerce_details  where sup_company_id='$sup_companyid'");
         $row_foot_con=mysqli_fetch_array($data_foot_con);
         $whatsapp=$row_foot_con['whatsapp'];
         $mobile=$row_foot_con['mobile'];
         $email=$row_foot_con['email'];
         $content=$row_foot_con['content'];
      ?>
     	  WhatsApp us : <span style="display: inline-block; margin-bottom: 1rem;"><a href="https://wa.me/7508080826" target="_blank" rel="noopener"><?php echo $whatsapp;?></a></span>
     	   <br />
     	   Call Us : <span style="display: inline-block;"><a href="#" target="_blank" rel="noopener"><?php echo $mobile;?></a></span><br />
     	<p style="font-weight: 700;
    text-align: justify !important;
    display: block;"><?php echo html_entity_decode(strtolower($content));?> <a href="mailto:<?php echo $email;?>"><?php echo strtolower($email); ?></a></p> 
   	</div>
  </div> 
  <br>
  <div class="col-md-12 hidden-sm hidden-xs payment-opt">
    <div class='row'>
      <div class='container'>
      <div class="col-md-2 col-sm-12">
        <div class="row" style="margin-left: 0px;margin-right: 0px;">
            <h4 class="pay" style="padding-top: 19px;">PAYMENT OPTIONS:</h4>
        </div>
      </div>
      <div class="col-md-10">
        <div class="row">
          <div class="col-md-3">
            <span style="font-size: 15px; font-weight:bold; display: inline-flex;vertical-align: super;        padding-top: 26px;">CASH ON DELIVERY</span>
          </div>
          <div class="col-md-9">
            <span style="font-size: 10px; font-weight:bold; display: inline-flex;vertical-align: super;margin-top: -15px; "><img src='images/payment.png'></span></li>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>  
</footer>
 <small class="copyright"> <div class="copyblock"> <ul><li style="font-size: 14px;color:">© 2021 All rights reserved. <b><a target="_blank" style="color:green" href='https://reliableservices.org/'> Reliable Services.</a></b></li> </ul> </div> </small>
<script>
  // ************************************************
// Shopping Cart API
// ************************************************
var shoppingCart = (function() {
  // =============================
  // Private methods and propeties
  // =============================
  cart = [];
  // Constructor
  function Item(id,name, price, discount, image, count) {
    this.id = id;
    this.name = name;
    this.price = price;
    this.discount = discount;
    this.image = image;
    this.count = count;
  }
  // Save cart
  function saveCart() {
    localStorage.setItem('shoppingCart', JSON.stringify(cart));
  }
  // Load cart
  function loadCart() {
    cart = JSON.parse(localStorage.getItem('shoppingCart'));
  }
  if(localStorage.getItem("shoppingCart") != null) {
    loadCart();
  }
  // =============================
  // Public methods and propeties
  // =============================
  var obj = {};
  // Add to cart
  obj.addItemToCart = function(id,name, price, discount, image, count) {
    for(var item in cart) {
      if(cart[item].id === id) {
        cart[item].count ++;
        saveCart();
        return;
      }
    }
    var item = new Item(id,name, price, discount, image, count);
    cart.push(item);
    saveCart();
  }
  // Set count from item
  obj.setCountForItem = function(id,name, price, discount, image, count) {
    for(var i in cart) {
      if(cart[i].id === id) {
        cart[i].count = count;
        cart[i].discount = discount;
        cart[i].price = price;
        cart[i].image = image;
        break;
      }
    }
  };
  // Remove item from cart
  obj.removeItemFromCart = function(id) {
      for(var item in cart) {
        if(cart[item].id === id) {
          cart[item].count --;
          if(cart[item].count === 0) {
            countCartBtn();
            cart.splice(item, 1);
          }
          break;
        }
    }
    saveCart();
  }
  // Remove all items from cart
  obj.removeItemFromCartAll = function(id) {
    for(var item in cart) {
      if(cart[item].id == id) {
        cart[item].count = 0;
        countCartBtn();
        cart.splice(item, 1);
        break;
      }
    }
    saveCart();
  }
  // Clear cart
  obj.clearCart = function() {
    cart = [];
    saveCart();
  }
  // Count cart 
  obj.totalCount = function() {
    var totalCount = 0;
    for(var item in cart) {
      totalCount += cart[item].count;
    }
    return totalCount;
  }
  // Total cart
  obj.totalCart = function() {
    var totalCart = 0;
    for(var item in cart) {
      totalCart += cart[item].price * cart[item].count;
    }
    return Number(totalCart.toFixed(2));
  }
  // Total Discount
  obj.totalDisc = function() {
    var totalDisc = 0;
    for(var item in cart) {
      totalDisc += cart[item].discount * cart[item].count;
    }
    return Number(totalDisc.toFixed(2));
  }
  // List cart
  obj.listCart = function() {
    var cartCopy = [];
    for(i in cart) {
      item = cart[i];
      itemCopy = {};
      for(p in item) {
        itemCopy[p] = item[p];
      }
      var i_num=item.price;
      itemCopy.total = Number(item.price * item.count).toFixed(2);
      cartCopy.push(itemCopy)
    }
    return cartCopy;
  }
  // cart : Array
  // Item : Object/Class
  // addItemToCart : Function
  // removeItemFromCart : Function
  // removeItemFromCartAll : Function
  // clearCart : Function
  // countCart : Function
  // totalCart : Function
  // totalDisc : Function
  // listCart : Function 
  // saveCart : Function
  // loadCart : Function
  return obj;
})();
// *****************************************
// Triggers / Events
// ***************************************** 
// Add item
$('.add-to-cart').click(function() {
  addToCart(this);
});
function addToCart(thiss){
  // window.location.reload();
  // event.preventDefault();
  var id = $(thiss).data('id');
  var name = $(thiss).data('name');
  var price = Number($(thiss).data('price'));
  var count = Number($(thiss).data('count'));
  var discount = Number($(thiss).data('discount'));
  var image = $(thiss).data('image');
  shoppingCart.addItemToCart(id, name, price, discount, image, 1);
  $(thiss).attr("data-count","1");
  // count = Number($(this).data('count'));
  // this.innerHTML =  `
  //                   <span class="minus btn btn-primary" onclick="updateItem(${id},'-')">-</span>
  //                   <span class="current-qty">${count}</span>
  //                   <span class="plus btn btn-primary" onclick="updateItem(${id},'+')">+</span>
  //                 `;
  displayCart();
}

// Clear items
$('.clear-cart').click(function() {
  // window.location.reload();
  shoppingCart.clearCart();
  displayCart();
});

function displayCart() {
  var output = "";
  var cartArray = shoppingCart.listCart();
  var imglink = "<?php echo $imglink ?>";
  var sup_companyid = "<?php echo $sup_companyid ?>";
  console.log(imglink,sup_companyid)
  cartArray.map((item,i)=>{
    output += "<tr id='tr_cart_"+i+"' style='margin-bottom:20px;'>"
      + "<td width='20%'><img class='pro-img mylistimg' src='"+imglink+"comp"+sup_companyid+"/item_image/"+item.image+"'></td>"
      + "<td width='40%' class='item_name[]'>"+ item.name +"</td>" 
      + "<td width='10%' class='item_price[]'>"+ item.price + " x "+ item.count + "</td>"
      + "<td class='item_total[]'>"+ item.total + "</td>" 
      + "<td><button' style='height: 34px;' class='delete-item btn btn-danger' data-name=" + item.name +" data-id=" + item.id +" data-remove='tr_cart_"+i+"'> X </button></td>"
      +  "</tr><br>";
  })
  document.querySelector('.show-cart').innerHTML = output;
  $('.total-cart').html(shoppingCart.totalCart());
  $('.total-disc').html(shoppingCart.totalDisc());
  $('.total-count').html(shoppingCart.totalCount());
  countCartBtn();
  if(document.querySelector(".ttr")){
    populateCart();
  }
}
// Delete item button
$('.show-cart').on("click", ".delete-item", function(event) {
  var id = $(this).data('id');
  shoppingCart.removeItemFromCartAll(id);
  displayCart();
})
// -1
$('.show-cart').on("click", ".minus-item", function(event) {
  var id = $(this).data('id')
  shoppingCart.removeItemFromCart(id);
  displayCart();
})
// +1
$('.show-cart').on("click", ".plus-item", function(event) {
  var id = $(this).data('id')
  shoppingCart.addItemToCart(id);
  displayCart();
})

// Item count input
$('.show-cart').on("keyup", ".item-count", function(event) {
 var price = $(this).data('price');
   var name = $(this).data('name');
   var count = Number($(this).val());
  var a=price*count;
  shoppingCart.setCountForItem(id,name,price,discount,image,count);
  event.preventDefault();
  displayCart();
});
displayCart();

// select all add-to-cart btn
function countCartBtn(){
  var btns = document.querySelectorAll(".add-to-cart");
  for(let i =0;i<btns.length;i++){
    var id = btns[i].getAttribute('data-id');
    var cartArray = shoppingCart.listCart();
    cartArray.map((item,j)=>{
      if(item.id == id){
        var cnt  = item.count;
        var thiss = btns[i];
        if(cnt>0){
          btns[i].outerHTML = `<div class="add-to-cart" data-id="${item.id}">
                                <span class="minus btn btn-primary" onclick="updateItem(${item.id},'-')">-</span>
                                <span class="current-qty">${item.count}</span>
                                <span class="plus btn btn-primary" onclick="updateItem(${item.id},'+')">+</span>
                              </div>`;
        }else{
          btns[i].outerHTML = `
                    <button data-name="${item.name}" data-price="${item.price}" data-discount="${item.discount}" data-id='${item.id}' data-image='${item.image}' class="add-to-cart btn btn-primary" onclick="addToCart(this)">Add to Basket</button>`;
          btns[i].removeAttribute("disabled")
        }
        // console.log("%c"+item.id,"color:orange;background:green;padding:10px");
      }
    })
  }
}
// window.addEventListener("click",function(e){
//   console.log(e.target)
// })
function updateItem(id,act){
  if(act== '+'){
    shoppingCart.addItemToCart(id);
  }else{
    shoppingCart.removeItemFromCart(id);
  }
  displayCart();
}
function isLogin(){
  var login = "<?php echo $is_login; ?>";
  if(login){
    return true;
  }else{
    return false;
  }
}
function checkSponsor(){
  var ref_sponsor_id = "<?php echo $ref_sponsor_id ?>";
  return ref_sponsor_id;
}
// for cart page
function populateCart(){
  var output = "",tot_mrp=0,tot_disc=0,tot_price=0,addPrice='';
  var cartArray = shoppingCart.listCart();
  cartArray.map((item,i)=>{
    var qty = item.count;
    var total_price = item.price * item.count;
    var total_disc = item.discount * item.count;
    if(total_disc!=0 || total_disc!=''){
      var mrp = item.price + item.discount;
      if(total_disc>0){
        saveDiv = `<span style="color:#00a100"> You Save ${total_disc}</span>`;
      }
      addPrice = `
                <span class="mrpprice">
                  <strike> <span><i class="fa fa-rupee-sign"></i>${mrp}</span></strike>
                  ${saveDiv}
                </span>`;
    }
    var total_mrp = total_price + total_disc;
    tot_mrp += total_mrp;
    tot_price += total_price;
    tot_disc += total_disc;
    var imglink = "<?php echo $imglink ?>";
    var sup_companyid = "<?php echo $sup_companyid ?>";
    // console.log(imglink)
    output += `
            <div class="proditem" style='margin-bottom:20px;'>
            <div class='col-md-12' style='border-bottom:2px solid #fff;padding-bottom:20px;padding-top:20px;'>
              <div class="leftside-icons col-md-2">
                <a class="product-item-photo" href="pro_details.php?pro_name=${item.name}" title="${item.name}">
                <img class="pro-img mylistimg" src="${imglink}comp${sup_companyid}/item_image/${item.image}">
                </a>
              </div>
              <div class="rightside-details col-md-10">
                <div class="row m-0">
                  <div class="product-item-name  pl-0"><a href="pro_details.php?pro_name=${item.name}">${item.name}</a><br>
                    <span class="itemprice price_main"><!----><i class="fa fa-rupee-sign"></i>${item.price}</span>
                    ${addPrice}
                  <b>  <div class="item-prices">Total : <i class="fa fa-rupee-sign"></i>${total_price}</div></b>
                  </div>
                </div>
                <div class="row m-0 mt-3">
                  <div class="mfr-name col-7 pl-0"><!----></div>
                  <div class="addtocartbox col-5 p-0 text-right"><!----><!----><!----><!---->
                    <div class="pro-qty qty-upt-evt d-none"></div><!---->
                    <div class="add plusminus">
                      <div class="inner-qty">
                        <span class="minus btn btn-primary" onclick="updateItem(${item.id},'-')">-</span>
                        <span class="current-qty">${item.count}</span>
                        <span class="plus btn btn-primary" onclick="updateItem(${item.id},'+')">+</span>
                      </div>
                    </div><!----><!----><!---->
                    <div class="remove-drug mt-2 d-none">
                      <a class="action action-delete removeitem" href="javascript:void(0);" title="Remove item">Remove</a>
                    </div>
                  </div>
                </div>
              </div>
              <div class='clearfix'></div>
              </div>
            </div>
             <br>
            `;
  })
  document.querySelector(".ttr").innerHTML = output;
  showBill(tot_mrp,tot_disc,tot_price);
};
function showBill(tot_mrp,tot_disc,tot_price){
  var discount=0,extra_disc=0;
  // calculation for extra discount
  if(isLogin()){
    var ref_sponsor_id = "<?php echo $ref_sponsor_id ?>";
    var toolbox = <?php echo $company_toolbox_json?>;
    if(ref_sponsor_id>0){
      discount = toolbox.tools.ecom_discount;
    }
  }
  if(discount>0){
    discount = parseFloat(discount)
    extra_disc = (tot_price * discount)/100;
  }
  document.querySelector('#cart_sub_total').innerHTML = parseFloat(tot_mrp).toFixed(2);
  document.querySelector('#cart_total_disc1').innerHTML = parseFloat(tot_disc).toFixed(2);
  document.querySelector('#cart_netpay_amt1').innerHTML = parseFloat(tot_price).toFixed(2);
  if(extra_disc>0){
    $(".extra-discount").show();
    document.querySelector('#vedgun_money').innerHTML = parseFloat(extra_disc).toFixed(2);
  }
  if(tot_disc>0){
    $(".save-amount").show();
    document.querySelector('#cart_savings').innerHTML = parseFloat(tot_disc).toFixed(2);
  }
}
</script>