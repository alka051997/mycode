 <script type="application/ld+json">
            {        
                "@context": "https://schema.org",
                "@type": "BreadcrumbList",
                "itemListElement": [
    {
        "@type": "ListItem",
        "position": 0,
        "name": "Home",
        "item": "https://www.Vedgun.com/"
    },
    {
        "@type": "ListItem",
        "position": 1,
        "name": "All Categories",
        "item": "https://www.Vedgun.com/all-category"
    },
    {
        "@type": "ListItem",
        "position": 2,
        "name": "Groceries",
        "item": "https://www.Vedgun.com/c/groceries/2"
    },
    {
        "@type": "ListItem",
        "position": 3,
        "name": "Fruits &amp; Vegetables",
        "item": "https://www.Vedgun.com/c/groceries/fruits-vegetables/219"
    },
    {
        "@type": "ListItem",
        "position": 4,
        "name": "Fresh Fruits",
        "item": "https://www.Vedgun.com/c/groceries/fruits-vegetables/fresh-fruits/220"
    }
]            }
        </script> <input type="hidden" id="mstar_api_baseurl" value="https://www.Vedgun.com/mst/rest/v1/" /> <input type="hidden" id="gift_api_url" value="/api/v1/myorders/giftbulkordersubmit" /> <input type="hidden" id="gift_auth" value="Z2lmdGJ1bGtvcmRlcjpVMnBZVVNaaUpXaEtka2xuWVZsNA==" /> <script type="text/javascript" src="../../../../assets/smartweb/js/lazysizes-umd.min.js" async=""></script> <script type="text/javascript" src="../../../../assets/smartweb/js/jquery-3.4.1.min.js" crossorigin="anonymous"></script> <script type="text/javascript" src="../../../../assets/smartweb/js/jquery-ui.min.js" defer crossorigin="anonymous"></script> <script src="../../../../assets/smartweb/js/bootstrap.min.js" defer crossorigin="anonymous"></script> <script type="text/javascript" src="../../../../assets/smartweb/js/clipboard.min.js" defer crossorigin="anonymous"></script> <script type="text/javascript" src="../../../../assets/smartweb/js/swiper.min.js" defer crossorigin="anonymous"></script> <script src="../../../../assets/smartweb/js/algolia-autocomplete.min.js" defer crossorigin="anonymous"></script> <script src="../../../../../cdn.jsdelivr.net/algoliasearch/3/algoliasearch.min.js" defer crossorigin="anonymous"></script> <script src="../../../../assets/smartweb/js/jquery.cookie.min.js" defer crossorigin="anonymous"></script> <script type="text/javascript" src="../../../../assets/smartweb/js/bootstrap.notify.min.js" defer crossorigin="anonymous"></script> <script type="text/javascript" src="../../../../assets/smartweb/js/jquery.validate.min.js" defer crossorigin="anonymous"></script> <script type="text/javascript" src="../../../../assets/smartweb/js/jquery.md5.min.js" defer crossorigin="anonymous"></script> <script>
    $(document).ready(function () {
        $('.combo-view-more').click(function(){
            var target = $(this).attr("data-target");
            $(target).modal();
        });
    });
</script> <script>
    $(document).ready(function(){
        var userId = localStorage.getItem('userid');
        var authToken = localStorage.getItem('authtoken');
        var displayName = localStorage.getItem('displayname');
        var login_pincode = localStorage.getItem('nms_mgo_pincode');
                if(login_pincode && (login_pincode !="")) {
            $.cookie("nms_mgo_pincode", login_pincode, { expires : 1, path    : '/' });
        }
    });
</script> <script type="text/javascript">
$(document).ready(function () {
    localStorage.removeItem('loginpage');
    window.user_id     = (localStorage.getItem('userid')!=null) ? localStorage.getItem('userid'):"" ;
    window.auth_token  = (localStorage.getItem('authtoken')!=null) ? localStorage.getItem('authtoken'):"";
    window.cust_dname  = (localStorage.getItem('displayname')!=null) ? localStorage.getItem('displayname'):"";
        window.login_session = {
      "async": true,
      "crossDomain": true,
      "url": "https://www.Vedgun.com/mst/rest/v1/entity/customer/get_details",
      "method": "GET",
      "headers": {
        "userid": window.user_id,
        "authtoken": window.auth_token
      }
    };
    if((user_id!="" && user_id != 0) && (cust_dname!="")){
        $('.login #logged_user').text("");
        $('.login #logged_user').append(cust_dname);
        $('.login a:first').hide();
        $('.login #logged_user').show();
        $("#customer-name").text("Hello, "+cust_dname);
        $("#profile-link").attr("href","/customer/account");
        $("#sign_in_out").text('Logout').attr("href","/customer/account/logout");
    } else {
        $('.login #logged_user').hide();
        $('.login a:first').show();
    }
        $('.logged').show();
});
</script> <input type="hidden" name="enable_fbpixel" id="enable_fbpixel" value="0" /> <script type="text/javascript" src="../../../../assets/version1605113383/smartweb/js/main.min.js" defer crossorigin="anonymous"></script> <script type="text/javascript" src="../../../../assets/version1605113383/smartweb/js/cart.min.js" defer crossorigin="anonymous"></script> <script src="../../../../assets/version1605113383/smartweb/js/search_autocomplete.min.js" defer crossorigin="anonymous"></script> <script type="text/javascript" src="../../../../assets/smartweb/js/url.min.js" defer crossorigin="anonymous"></script> <script>
$(document).ready(function(){
    var custEmail = (localStorage.getItem('displayemail')!=undefined) ? localStorage.getItem('displayemail'):"";
    var custNew = (localStorage.getItem('new_customer')!=undefined) ? localStorage.getItem('new_customer'):"";
    var cityName = (localStorage.getItem('nms_mgo_city')!=undefined) ? localStorage.getItem('nms_mgo_city').toUpperCase() : "NA";
            if((user_id!="") && (custEmail!="")){
            dataLayer.push({
              'ecommerce': {
                'currencyCode': 'INR',                       
                'impressions': [
                                 {  
                   'name': "Dates Imported 400 g (Pack)",       
                   'id': "590002744",
                   'price': "159.00",
                   'brand': "",
                   'category': "Groceries",
                                       'list': 'Category List',
                                       'position': "1"
                 },
                                                   {
                   'name': "Mosambi 1 kg",
                   'id': "590000448",
                   'price': "78.00",
                   'brand': "",
                   'category': "Groceries",
                                       'list': 'Category List',
                                       'position': "2"
                 }
                                 ]
              },
              "customer":{"isLoggedIn":true,"id":user_id,"email":$.md5(custEmail),"new_customer":custNew,"city":cityName}
            });
        } else {
            dataLayer.push({
              'ecommerce': {
                'currencyCode': 'INR',                       
                'impressions': [
                                 {  
                   'name': "Dates Imported 400 g (Pack)",       
                   'id': "590002744",
                   'price': "159.00",
                   'brand': "",
                   'category': "Groceries",
                                       'list': 'Category List',
                                       'position': "1"
                 },
                                                   {
                   'name': "Mosambi 1 kg",
                   'id': "590000448",
                   'price': "78.00",
                   'brand': "",
                   'category': "Groceries",
                                       'list': 'Category List',
                                       'position': "2"
                 }
                                 ]
              },
              "customer":{"isLoggedIn":false,"city":cityName}
            });
        }
                    $(".category_name").click(function(){
                var prod_url = $(this).attr('href');
                if((user_id!="") && (custEmail!="")){
                  dataLayer.push({
                    'event': 'productClick',
                    'customer':{"isLoggedIn":true,"id":user_id,"email":$.md5(custEmail),"new_customer":custNew,"city":cityName},
                    'ecommerce': {
                      'click': {
                        'actionField': {'list': 'Category List'},      // Optional list property.
                        'products': [{
                          'name': $(this).attr('title'),                      // Name or ID is required.
                          'id': $(this).closest('.cat-item').find('button.addtocartbtn').attr('data-sku'),
                          'price': $(this).closest('.cat-item').find('#final_price').text(),
                          'brand': $(this).closest('.cat-item').find('span.drug-varients').text().replace("Mfr:",""),
                          'category': 'Fresh Fruits',
                          'ProductId_City': $(this).closest('.cat-item').find('button.addtocartbtn').attr('data-sku')+'_'+cityName,
                          'available_city': cityName
                         }]
                       }
                     },
                     'eventCallback': function() {
                       document.location = prod_url
                     }
                  });
                } else {
                  dataLayer.push({
                    'event': 'productClick',
                    "customer":{"isLoggedIn":false,"city":cityName},
                    'ecommerce': {
                      'click': {
                        'actionField': {'list': 'Category List'},      // Optional list property.
                        'products': [{
                          'name': $(this).attr('title'),                      // Name or ID is required.
                          'id': $(this).closest('.cat-item').find('button.addtocartbtn').attr('data-sku'),
                          'price': $(this).closest('.cat-item').find('#final_price').text(),
                          'brand': $(this).closest('.cat-item').find('span.drug-varients').text().replace("Mfr:",""),
                          'category': 'Fresh Fruits',
                          'ProductId_City': $(this).closest('.cat-item').find('button.addtocartbtn').attr('data-sku')+'_'+cityName,
                          'available_city': cityName
                         }]
                       }
                     },
                     'eventCallback': function() {
                       document.location = prod_url
                     }
                  });
                }
            });
                });
</script>
 <script src="../../../../../cdn.jsdelivr.net/npm/instantsearch.js" crossorigin="anonymous"></script> <script type="text/javascript" src="../../../../assets/version1605113383/smartweb/js/otc_category_page.min.js" defer crossorigin="anonymous"></script> <script type="text/javascript" src="../../../../assets/version1605113383/smartweb/js/filter.min.js" defer crossorigin="anonymous"></script> <script>
function getPageType(){
    var pageType = 'other pages';
    if($("body").hasClass("cms-home")){
        pageType = "Home Page";
    }else if($("body").hasClass("catalog-category-view")){
        pageType = "category page";
    }else if($("body").hasClass("catalog-product-view")){
        pageType = "Product Details Page";
    }
    else if($("body").hasClass("search-result-page")){
        pageType = "Search Page";
    }            
    return pageType;
}   

function trackGoogleEvents(category,action,label){
    if("ga"in window){
        tracker=ga.getAll()[0];
        if(tracker){
            tracker.send("event",category,action,label);
        }
    }
}



$(document).ready(function(){  
    $('#size_chart_btn').on('click',function(){
        var dataURL = $(this).attr('data-href');
        $('#sizechart_dialog .dialog_content').load(dataURL,function(){
            $('#sizechart_dialog').modal({show:true,backdrop:'static'});
        });
    });
    $(".add_to_cart_fixed .cartbag").click(function(){
        trackGoogleEvents("New Click actions","Add to cart button","Product Holder");
    });

    $("#search").focus(function(){
        trackGoogleEvents("New Click actions","Search","");
    });

    $(".mini-cart").click(function(){
        var pageType = 'other pages';
        if($("body").hasClass("cms-home")){
            pageType = "home page";
        }
        else if($("body").hasClass("catalog-category-view")){
            pageType = "category page";
        }
        else if($("body").hasClass("catalog-product-view")){
            pageType = "product page";
        }
        trackGoogleEvents("New Click actions","Cart",pageType);
    });  

    });
</script> <script>
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('../../../../service-worker.js', {
          scope: '/'
        });
    });
}
</script> <script>
  var ALGOLIA_INSIGHTS_SRC = "//cdn.jsdelivr.net/npm/search-insights@1.3.1";

  !function(e,a,t,n,s,i,c){e.AlgoliaAnalyticsObject=s,e[s]=e[s]||function(){
  (e[s].queue=e[s].queue||[]).push(arguments)},i=a.createElement(t),c=a.getElementsByTagName(t)[0],
  i.async=1,i.src=n,c.parentNode.insertBefore(i,c)
  }(window,document,"script",ALGOLIA_INSIGHTS_SRC,"aa");


  // Initialize library
  aa('init', {
    appId: window.algolia_app_id,
    apiKey: window.algolia_api_key
  });
</script> <script>
if($("body").hasClass("gift-page")){
    $(".pages-items a").each(function(i,el){
        var href = $(el).attr("href");
        if (href.indexOf('/gifting/page/2') > -1) {
            $(el).attr("href",href+"?prod_mart_master_vertical_products_popularity");
        }
    });
}
</script> <script>
if($("body").hasClass("prod-jewellery")){
$( "#price_section" ).after( "<div class='clearfix'></div><p class='prepaid_msg'>Only Prepaid Orders Allowed</p>" );
}
</script>