
<?php

 include('dbconnect.php');

 ?>
<!Doctype html>
 <html lang="en-US"> 
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
  <head>
      <title>Buy Grocery Online | Daily Needs Supermarket - Vedgun</title> 
      <meta charset="utf-8"> <meta name="robots" content="INDEX,FOLLOW"> 
      <meta name="description" content="Vedgun - Choose and Buy Online Grocery from a wide range of fruits, vegetables, baby care products, personal care products and much more. Shop Now !" /> 
      <meta name="keywords" content="Online Grocery, Fruits &amp; Vegetables, Staples, Dairy, Packages Foods, Home care, Personal Care" />
      <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"> 
      <meta property="og:site_name" content="Vedgun" /> 
      <meta property="og:type" content="website" /> 
      <meta property="og:title" content="Buy Grocery Online | Daily Needs Supermarket - Vedgun" />
      <meta property="og:description" content="Vedgun - Choose and Buy Online Grocery from a wide range of fruits, vegetables, baby care products, personal care products and much more. Shop Now !" />
      <meta property="og:url" content="index.php" /> 
      <meta property="og:image" content="assets/global/logo-fb.png" /> <!-- Appple Touch Icons --> 
      <meta name="google-play-app" content="app-id=com.jpl.Vedgun">
      <meta name="apple-itunes-app" content="app-id=1522085683">
      <meta name="theme-color" content="#ffffff"/> 
      <?php include('include/files.php');?>
             <style> .multi-srch-hide{ display:none !important; } .ais-InfiniteHits-loadMore{ display:none; } .gift-page #saved_location{ display:none; } </style> <link rel="manifest" href="manifest.json"> <style> .otc-product-page #first_desc h2 {display: none} .otc-product-page #first_desc h2.pname{display: block!important;}.catalog-category-view.level-3 .white-bg.msite-list, .catalog-category-view.level-0 .white-bg.msite-list{display:none !important} .cat-fashion .right-block .empty_listing {position:absolute;z-index:3} .compare_products{ display:none; }#bought_together{display:none !important}.prod-groceries #similar_products{display: none;} .prod-groceries .section-seperate1{display: none;} .prod-fashion .new_product #product_details #left_col .gallery-top,.prod-groceries .new_product #product_details #left_col .gallery-top{height: auto;} .gift-page .all-product .row product-list .col-md-3:last-child .price-box{display:none} .gift-page #free_gift_wrap{display:none !important} .best_deals .add_banner {margin: 0 auto;text-align: center;} .best_deals .add_banner img {width: auto;height: 100%;border-radius: 0;} .best_deals .section-seperate{display: none;} .prod-jewellery .brand_name{display:none !important} .prod-jewellery .prepaid_msg{display:block;font-size:14px;color:#dd0608;font-family: sans-serif;} .aa-dropdown-menu .aa-suggestions .aa-suggestion .product-item-info.search-jewellery a .drug_img { background: url(assets/version1605113383/smartweb/images/search_icons/search_jewellery.png) center no-repeat; background-size: 40px;} .top_cat_name{
              margin-top: 20px;
    display: block;
    text-align: center;
    color: #000;
    font-weight: 900;
              } 
      </style>
    </head> <body class="cms-home Vedgun_home">  <div class="page-wrapper"> 

     <?php include('include/header.php');?>





     <div class="home-banner" data-id="section_30">
      <div class="swiper-container home-slides">
       <div class="swiper-wrapper">
       <?php 
       // echo "SELECT * FROM `e_commerce_scheme` ORDER BY `scheme_id` ASC";
      $data_ban=mysqli_query($con_sup,"SELECT * FROM `e_commerce_scheme` where sup_company_id='$sup_companyid' ORDER BY `scheme_id` ASC");
       

     while($row_ban=mysqli_fetch_array($data_ban)){
       $ban_img=$row_ban['fileupload'];
      $ban_sup_company_id=$row_ban['sup_company_id'];
      $ban_item_name=$row_ban['item_name'];
      if($ban_img!='' && $ban_img!='0' && (!file_exists("$imglink.'comp'.$sup_companyid.'/'.'fileupload'.'/'.$ban_img"))){
        

     ?>
        <div class="swiper-slide" id="rb_slide_3972">
         <a href="pro_details.php?pro_name='<?php echo $ban_item_name;?>'" title="Winter food" rel="nofollow">
          <img class="banner_img" src="<?php echo $imglink.'comp'.$sup_companyid.'/'.'fileupload'.'/'.$ban_img ?>" title="<?php echo $ban_item_name;?>" alt="<?php echo $ban_item_name; ?>"> </a> 
       </div>
       <?php }} ?>
       </div>
      </div> 
      <div class="swiper-pagination customise-pagination"></div> <div class="swiper-button-next swiper-home-btn-next">
      </div>
       <div class="swiper-button-prev swiper-home-btn-prev"></div> 
     </div> <div class="clearfix"></div> 

     <div class="home-content" > 
      <section id="vertical_banner" data-id="section_274">
       <h1 class="title_section"> Shop from Top Categories </h1> 
       <div class="swiper-container shop-vertical-slides">
        <div class="swiper-wrapper">

     <?php 
     
               $data_top_cat=mysqli_query($con_sup,"select * from  item_master where  publish_status='1' GROUP BY sup_category_id order by item_id limit 0,5");
                 while($row_top_cat=mysqli_fetch_array($data_top_cat)){
                  $top_cat_img1=strtolower($row_top_cat['image1']);
                      $top_item_name=$row_top_cat['item_name'];
                      $cat_name=$row_top_cat['cat_name'];
                    $top_com_id=$row_top_cat['sup_company_id'];
                    $top_com_id_name=$row_top_cat['sup_category_name'];
                  if($top_cat_img1!='0' && (!file_exists($imglink.'comp_id'.$sup_companyid.'/item_image'.'/'.$top_cat_img1))){

                  ?>
         <div class="swiper-slide" id="rb_slide_3403"> 
          <a href="220.php?sub_cat=<?php echo $cat_name;?>" title="" rel="nofollow"> 
            <img class="banner_img" src="<?php echo $imglink.'comp'.$sup_companyid.'/'.'item_image'.'/'.$top_cat_img1; ?>" title="" alt="">
            <lable class='top_cat_name'><?php echo $top_com_id_name; ?></lable>
           </a>
         </div>
       <?php }} ?>
      

          </div> 
        </div>
         <div class="swiper-button-next swiper-ver-btn-next"></div> 

         <div class="swiper-button-prev swiper-ver-btn-prev"></div> </section>
           
      
          <section class="best_deals product_section" data-id="section_307"> 
            
   <?php 
          $data_shoping=mysqli_query($con_sup,"select * from e_commerce_details where sup_company_id='$sup_companyid'");
          $row_shopping=mysqli_fetch_array($data_shoping);
          $shopping_img=strtolower($row_shopping['offer_banner']);
          if($shopping_img!='' && $shopping_img!='0' && !(file_exists($imglink.'comp'.$sup_companyid.'/'.'offer_banner'.'/'.$shopping_img))){
          ?>

            <div class="add_banner" data-slideid="3893"> <a href="customer/mylist.php" rel="nofollow"> <img class="lazyload banner_img" src="<?php echo $imglink.'comp'.$sup_companyid.'/'.'offer_banner'.'/'.$shopping_img; ?>" data-src="<?php echo $imglink.'comp'.$sup_companyid.'/'.'offer_banner'.'/'.$shopping_img; ?>" title="Great deals on your Past Orders" alt="Great deals on your Past Orders" /> </a> </div> <div class="section-seperate"></div> 
  <?php } ?>
          </section> 
      

          <div class="clearfix"></div>
            <?php
      
                 $data=mysqli_query($con_sup,"select * from item_master  where sup_company_id='$sup_companyid' and delete_data='0' group by sup_category_name order by cat_id");
                 while($row=mysqli_fetch_array($data)){
                  $category_name=$row['sup_category_name'];
                   $category_id=$row['sup_category_id'];
                     $ccat_name=$row['cat_name'];
                 
        ?>
            <section class="product_section" id="section_35">
          
          <h1> <?php echo $ccat_name;?> </h1>
          <a href="all_top_deals.php" class="clsviewall">View All</a>

           <div class="clearfix"></div>
            <div class="new_product_swiper swiper-container"> 
              <div class="swiper-wrapper"> 
              <?php 
        $data_pro_del=mysqli_query($con_sup,"SELECT ROUND(((item_master.`mrp`-item_master.`offer_price`)*100)/item_master.`mrp`) as per,item_master.* FROM `item_master` where sup_company_id='$sup_companyid'  order by RAND() limit 10");
        while($row_pro_del=mysqli_fetch_array($data_pro_del)){
              $pro_del_id=$row_pro_del['item_id'];
              $pro_del_name=$row_pro_del['item_name'];
              $pro_del_mrp=$row_pro_del['mrp'];
              $per=$row_pro_del['per'];
              $pro_del_save = 0;
              $pro_del_offer_price=$row_pro_del['offer_price'];
              $pro_del_image=strtolower($row_pro_del['image1']);
              $pro_del_comp_id=$row_pro_del['sup_company_id'];
              if($pro_del_offer_price!='' && $pro_del_offer_price!='0'){
                $final_price = $pro_del_offer_price;
                $pro_del_save = $pro_del_mrp - $pro_del_offer_price;
              }else{
                $final_price = $pro_del_mrp;
              }                        
              ?>
                <div class="swiper-slide"> 
               
                  <div class="pro_items">
                    <?php if($per!='' && $per !='0' && $per!='100'){?>
                   <span class="dis_section">
                    <span><?php echo $per;?><span class="per_txt">%</span></span> <br/> off </span>
                  <?php }?>
                    <div class="pro_detail">
                     <a href="pro_details.php?pro_name=<?php echo $pro_del_name;?>" title="<?php echo $pro_del_name;?> 500 g">
                   <?php if($pro_del_image!='' && $pro_del_image!='0' && !(file_exists($imglink.'comp'.$sup_companyid.'/'.'item_image/'.$pro_del_image))){?>
                      <span class="cat-img">
                        <img class="product-image-photo" src="<?php echo $imglink.'comp'.$sup_companyid.'/'.'item_image/'.$pro_del_image;?>" alt="<?php echo $pro_del_name;?>">
                      </span>
                    <?php } ?>

                      <span class="clsgetname"><?php echo $pro_del_name;?> 500 g</span>
                     </a> 
                    </div> 
                    <div class="price_box">
                      <span class="price">M.R.P <?php if($pro_del_offer_price!='' && $pro_del_offer_price!='0'){?>
                        <strike>&#8377; <?php echo $pro_del_mrp;?>.00</strike>
                        <span class="final_price">&#8377; <?php echo $pro_del_offer_price;?>.00</span>
                        <span class="save_price">Save &#8377; <?php echo $pro_del_save;?>.00</span>
                     <?php }else{?>
                      &#8377; <?php echo $pro_del_mrp;?>.00
                     <?php }?>
                      </span>
                    </div>
                    <div class="cart_btn">
                     <div class="cart_btn">
                    <button data-name="<?php echo $pro_del_name;?>" data-price="<?php echo $final_price;?>" data-discount="<?php echo $pro_del_save;?>" data-id='<?php echo $pro_del_id ?>' data-image='<?php echo $pro_del_image ?>' class="add-to-cart btn btn-primary">Add to Basket</button>
                     </div> 
                   </div> 
                 </div>
                  </div>
                  <?php }?>
              
               </div>
              </div>
            <div class="swiper-button-next swiper-new_product_swiper-next">
            </div> 
            <div class="swiper-button-prev swiper-new_product_swiper-prev">
            </div>
             <div class="clearfix"></div>
            </section> 
          <?php } ?>
          <section class="product_section" id="section_35">
          
          <h1> Deals Of The Day </h1>
          <a href="all_top_deals.php" class="clsviewall">View All</a>

           <div class="clearfix"></div>
            <div class="new_product_swiper swiper-container"> 
              <div class="swiper-wrapper"> 
              <?php 
        $data_pro_del=mysqli_query($con_sup,"SELECT ROUND(((item_master.`mrp`-item_master.`offer_price`)*100)/item_master.`mrp`) as per,item_master.* FROM `item_master` where sup_company_id='$sup_companyid'  order by RAND() limit 10");
        while($row_pro_del=mysqli_fetch_array($data_pro_del)){
              $pro_del_id=$row_pro_del['item_id'];
              $pro_del_name=$row_pro_del['item_name'];
              $pro_del_mrp=$row_pro_del['mrp'];
              $per=$row_pro_del['per'];
              $pro_del_save = 0;
              $pro_del_offer_price=$row_pro_del['offer_price'];
              $pro_del_image=strtolower($row_pro_del['image1']);
              $pro_del_comp_id=$row_pro_del['sup_company_id'];
              if($pro_del_offer_price!='' && $pro_del_offer_price!='0'){
                $final_price = $pro_del_offer_price;
                $pro_del_save = $pro_del_mrp - $pro_del_offer_price;
              }else{
                $final_price = $pro_del_mrp;
              }                        
              ?>
                <div class="swiper-slide"> 
               
                  <div class="pro_items">
                    <?php if($per!='' && $per !='0' && $per!='100'){?>
                   <span class="dis_section">
                    <span><?php echo $per;?><span class="per_txt">%</span></span> <br/> off </span>
                  <?php }?>
                    <div class="pro_detail">
                     <a href="pro_details.php?pro_name=<?php echo $pro_del_name;?>" title="<?php echo $pro_del_name;?> 500 g">
                   <?php if($pro_del_image!='' && $pro_del_image!='0' && !(file_exists($imglink.'comp'.$sup_companyid.'/'.'item_image/'.$pro_del_image))){?>
                      <span class="cat-img">
                        <img class="product-image-photo" src="<?php echo $imglink.'comp'.$sup_companyid.'/'.'item_image/'.$pro_del_image;?>" alt="<?php echo $pro_del_name;?>">
                      </span>
                    <?php } ?>

                      <span class="clsgetname"><?php echo $pro_del_name;?> 500 g</span>
                     </a> 
                    </div> 
                    <div class="price_box">
                      <span class="price">M.R.P <?php if($pro_del_offer_price!='' && $pro_del_offer_price!='0'){?>
                        <strike>&#8377; <?php echo $pro_del_mrp;?>.00</strike>
                        <span class="final_price">&#8377; <?php echo $pro_del_offer_price;?>.00</span>
                        <span class="save_price">Save &#8377; <?php echo $pro_del_save;?>.00</span>
                     <?php }else{?>
                      &#8377; <?php echo $pro_del_mrp;?>.00
                     <?php }?>
                      </span>
                    </div>
                    <div class="cart_btn">
                     <div class="cart_btn">
                    <button data-name="<?php echo $pro_del_name;?>" data-price="<?php echo $final_price;?>" data-discount="<?php echo $pro_del_save;?>" data-id='<?php echo $pro_del_id ?>' data-image='<?php echo $pro_del_image ?>' class="add-to-cart btn btn-primary">Add to Basket</button>
                     </div> 
                   </div> 
                 </div>
                  </div>
                  <?php }?>
              
               </div>
              </div>
            <div class="swiper-button-next swiper-new_product_swiper-next">
            </div> 
            <div class="swiper-button-prev swiper-new_product_swiper-prev">
            </div>
             <div class="clearfix"></div>
            </section> 
          <div class="clearfix"></div> <style> .essentials_section#section_121 .cat_list .split_col{ background:#efd6da !important; } </style>
          <h1 class='product_section essentials_section' style="    margin: 0;
    padding: 8px 16px 16px 4px;
    font-size: 20px;
    color: #000;
    font-family: sans-serif;"> Shop by Offer <a href="offers.php" class="clsviewall"> View All </a> </h1>
           <?php 
           $cdate=date('Y-m-d H:i:s');
          $sql_offer = "select * from  offer_entry
 where start_datetime <='$cdate' and end_datetime >='$cdate' and enable='0' and delete_data='0'  order by offer_id asc";
 $data_offer=mysqli_query($con_sup,$sql_offer);
 while($row_offer=mysqli_fetch_array($data_offer)){
          $offer_name=$row_offer['offer_name'];
        $offer_id=$row_offer['offer_id'];
      

       
       ?> 

           <section class="essentials_section" id="section_<?php echo $offer_id; ?>">
 
            <h1> Offers on daily <?php echo $offer_name;?> </h1>
             <div class="clearfix"></div> 
             <div class="cat_list">
              <?php 
              $product_offer=mysqli_query($con_sup,"select * from offer_product_list
 where offer_id='$offer_id'");
              while($row_product_offer=mysqli_fetch_array($product_offer)){
                $discount=$row_product_offer['discount'];
                $item_name=$row_product_offer['item_name'];
                $sup_company_id=$row_product_offer['sup_company_id'];
                $item_image=$row_product_offer['item_image'];
              ?>
             
              <div class="split_col">
               <span class="offer_badge"> Up To <b><?php echo $discount;?>%</b> OFF </span>
                <div class="cat_details">
                 <a href="pro_details.php?pro_name=<?php echo $item_name;?>" title="Dals & Pulses">
              <?php if($item_image!='' && $item_image!='0' && !(file_exists($imglink.'comp'.$sup_company_id.'/'.'offer_images/'.$item_image))){?>
                  <span class="cat_img"> 
                  <img src="<?php echo $imglink.'comp'.$sup_company_id.'/'.'offer_images/'.$item_image;?>" alt="Dals & Pulses"> </span> 
                 <?php } ?>
                  <span class="cat_name"> <?php echo $item_name;?></span> 
                 </a>
                  </div>
                </div>
              <?php } ?>
                
            <div class="clearfix"></div> </div> </section>
            <?php } ?>
            
            
            
             <div class="clearfix"></div> 
             <section class="shop_by_cat" id="section_122"> 
             <h1> Order By Categories <a href="all-category.php" class="clsviewall"> View All </a> </h1>
              <div class="clearfix"></div>
               <div class="shop_cat_swiper swiper-container">
               <div class="swiper-wrapper">
                 <?php 
     
               $data_cat_down=mysqli_query($con_sup,"select * from  item_master where  publish_status='1' GROUP BY sup_category_id order by item_id");
                 while($row_cat_down=mysqli_fetch_array($data_cat_down)){
                  $top_cat_img1_down=strtolower($row_cat_down['image1']);
                      $top_item_name_down=$row_cat_down['item_name'];
                       $top_cat_name_down=$row_cat_down['cat_name'];
                    $top_com_id_down=$row_cat_down['sup_company_id'];
                  if($top_cat_img1_down!='0' && (!file_exists($imglink.'comp_id'.$sup_companyid.'/item_image'.'/'.$top_cat_img1_down))){

                  ?>
               
                <div class="swiper-slide">
                 <a href="220.php?sub_cat=<?php echo $top_cat_name_down;?>" title="<?php echo $top_item_name_down;?>"> 
                 <span class="cat_image"> 
                   <img src="<?php echo $imglink.'comp'.$sup_companyid.'/'.'item_image'.'/'.$top_cat_img1_down; ?>" alt="Personal Care">
                 </span>
                 <span class="cat_list_name"> <?php echo $top_item_name_down; ?> </span> 
                 </a> 
                </div>
                <?php }} ?>
                
             </div> </div> <div class="swiper-button-next swiper-shop_cat_swiper-next"></div> <div class="swiper-button-prev swiper-shop_cat_swiper-prev"></div> <div class="clearfix"></div> </section> <div class="clearfix"></div>   </div> <div class="clearfix"></div> <style> .essentials_section#section_129 .cat_list.split_col{ background:#c5f8c0 !important; } </style>     </div> <div class="clearfix"></div> <style> .essentials_section#section_132 .cat_list .split_col{ background:##fffed2 !important; } </style>  <div class="clearfix"></div> 
             <?php include('include/footer.php');?>
             
              <div class="modal fade" id="rel_pincode_popup" data-easein="slideUpBigIn" tabindex="-1" role="dialog"> <div class="modal-dialog" role="document"> <div class="modal-content"> <div class="modal-header"> <h5 class="modal-title"><span>Happiness</span> Home Delivered...</h5> <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button></div> <div class="clearfix"></div> <div id="delivery_details"> <form id="rel_pincode_form"> <div class="lblock"> <label>Where do you want us to deliver your grocery?</label> <input type="text" class="inp_text" name="rel_pincode" id="rel_pincode" placeholder="Enter your Pincode" autocomplete="off" maxlength="6" /> <div id="rel_pin_msg"></div> <button type="submit" class="shopping_btn">Start Shopping</button> </div> <div class="rblock"> <img src="assets/smartweb/images/delivery_popup_jio.png" alt="Vedgun, Online Groceries Shop"> </div> <div class="clearfix"></div> </form> </div> </div> </div> </div>
</body> 

 <input type="hidden" id="mstar_api_baseurl" value="https://www.Vedgun.com/mst/rest/v1/" />
  <input type="hidden" id="gift_api_url" value="/api/v1/myorders/giftbulkordersubmit" /> 
  <input type="hidden" id="gift_auth" value="Z2lmdGJ1bGtvcmRlcjpVMnBZVVNaaUpXaEtka2xuWVZsNA==" />
 <script type="text/javascript" src="assets/smartweb/js/lazysizes-umd.min.js" async></script> 
 <script type="text/javascript" src="assets/smartweb/js/jquery-3.4.1.min.js" crossorigin="anonymous"></script> 
 <script type="text/javascript" src="assets/smartweb/js/jquery-ui.min.js" defer crossorigin="anonymous"></script> 
 <script src="assets/smartweb/js/bootstrap.min.js" defer crossorigin="anonymous"></script>
  <script type="text/javascript" src="assets/smartweb/js/clipboard.min.js" defer crossorigin="anonymous"></script> 
  <script type="text/javascript" src="assets/smartweb/js/swiper.min.js" defer crossorigin="anonymous"></script>
   <script src="assets/smartweb/js/algolia-autocomplete.min.js" defer crossorigin="anonymous"></script> 
   <!-- <script src="../cdn.jsdelivr.net/algoliasearch/3/algoliasearch.min.js" defer crossorigin="anonymous"></script> -->
    <script src="assets/smartweb/js/jquery.cookie.min.js" defer crossorigin="anonymous"></script>
     <script type="text/javascript" src="assets/smartweb/js/bootstrap.notify.min.js" defer crossorigin="anonymous"></script>
      <script type="text/javascript" src="assets/smartweb/js/jquery.validate.min.js" defer crossorigin="anonymous"></script> 
      <script type="text/javascript" src="assets/smartweb/js/jquery.md5.min.js" defer crossorigin="anonymous"></script> 
      <script>
    $(document).ready(function () {
        $('.combo-view-more').click(function(){
            var target = $(this).attr("data-target");
            $(target).modal();
        });
    });
</script> <script>
    $(document).ready(function(){
        var userId = localStorage.getItem('userid');
        var authToken = localStorage.getItem('authtoken');
        var displayName = localStorage.getItem('displayname');
        var login_pincode = localStorage.getItem('nms_mgo_pincode');
                if(login_pincode && (login_pincode !="")) {
            $.cookie("nms_mgo_pincode", login_pincode, { expires : 1, path    : '/' });
        }
    });
</script> <script type="text/javascript">
$(document).ready(function () {
    localStorage.removeItem('loginpage');
    window.user_id     = (localStorage.getItem('userid')!=null) ? localStorage.getItem('userid'):"" ;
    window.auth_token  = (localStorage.getItem('authtoken')!=null) ? localStorage.getItem('authtoken'):"";
    window.cust_dname  = (localStorage.getItem('displayname')!=null) ? localStorage.getItem('displayname'):"";
        window.login_session = {
      "async": true,
      "crossDomain": true,
      "url": "https://www.Vedgun.com/mst/rest/v1/entity/customer/get_details",
      "method": "GET",
      "headers": {
        "userid": window.user_id,
        "authtoken": window.auth_token
      }
    };
    if((user_id!="" && user_id != 0) && (cust_dname!="")){
        $('.login #logged_user').text("");
        $('.login #logged_user').append(cust_dname);
        $('.login a:first').hide();
        $('.login #logged_user').show();
        $("#customer-name").text("Hello, "+cust_dname);
        $("#profile-link").attr("href","/customer/account");
        $("#sign_in_out").text('Logout').attr("href","/customer/account/logout");
    } else {
        $('.login #logged_user').hide();
        $('.login a:first').show();
    }
        $('.logged').show();
});
</script> <input type="hidden" name="enable_fbpixel" id="enable_fbpixel" value="0" /> <script type="text/javascript" src="assets/version1605113383/smartweb/js/main.min.js" defer crossorigin="anonymous"></script> <script type="text/javascript" src="assets/version1605113383/smartweb/js/cart.min.js" defer crossorigin="anonymous"></script> <script src="assets/version1605113383/smartweb/js/search_autocomplete.min.js" defer crossorigin="anonymous"></script> <script type="text/javascript" src="assets/smartweb/js/url.min.js" defer crossorigin="anonymous"></script> <script>
$(document).ready(function(){
    var custEmail = (localStorage.getItem('displayemail')!=undefined) ? localStorage.getItem('displayemail'):"";
    var custNew = (localStorage.getItem('new_customer')!=undefined) ? localStorage.getItem('new_customer'):"";
    var cityName = (localStorage.getItem('nms_mgo_city')!=undefined) ? localStorage.getItem('nms_mgo_city').toUpperCase() : "NA";
                if((user_id!="") && (custEmail!="")){
            dataLayer.push({"ecommerce":{"currencyCode":"INR"},"customer":{"isLoggedIn":true,"id":user_id,"email":$.md5(custEmail),"new_customer":custNew,"city":cityName},"pageType":"homepage"});
        } else {
        dataLayer.push({"ecommerce":{"currencyCode":"INR"},"customer":{"isLoggedIn":false,"city":cityName},"pageType":"homepage"});
        }
         });
</script> <script>
        $(document).ready(function(){
            if((localStorage.getItem('paynowID')) && (localStorage.getItem('paynowID')!=='')){
                localStorage.removeItem('paynowID');
                localStorage.removeItem('m2_errlist');      
            }
        });    
    </script> <script>
function getPageType(){
    var pageType = 'other pages';
    if($("body").hasClass("cms-home")){
        pageType = "Home Page";
    }else if($("body").hasClass("catalog-category-view")){
        pageType = "category page";
    }else if($("body").hasClass("catalog-product-view")){
        pageType = "Product Details Page";
    }
    else if($("body").hasClass("search-result-page")){
        pageType = "Search Page";
    }            
    return pageType;
}   

function trackGoogleEvents(category,action,label){
    if("ga"in window){
        tracker=ga.getAll()[0];
        if(tracker){
            tracker.send("event",category,action,label);
        }
    }
}



$(document).ready(function(){  
    $('#size_chart_btn').on('click',function(){
        var dataURL = $(this).attr('data-href');
        $('#sizechart_dialog .dialog_content').load(dataURL,function(){
            $('#sizechart_dialog').modal({show:true,backdrop:'static'});
        });
    });
    $(".add_to_cart_fixed .cartbag").click(function(){
        trackGoogleEvents("New Click actions","Add to cart button","Product Holder");
    });

    $("#search").focus(function(){
        trackGoogleEvents("New Click actions","Search","");
    });

    $(".mini-cart").click(function(){
        var pageType = 'other pages';
        if($("body").hasClass("cms-home")){
            pageType = "home page";
        }
        else if($("body").hasClass("catalog-category-view")){
            pageType = "category page";
        }
        else if($("body").hasClass("catalog-product-view")){
            pageType = "product page";
        }
        trackGoogleEvents("New Click actions","Cart",pageType);
    });  

             
    $(".home-slides .swiper-slide").click(function(){
        trackGoogleEvents("Home Banner","Primary Banners","Home Page");                
    });

    $(".home-category-swipe .swiper-slide").click(function(){
        var catname = $(this).find(".clsgetname").text();
        trackGoogleEvents("Home Explore Categories",catname,"Home Page");                
    }); 

    $(".home-best-seller .swiper-slide").click(function(){
        var prodname = $(this).find(".clsgetname").text();
        trackGoogleEvents("Home Best Sellers",prodname,"Home Page");                
    });
    });
</script> 
 <script>
  var ALGOLIA_INSIGHTS_SRC = "//cdn.jsdelivr.net/npm/search-insights@1.3.1";

  !function(e,a,t,n,s,i,c){e.AlgoliaAnalyticsObject=s,e[s]=e[s]||function(){
  (e[s].queue=e[s].queue||[]).push(arguments)},i=a.createElement(t),c=a.getElementsByTagName(t)[0],
  i.async=1,i.src=n,c.parentNode.insertBefore(i,c)
  }(window,document,"script",ALGOLIA_INSIGHTS_SRC,"aa");


  // Initialize library
  aa('init', {
    appId: window.algolia_app_id,
    apiKey: window.algolia_api_key
  });
</script> <script>
if($("body").hasClass("gift-page")){
    $(".pages-items a").each(function(i,el){
        var href = $(el).attr("href");
        if (href.indexOf('/gifting/page/2') > -1) {
            $(el).attr("href",href+"?prod_mart_master_vertical_products_popularity");
        }
    });
}
</script> <script>
if($("body").hasClass("prod-jewellery")){
$( "#price_section" ).after( "<div class='clearfix'></div><p class='prepaid_msg'>Only Prepaid Orders Allowed</p>" );
}
</script> 
<!-- Mirrored from www.Vedgun.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 30 Nov 2020 05:08:16 GMT -->
</html>
