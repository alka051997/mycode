<?php
include("dbconnect.php");
$create_date=date('Y-m-d');
if(isset($_POST['signup'])){
	$mobile = $_POST['mobile'];
	//echo "SELECT * from ac_party_led where (mobile='$mobile') ";
    $rs=mysqli_query($con,"SELECT * from ac_party_led where (mobile='$mobile') ");
    //echo "--".mysqli_num_rows($rs);die;
    if(mysqli_num_rows($rs)==1){
		 //header('location:index.php?send_OTP=success');
        echo "exists";
    }else {
		$pin = rand(100000,999999);
		$_SESSION['mobile']=$mobile;
		$_SESSION['onlineotp']=$pin;
		//echo  $_SESSION['onlineotp'];
		$message=$pin." is your verification code,for Vedgun.For security reasons,DO NOT share this OTP anyone.";
		//mysqli_query($con,"insert into smsactivity(mobile,create_date) values('$mobilenumber','$create_date')");
		$sent = $cmn->sendSmsdynamic($con,$message, $mobile,"","",1);
		echo "send";
    }
}
if(isset($_POST['login'])){
	$mobile = $_POST['mobile'];
    $rs=mysqli_query($con,"SELECT * from ac_party_led where (mobile='$mobile') ");
    if(mysqli_num_rows($rs)==1){
		$pin = rand(100000,999999);
		$_SESSION['mobile']=$mobile;
		$_SESSION['onlineotp']=$pin;
		//echo  $_SESSION['onlineotp'];
		$message=$pin." is your verification code,for Vedgun.For security reasons,DO NOT share this OTP anyone.";
		//mysqli_query($con,"insert into smsactivity(mobile,create_date) values('$mobilenumber','$create_date')");
		$sent = $cmn->sendSmsdynamic($con,$message, $mobile,"","",1);
		 //header('location:index.php?send_OTP=success');
		echo "send";
    }else {
        echo "not";
    }
}
if(isset($_POST['validateOtp'])){
	if ($_POST['otp'] == $_SESSION['onlineotp']) {
		echo "verify";
	} else {
		echo "false";
	}
}
if(isset($_POST['validateSponsor'])){
	$code = $_POST['code'];
    $rs=mysqli_query($con,"SELECT * from ac_party_led where (sponsor_code='$code') ");
    if(mysqli_num_rows($rs)==1){
		echo "valid";
    }else {
        echo "invalid";
    }
}
?>