<?php
session_start();
include("dbinfo_sup.php");
include("dbinfo.php");
//print_r($_SESSION);
$membertype = $_SESSION['membertype'];
$company_id=$_SESSION['memberid'];
$userid = $_SESSION['userid'];
$username = $_SESSION['username'];
$ref_sponsor_id = $_SESSION['ref_sponsor_id'];
$is_login = $_SESSION['login'];
$datatable_crit=" ";
if($company_id > 0){
	$getLogin = mysqli_query($con,"SELECT * from company_master where co_id='$company_id'");
	$rowLogin = mysqli_fetch_array($getLogin);
	$company_name=$rowLogin['company_name'];
	$company_address=$rowLogin['address'];
	$company_state = $rowLogin['state'];
	$company_city = $rowLogin['city'];
	$logo=$rowLogin['logo'];
	$company_product_type = $rowLogin['product_type'];

	$datatable_crit=" and company_id='$company_id'";
}
$session = $_SESSION['session'];
$sessArr = explode("-",$session);
$sessYear = substr($sessArr[0],2,2).'-'.substr($sessArr[1],2,2);
$createdate = date('Y-m-d H:i:s');

/// settings
$pdf_sale_invoice = $cmn->getvalfield($con, "sup_company","pdf_sale_invoice","sc_id <> 0");
$sup_co_id = $cmn->getvalfield($con, "sup_company","companyid","sc_id <> 0");
$companycode = "comp$sup_companyid";

//for toolbox setting
$sttTools = mysqli_query($con,"select * from tool_box where company_id = '$company_id'");
$toolCnt = mysqli_num_rows($sttTools);
$company_toolbox="";
if($toolCnt >0){
	$company_toolbox = mysqli_fetch_assoc($sttTools);
	//to get column_name write $company_toolbox['column_name']
	$showToolsArr = array("tools"=>$company_toolbox);
	$company_toolbox_json = json_encode($showToolsArr,false);
	//pass $company_toolbox_json as input value to use it in javascript
}
// delivery address
$userRow = mysqli_fetch_array(mysqli_query($con,"SELECT * FROM ac_party_led where ledger_id = '".$userid."'  "));
$user_state = $userRow['state'];
$user_district = $userRow['district'];
$user_city = $userRow['city'];
$user_pincode = $userRow['pincode'];
$user_address = $userRow['address'];
///
?>