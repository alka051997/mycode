<!doctype html> <html lang="en-US"> 
<!-- Mirrored from www.Vedgun.com/help-support by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 30 Nov 2020 05:36:21 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head> <title>Need Help</title> <meta charset="utf-8"> <meta name="robots" content="INDEX,FOLLOW"> <meta name="description" content="Buy Grocery Online in Mumbai, Pune, Bangalore at Vedgun online grocery store. Best price on fresh fruits &amp; vegetables, dairy &amp; bakery, packaged food." /> <meta name="keywords" content="" /> <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"> <meta property="og:site_name" content="Vedgun" /> <meta property="og:type" content="website" /> <meta property="og:title" content="Need Help" /> <meta property="og:description" content="Buy Grocery Online in Mumbai, Pune, Bangalore at Reliance Smart online grocery store. Best price on fresh fruits & vegetables, dairy & bakery, packaged food." /> <meta property="og:url" content="help-support.php" /> <meta property="og:image" content="assets/global/logo-fb.png" /> <!-- Appple Touch Icons --> <link rel="apple-touch-icon" sizes="48x48" href="assets/global/new_toch_Vedgun_icon/apple-touch-icon-48x48.png"> <link rel="apple-touch-icon" sizes="72x72" href="assets/global/new_toch_Vedgun_icon/apple-touch-icon-72x72.png"> <link rel="apple-touch-icon" sizes="128x128" href="assets/global/new_toch_Vedgun_icon/apple-touch-icon-128x128.png"> <link rel="apple-touch-icon" sizes="256x256" href="assets/global/new_toch_Vedgun_icon/apple-touch-icon-256x256.png"> <link rel="apple-touch-icon" href="assets/global/new_toch_Vedgun_icon/apple-touch-icon-48x48.png"> <meta name="google-play-app" content="app-id=com.jpl.Vedgun"> <meta name="apple-itunes-app" content="app-id=1522085683"> <meta name="theme-color" content="#ffffff"/> <link rel="preload" href="assets/smartweb/images/Vedgun_logo_beta.svg" as="image"> <link rel="preload" crossorigin="anonymous" href="assets/smartweb/fonts/jio/JioTypeW04-Light.woff2" as="font"> <link rel="preload" crossorigin="anonymous" href="assets/smartweb/fonts/jio/JioTypeW04-Bold.woff2" as="font"> <link rel="preload" crossorigin="anonymous" href="assets/smartweb/fonts/jio/JioTypeW04-Medium.woff2" as="font"> <link rel="preload" crossorigin="anonymous" href="assets/smartweb/fonts/Blank-Theme-Icons/Blank-Theme-Icons.woff2" as="font"> <link rel="shortcut icon" type="image/x-icon" href="assets/smartweb/favicon.svg" /> <link rel="stylesheet" type="text/css" media="all" href="assets/smartweb/css/main.min.css" /> <link rel="stylesheet" type="text/css" media="all" href="assets/version1605113383/smartweb/css/style.min.css" /> <link rel="stylesheet" type="text/css" media="all" href="assets/version1605113383/smartweb/css/layout.min.css" /> <link rel="stylesheet" type="text/css" media="all" href="assets/version1605113383/smartweb/css/offers.min.css" /> <link rel="stylesheet" type="text/css" media="all" href="assets/version1605113383/smartweb/css/home.min.css" /> <link rel="stylesheet" type="text/css" media="all" href="assets/version1605113383/smartweb/css/searchpage.min.css" /> <link rel="stylesheet" type="text/css" media="all" href="assets/smartweb/css/jquery-ui.min.css" /> <link rel="stylesheet" type="text/css" media="all" href="assets/version1605113383/smartweb/css/static.min.css" /> <link rel="stylesheet" href="assets/version1605113383/smartweb/css/need-help.min.css"> <link rel="stylesheet" href="assets/version1605113383/smartweb/css/jquery.multiselect.css"> <style> .multi-srch-hide{ display:none !important; } .ais-InfiniteHits-loadMore{ display:none; } .gift-page #saved_location{ display:none; } </style> <style> #feedback_help,.hidden_options,.feedback_yes{ display:none; } .need-support .col-12 .help-menu h2:before{display:none; } .order_details,.hidden_options,.cate_hidden,.feedback_yes,.ms-options ul li,#need_help,#need_help_form,#products,.ms-options-wrap{ display: none; } .raised_tickets{pointer-events: none;} </style> <link rel="manifest" href="manifest.json"> <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
		new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
		j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
		'../www.googletagmanager.com/gtm5445.php?id='+i+dl;f.parentNode.insertBefore(j,f);
		})(window,document,'script','dataLayer','GTM-NQLHTD8');</script> <style> .otc-product-page #first_desc h2 {display: none} .otc-product-page #first_desc h2.pname{display: block!important;}.catalog-category-view.level-3 .white-bg.msite-list, .catalog-category-view.level-0 .white-bg.msite-list{display:none !important} .cat-fashion .right-block .empty_listing {position:absolute;z-index:3} .compare_products{ display:none; }#bought_together{display:none !important}.prod-groceries #similar_products{display: none;} .prod-groceries .section-seperate1{display: none;} .prod-fashion .new_product #product_details #left_col .gallery-top,.prod-groceries .new_product #product_details #left_col .gallery-top{height: auto;} .gift-page .all-product .row product-list .col-md-3:last-child .price-box{display:none} .gift-page #free_gift_wrap{display:none !important} .best_deals .add_banner {margin: 0 auto;text-align: center;} .best_deals .add_banner img {width: auto;height: 100%;border-radius: 0;} .best_deals .section-seperate{display: none;} .prod-jewellery .brand_name{display:none !important} .prod-jewellery .prepaid_msg{display:block;font-size:14px;color:#dd0608;font-family: sans-serif;} .aa-dropdown-menu .aa-suggestions .aa-suggestion .product-item-info.search-jewellery a .drug_img { background: url(assets/version1605113383/smartweb/images/search_icons/search_jewellery.png) center no-repeat; background-size: 40px; } </style> <script>
        window.default_pin = '400020';
        window.algolia_filter = false;
        window.algolia_app_id = "3YP0HP3WSH";
        window.algolia_api_key = "aace3f18430a49e185d2c1111602e4b1";
        //window.algolia_index_name = "";
        window.algolia_suffix = 'prod_mart';
                window.product_image_path = "index.php";
                window.location_api = "AIzaSyBfquJmLRraJi0sNjV14BQWqGlMAEzqAIw";
        window.default_vertical_city_code = JSON.parse('{"ELECTRONICS": "null","FASHION": null,"GROCERIES": "6221", "JEWELLERY": "PANINDIAJEWEL"}');
        window.inventory_store_code = JSON.parse('{"GROCERIES":["6210"],"FASHION":null,"ELECTRONICS":null}');
    </script> </head> <body class="need-support"> <noscript><iframe src="https://www.googletagmanager.com/ns.php?id=GTM-NQLHTD8" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript> <script>
            var userID      = localStorage.getItem('userid');
            if((userID == null) || (userID == '0')){
                localStorage.setItem('redirectUrl','/help-support');
                window.location.href = window.location.origin+"/customer/account/login";
            }
        </script> <div class="page-wrapper"> <div class="top-section"> <header> <div class="panel-header"> <div class="menu_section" onclick="openNav()"></div> <div id="mySidenav" > <div class="sidenav"> <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a> <a id="profile-link" href="https://www.Vedgun.com/customer/account/login"> <div id="customer-profile"> <div id="customer-profile-left" class="avatar-icon"> <div id="customer-avatar-icon" class="nav-sprite"></div> </div> <div id="customer-profile-right"> <div id="customer-name"> Hello, Sign in </div> </div> </div> </a> <div id="ham_menu_content"> <div id="hmenu-top-section" style="padding-top: 0px;"> <ul> <li><a class="redirectLogin" href="customer/account.php">Account</a></li> <li><a class="redirectLogin" href="customer/orderhistory.php">Orders</a></li> </ul> </div> <div class="hmenu_content" style="height: calc(100% - 155px); overflow: auto; background: #fff;"> <ul> <li><a href="index.php" style="font-family: sans-serif; padding-left: 16px;">Home</a></li> <li><a href="all-category.php" style="font-family: sans-serif; padding-left: 16px;">Shop by Category</a></li> <li class="myjiohide"><a href="customer/mylist.php" style="font-family: sans-serif; padding-left: 16px;">My List</a></li> <li class="myjiohide"><a href="https://www.Vedgun.com/customer/account/mysubscription" style="font-family: sans-serif; padding-left: 16px;">My Subscription</a></li> <li class="myjiohide"><a href="https://www.Vedgun.com/customer/account/Vedgunwallets" style="font-family: sans-serif; padding-left: 16px;">Vedgun Wallet</a></li> <li><a href="offers.php" style="font-family: sans-serif; padding-left: 16px;">All Offers</a></li> <li class="hmenu-separator"></li> <li><a class="redirectLogin" href="customer/account.php" style="font-family: sans-serif; padding-left: 16px;">My Account</a></li> <li><a href="faqs.php" style="font-family: sans-serif; padding-left: 16px;">Need Help</a></li> <li><a href="about-us.php" style="font-family: sans-serif; padding-left: 16px;">About us</a></li> <li><a href="how-to-buy-on-Vedgun.php" style="font-family: sans-serif; padding-left: 16px;">Guide</a></li> <li class="hmenu-separator"></li> </ul> <div class="hmenu_contact" style="font-family: sans-serif; padding-top: 0px; padding-bottom: 45px;"> <h1>Contact Us</h1> <span class="mail_txt">WhatsApp us : <a href="https://wa.me/917000370003?text=Hi" target="_blank" rel="noopener">70003 70003</a></span><br /><span class="mail_txt"><span class="mail_txt">Call Us : <a href="tel:1800 890 1222" target="_blank" rel="noopener">1800 890 1222</a><br /></span></span> <p>8:00 AM to 8:00 PM, 365 days</p> <p style="margin: 0px; padding: 0px 0px 8px; font-size: 13px;">Please note that you are accessing the BETA Version of <a href="index.php" style="color: #073a09;">www.Vedgun.com</a></p> <p style="margin: 0px; padding: 0px 0px 8px; font-size: 13px;">Should you encounter any bugs, glitches, lack of functionality, delayed deliveries, billing errors or other problems on the beta website, please email us on <a href="mailto:cs@Vedgun.com" style="color: #073a09;">cs@Vedgun.com</a></p> <h1>Download App</h1> <a href="https://play.google.com/store/apps/details?id=com.jpl.Vedgun" target="_blank" rel="noopener"><img src="images/cms/wysiwyg/app-icons/play_store.png" alt="Download Vedgun App for Android from Play Store" /></a> <a href="https://apps.apple.com/in/app/Vedgun/id1522085683" target="_blank" rel="noopener"><img src="images/cms/wysiwyg/app-icons/ios_store.png" alt="Download Vedgun App for iOs from App Store" /></a></div> </div> </div> </div> </div> <div class="logo"> <a href="index.php"> <img src="assets/version1605113383/smartweb/images/Vedgun_logo_beta.svg" alt="Vedgun, Online Groceries Shop"> </a> </div> <div class="search-bar col p-0"> <div class="block-search"> <form id="search_form" action="https://www.Vedgun.com/catalogsearch/result" method="GET"> <div class="search-section"> <input tabindex="0" id="search" type="text" name="q" class="input-text algolia-search-input aa-input" autocomplete="off" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="Search essentials, groceries, and more …"> </div> </form> <span class="search_list"> <span id="rel_search_list_btn">Search<br>with List</span> </span> <span class="qr-code d-none"> <label class="qrcode-text-btn"><input type=file accept="image/*" capture=environment onchange="openQRCamera(this);" tabindex=-1></label> </span> </div> <div class="search_list_block" id="rel_search_list_box" style="display:none;"> <h5>Shop faster - type or paste your shopping list below</h5> <button type="button" class="close"> <span>&times;</span> </button> <div class=clearfix></div> <form id="rel_search_form"> <textarea name="searchTerm" id="rel_search_val" class="search_product" autofocus="true" placeholder="e.g. Milk, Bread, Fruit"></textarea> <div class=clearfix></div> <button type="reset" title="Reset" class="clear_btn"> Clear </button> <button type="submit" title="Submit" class="search_btn"> Search Now </button> <div class=clearfix></div> </form> </div> </div> <div class="login col-lg-2 p-0 "> <div class="logged" style="display: none;"> <a href="https://www.Vedgun.com/customer/account/login"> Sign in / Sign up </a> <a id="logged_user" href="https://www.Vedgun.com/customer/account/"></a> </div> </div> <div data-block="minicart" class="mini-cart col-lg-1 p-0" id="minicart_btn"> <a class="cart_text" href="checkout/cart.php"> <div class="text"> <span class="counter-number" style="display:none;"></span> </div> Cart </a> <div class="minicart_container" id="mini_cart"> <div class="mc_triangle"></div> <div class="mc_content"></div> </div> </div> </div> </header> <div class="menu_delivery_section"> <div class="explorer-menu"> <ul> <li class="delivery_section" id="pincode_section"> <div class="delivery_content"> Deliver to <span id="delivery_details"></span> </div> <div class="jio_delivery_popup" style="display:none;"> <div class="jio_traingle"></div> <div class="jio_pinoce_content"> <div id="saved_location"> <h1>Where do you want the delivery?</h1> <span id="delivery_txt" class="pincode_availablity">Get access to your Addresses, Orders, and Wishlist</span> <div class="clearfix"></div> <button type="button" style="display:none;" class="signin_btn">Sign in to see Your Addresses</button> <div class="saved_location_swiper swiper-container" style="display:none;"> <div class="swiper-wrapper" id="saved_addresses"> Loading.. </div> </div> </div> <div class="clearfix"></div> <div id="delivery_details"> <h1>Or Enter Pincode</h1> <span class="pincode_availablity">Select pincode to see product availability.</span> <div class="clearfix"></div> <div class="pCode_form"> <form id="rel_pincode_form"> <div class="pin_detail"> <button type="button" class="get-location" id="location_btn">L</button> <input type="tel" class="inp_text" name="rel_pincode" id="rel_pincode" placeholder="Enter your Pincode" autocomplete="off" maxlength="6" /> <button type="submit" class="apply_btn">APPLY</button> <div class="clearfix"></div> </div> <div class="clearfix"></div> <div id="rel_pin_msg"></div> <div class="clearfix"></div> </form> </div> <div class="clearfix"></div> <div class="detect_location">DETECT MY LOCATION <span id="detect_location_msg"></span></div> <div class="clearfix"></div> </div> <div class="clearfix"></div> </div> </div> </li> <li class="o-menu"> <a href="c/groceries/fruits-vegetables/219.php"> Fruits & Vegetables </a> <ul> <li> <a href="c/groceries/fruits-vegetables/fresh-fruits/220.php"> Fresh Fruits </a> </li> <li> <a href="c/groceries/fruits-vegetables/fresh-vegetables/229.php"> Fresh Vegetables </a> </li> <li> <a href="c/groceries/fruits-vegetables/herbs-seasonings/233.php"> Herbs & Seasonings </a> </li> <li> <a href="c/groceries/fruits-vegetables/exotic-fruits-vegetables/243.php"> Exotic Fruits & Vegetables </a> </li> </ul> </li> <li class="o-menu"> <a href="c/groceries/dairy-bakery/61.php"> Dairy & Bakery </a> <ul> <li> <a href="c/groceries/dairy-bakery/dairy/62.php"> Dairy </a> </li> <li> <a href="c/groceries/dairy-bakery/toast-khari/102.php"> Toast & Khari </a> </li> <li> <a href="c/groceries/dairy-bakery/cakes-muffins/125.php"> Cakes & Muffins </a> </li> <li> <a href="c/groceries/dairy-bakery/breads-and-buns/267.php"> Breads and Buns </a> </li> <li> <a href="c/groceries/dairy-bakery/baked-cookies/273.php"> Baked Cookies </a> </li> <li> <a href="c/groceries/dairy-bakery/bakery-snacks/281.php"> Bakery Snacks </a> </li> <li> <a href="c/groceries/dairy-bakery/batter-chutney/407.php"> batter & chutney </a> </li> <li> <a href="c/groceries/dairy-bakery/cheese/1569.php"> Cheese </a> </li> <li> <a href="c/groceries/dairy-bakery/ghee/1571.php"> Ghee </a> </li> <li> <a href="c/groceries/dairy-bakery/paneer-tofu/1573.php"> Paneer & Tofu </a> </li> </ul> </li> <li class="o-menu"> <a href="c/groceries/staples/13.php"> Staples </a> <ul> <li> <a href="c/groceries/staples/atta-flours-sooji/26.php"> Atta, Flours & Sooji </a> </li> <li> <a href="c/groceries/staples/dals-pulses/17.php"> Dals & Pulses </a> </li> <li> <a href="c/groceries/staples/rice-rice-products/14.php"> Rice & Rice Products </a> </li> <li> <a href="c/groceries/staples/edible-oils/58.php"> Edible Oils </a> </li> <li> <a href="c/groceries/staples/masalas-spices/21.php"> Masalas & Spices </a> </li> <li> <a href="c/groceries/staples/salt-sugar-jaggery/23.php"> Salt, Sugar & Jaggery </a> </li> <li> <a href="c/groceries/staples/soya-products-wheat-other-grains/106.php"> Soya Products, Wheat & Other Grains </a> </li> <li> <a href="c/groceries/staples/dry-fruits-nuts/657.php"> Dry Fruits & Nuts </a> </li> </ul> </li> <li class="o-menu"> <a href="c/groceries/snacks-branded-foods/10.php"> Snacks & Branded Foods </a> <ul> <li> <a href="c/groceries/snacks-branded-foods/biscuits-cookies/11.php"> Biscuits & Cookies </a> </li> <li> <a href="c/groceries/snacks-branded-foods/noodle-pasta-vermicelli/86.php"> Noodle, Pasta, Vermicelli </a> </li> <li> <a href="c/groceries/snacks-branded-foods/breakfast-cereals/98.php"> Breakfast Cereals </a> </li> <li> <a href="c/groceries/snacks-branded-foods/snacks-namkeen/43.php"> Snacks & Namkeen </a> </li> <li> <a href="c/groceries/snacks-branded-foods/chocolates-candies/70.php"> Chocolates & Candies </a> </li> <li> <a href="c/groceries/snacks-branded-foods/ready-to-cook-eat/53.php"> Ready To Cook & Eat </a> </li> <li> <a href="c/groceries/snacks-branded-foods/frozen-veggies-snacks/111.php"> Frozen Veggies & Snacks </a> </li> <li> <a href="c/groceries/snacks-branded-foods/spreads-sauces-ketchup/55.php"> Spreads, Sauces, Ketchup </a> </li> <li> <a href="c/groceries/snacks-branded-foods/indian-sweets/46.php"> Indian Sweets </a> </li> <li> <a href="c/groceries/snacks-branded-foods/pickles-chutney/51.php"> Pickles & Chutney </a> </li> <li> <a href="c/groceries/snacks-branded-foods/extracts-flavouring/181.php"> Extracts & Flavouring </a> </li> </ul> </li> <li class="o-menu"> <a href="c/groceries/beverages/33.php"> Beverages </a> <ul> <li> <a href="c/groceries/beverages/tea/34.php"> Tea </a> </li> <li> <a href="c/groceries/beverages/coffee/94.php"> Coffee </a> </li> <li> <a href="c/groceries/beverages/fruit-juices/96.php"> Fruit juices </a> </li> <li> <a href="c/groceries/beverages/energy-soft-drinks/40.php"> Energy & Soft Drinks </a> </li> <li> <a href="c/groceries/beverages/health-drink-supplement/49.php"> Health Drink & Supplement </a> </li> <li> <a href="c/groceries/beverages/soda-flavoured-water/115.php"> Soda & Flavoured Water </a> </li> </ul> </li> <li class="o-menu"> <a href="c/groceries/personal-care/91.php"> Personal Care </a> <ul> <li> <a href="c/groceries/personal-care/hair-care/92.php"> Hair Care </a> </li> <li> <a href="c/groceries/personal-care/oral-care/132.php"> Oral Care </a> </li> <li> <a href="c/groceries/personal-care/skin-care/122.php"> Skin Care </a> </li> <li> <a href="c/groceries/personal-care/bath-hand-wash/119.php"> Bath & Hand Wash </a> </li> <li> <a href="c/groceries/personal-care/body-wash-bathing-accessories/179.php"> Body Wash & Bathing Accessories </a> </li> <li> <a href="c/groceries/personal-care/feminine-hygiene/134.php"> Feminine Hygiene </a> </li> <li> <a href="c/groceries/personal-care/men-s-grooming/163.php"> Men's Grooming </a> </li> <li> <a href="c/groceries/personal-care/deo-fragrances/172.php"> Deo & Fragrances </a> </li> <li> <a href="c/groceries/personal-care/health-wellness/165.php"> Health & Wellness </a> </li> <li> <a href="c/groceries/personal-care/makeup/188.php"> Makeup </a> </li> <li> <a href="c/groceries/personal-care/covid-essentials/373.php"> Covid Essentials </a> </li> </ul> </li> <li class="o-menu"> <a href="c/groceries/home-care/36.php"> Home Care </a> <ul> <li> <a href="c/groceries/home-care/detergents/37.php"> Detergents </a> </li> <li> <a href="c/groceries/home-care/dishwash/148.php"> Dishwash </a> </li> <li> <a href="c/groceries/home-care/all-purpose-cleaners/152.php"> All Purpose Cleaners </a> </li> <li> <a href="c/groceries/home-care/fresheners-repellents/65.php"> Fresheners & Repellents </a> </li> <li> <a href="c/groceries/home-care/mops-brushes-scrubs/184.php"> Mops, Brushes & Scrubs </a> </li> <li> <a href="c/groceries/home-care/electrical/175.php"> Electrical </a> </li> <li> <a href="c/groceries/home-care/disposables/170.php"> Disposables </a> </li> <li> <a href="c/groceries/home-care/pooja-needs/156.php"> Pooja Needs </a> </li> <li> <a href="c/groceries/home-care/shoe-care/139.php"> Shoe Care </a> </li> <li> <a href="c/groceries/home-care/stationery/262.php"> Stationery </a> </li> <li> <a href="c/groceries/home-care/home-appliances/302.php"> Home Appliances </a> </li> <li> <a href="c/groceries/home-care/kitchenware/402.php"> kitchenware </a> </li> </ul> </li> <li class="o-menu"> <a href="c/groceries/baby-care/81.php"> Baby Care </a> <ul> <li> <a href="c/groceries/baby-care/baby-grooming/158.php"> Baby Grooming </a> </li> <li> <a href="c/groceries/baby-care/baby-bath-hygiene/197.php"> Baby Bath & Hygiene </a> </li> <li> <a href="c/groceries/baby-care/diapers-wipes/202.php"> Diapers & Wipes </a> </li> <li> <a href="c/groceries/baby-care/health-wellness/387.php"> Health & Wellness </a> </li> </ul> </li> </ul> </div> </div> </div> <main id="maincontent" class="main-section "> <div class="breadcrumbs d-none d-sm-block"> <ul class="items"> <li class="home"> <a href="index.php" title="Go to Home"> Home </a> </li> <li class="home"> <a href="customer/account.php" title="Go to My Account"> My Account </a> </li> <li class="home"> <span>Need Help</span> </li> </ul> </div> <div class="header_section"> <h5>Need Help</h5> </div> <div class="clearfix"></div> <div class="top_section"> <h1>Issue with your order?</h1> <p>One of the item in the order delivered is defective, missing or</p> <a href="help-support/raise-ticket.php" class="btn_section btn_newTicket">Raise a New Ticket</a> <a href="help-support/your-tickets.php" class="btn_section btn_prevTicket">Your Previous Tickets</a> </div> <div class="col-12"> <div class="help-content"> <h1>Need Help</h1> <div class="help-menu li_disabled" data-categoryid="1880"> <h2><a href="faqs.php">Frequently Asked Questions</a></h2> </div> </div> </div> </main> <footer> <div class="footer-container"> <ul> <li> <h2>Most Popular Categories</h2> </li> <li><a href="c/groceries/staples/13.php">Staples</a></li> <li><a href="c/groceries/beverages/33.php">Beverages</a></li> <li><a href="c/groceries/personal-care/91.php">Personal Care</a></li> <li><a href="c/groceries/home-care/36.php">Home Care</a></li> <li><a href="c/groceries/fruits-vegetables/219.php">Fruits and Vegetables</a></li> <li><a href="c/groceries/baby-care/81.php">Baby Care</a></li> <li><a href="c/groceries/snacks-branded-foods/10.php">Snacks &amp; Branded Foods</a></li> <li><a href="c/groceries/dairy-bakery/61.php">Dairy &amp; Bakery</a></li> </ul> <ul> <li> <h2>Customer Services</h2> </li> <li><a href="about-us.php">About Us</a></li> <li><a href="faqs.php">FAQ</a></li> <li><a href="terms-and-conditions.php">Terms and conditions</a></li> <li><a href="https://relianceretail.com/privacy-policy.php" target="_blank" rel="noopener">Privacy policy</a></li> <li><a href="reliance-retail-e-waste-recycling-policy.php">E-waste Policy</a></li> </ul> <div class="subscribe"> <h2>Contact Us</h2> WhatsApp us : <span style="display: inline-block; margin-bottom: 1rem;"><a href="https://wa.me/917000370003?text=Hi" target="_blank" rel="noopener">70003 70003</a></span><br />Call Us : <span style="display: inline-block;"><a href="tel:1800 890 1222" target="_blank" rel="noopener">1800 890 1222</a></span><br /> <p>8:00 AM to 8:00 PM, 365 days</p> <p>Please note that you are accessing the BETA Version of <a href="index.php">www.Vedgun.com</a></p> <p>Should you encounter any bugs, glitches, lack of functionality, delayed deliveries, billing errors or other problems on the beta website, please email us on <a href="mailto:cs@Vedgun.com">cs@Vedgun.com</a></p> <br /> <h2>Download App</h2> <br /><a href="https://play.google.com/store/apps/details?id=com.jpl.Vedgun" target="_blank" rel="noopener" style="margin-right: 16px;"><img src="images/cms/wysiwyg/app-icons/play_store.png" alt="Download Vedgun App for Android from Play Store" /></a><a href="https://apps.apple.com/in/app/Vedgun/id1522085683" target="_blank" rel="noopener"><img src="images/cms/wysiwyg/app-icons/ios_store.png" alt="Download Vedgun App for iOs from App Store" /></a></div> </div> </footer><!-- Copyright Section --> <small class="copyright"> <div class="copyblock"> <ul> <li>Best viewed on Microsoft Edge 81+, Mozilla Firefox 75+, Safari 5.1.5+, Google Chrome 80+</li> <li>© 2020 All rights reserved. Reliance Retail Ltd.</li> </ul> </div> </small> </div> <div class="modal fade" id="rel_pincode_popup" data-easein="slideUpBigIn" tabindex="-1" role="dialog"> <div class="modal-dialog" role="document"> <div class="modal-content"> <div class="modal-header"> <h5 class="modal-title"><span>Happiness</span> Home Delivered...</h5> <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button></div> <div class="clearfix"></div> <div id="delivery_details"> <form id="rel_pincode_form"> <div class="lblock"> <label>Where do you want us to deliver your grocery?</label> <input type="text" class="inp_text" name="rel_pincode" id="rel_pincode" placeholder="Enter your Pincode" autocomplete="off" maxlength="6" /> <div id="rel_pin_msg"></div> <button type="submit" class="shopping_btn">Start Shopping</button> </div> <div class="rblock"> <img src="assets/smartweb/images/delivery_popup_jio.png" alt="Vedgun, Online Groceries Shop"> </div> <div class="clearfix"></div> </form> </div> </div> </div> </div> <script type="application/ld+json">
            {        
                "@context": "https://schema.org",
                "@type": "BreadcrumbList",
                "itemListElement": [
    {
        "@type": "ListItem",
        "position": 0,
        "name": "Home",
        "item": "https://www.Vedgun.com/"
    },
    {
        "@type": "ListItem",
        "position": 1,
        "name": "My Account",
        "item": "https://www.Vedgun.com/customer/account"
    },
    {
        "@type": "ListItem",
        "position": 2,
        "name": "Need Help",
        "item": "https://www.Vedgun.com/help-support"
    }
]            }
        </script> <input type="hidden" id="mstar_api_baseurl" value="https://www.Vedgun.com/mst/rest/v1/" /> <input type="hidden" id="gift_api_url" value="/api/v1/myorders/giftbulkordersubmit" /> <input type="hidden" id="gift_auth" value="Z2lmdGJ1bGtvcmRlcjpVMnBZVVNaaUpXaEtka2xuWVZsNA==" /> <script type="text/javascript" src="assets/smartweb/js/lazysizes-umd.min.js" async=""></script> <script type="text/javascript" src="assets/smartweb/js/jquery-3.4.1.min.js" crossorigin="anonymous"></script> <script type="text/javascript" src="assets/smartweb/js/jquery-ui.min.js" defer crossorigin="anonymous"></script> <script src="assets/smartweb/js/bootstrap.min.js" defer crossorigin="anonymous"></script> <script type="text/javascript" src="assets/smartweb/js/clipboard.min.js" defer crossorigin="anonymous"></script> <script type="text/javascript" src="assets/smartweb/js/swiper.min.js" defer crossorigin="anonymous"></script> <script src="assets/smartweb/js/algolia-autocomplete.min.js" defer crossorigin="anonymous"></script> <script src="../cdn.jsdelivr.net/algoliasearch/3/algoliasearch.min.js" defer crossorigin="anonymous"></script> <script src="assets/smartweb/js/jquery.cookie.min.js" defer crossorigin="anonymous"></script> <script type="text/javascript" src="assets/smartweb/js/bootstrap.notify.min.js" defer crossorigin="anonymous"></script> <script type="text/javascript" src="assets/smartweb/js/jquery.validate.min.js" defer crossorigin="anonymous"></script> <script type="text/javascript" src="assets/smartweb/js/jquery.md5.min.js" defer crossorigin="anonymous"></script> <script type="text/javascript" src="assets/version1605113383/smartweb/js/need-help.min.js" defer crossorigin="anonymous"></script> <script type="text/javascript" src="assets/version1605113383/smartweb/js/jquery.multiselect.min.js" defer crossorigin="anonymous"></script> <script>
    $(document).ready(function () {
        $('.combo-view-more').click(function(){
            var target = $(this).attr("data-target");
            $(target).modal();
        });
    });
</script> <script>
    $(document).ready(function(){
        var userId = localStorage.getItem('userid');
        var authToken = localStorage.getItem('authtoken');
        var displayName = localStorage.getItem('displayname');
        var login_pincode = localStorage.getItem('nms_mgo_pincode');
                if(login_pincode && (login_pincode !="")) {
            $.cookie("nms_mgo_pincode", login_pincode, { expires : 1, path    : '/' });
        }
    });
</script> <script type="text/javascript">
$(document).ready(function () {
    localStorage.removeItem('loginpage');
    window.user_id     = (localStorage.getItem('userid')!=null) ? localStorage.getItem('userid'):"" ;
    window.auth_token  = (localStorage.getItem('authtoken')!=null) ? localStorage.getItem('authtoken'):"";
    window.cust_dname  = (localStorage.getItem('displayname')!=null) ? localStorage.getItem('displayname'):"";
        window.login_session = {
      "async": true,
      "crossDomain": true,
      "url": "https://www.Vedgun.com/mst/rest/v1/entity/customer/get_details",
      "method": "GET",
      "headers": {
        "userid": window.user_id,
        "authtoken": window.auth_token
      }
    };
    if((user_id!="" && user_id != 0) && (cust_dname!="")){
        $('.login #logged_user').text("");
        $('.login #logged_user').append(cust_dname);
        $('.login a:first').hide();
        $('.login #logged_user').show();
        $("#customer-name").text("Hello, "+cust_dname);
        $("#profile-link").attr("href","/customer/account");
        $("#sign_in_out").text('Logout').attr("href","/customer/account/logout");
    } else {
        $('.login #logged_user').hide();
        $('.login a:first').show();
    }
        $('.logged').show();
});
</script> <input type="hidden" name="enable_fbpixel" id="enable_fbpixel" value="0" /> <script type="text/javascript" src="assets/version1605113383/smartweb/js/main.min.js" defer crossorigin="anonymous"></script> <script type="text/javascript" src="assets/version1605113383/smartweb/js/cart.min.js" defer crossorigin="anonymous"></script> <script src="assets/version1605113383/smartweb/js/search_autocomplete.min.js" defer crossorigin="anonymous"></script> <script type="text/javascript" src="assets/smartweb/js/url.min.js" defer crossorigin="anonymous"></script> <script>
function getPageType(){
    var pageType = 'other pages';
    if($("body").hasClass("cms-home")){
        pageType = "Home Page";
    }else if($("body").hasClass("catalog-category-view")){
        pageType = "category page";
    }else if($("body").hasClass("catalog-product-view")){
        pageType = "Product Details Page";
    }
    else if($("body").hasClass("search-result-page")){
        pageType = "Search Page";
    }            
    return pageType;
}   

function trackGoogleEvents(category,action,label){
    if("ga"in window){
        tracker=ga.getAll()[0];
        if(tracker){
            tracker.send("event",category,action,label);
        }
    }
}



$(document).ready(function(){  
    $('#size_chart_btn').on('click',function(){
        var dataURL = $(this).attr('data-href');
        $('#sizechart_dialog .dialog_content').load(dataURL,function(){
            $('#sizechart_dialog').modal({show:true,backdrop:'static'});
        });
    });
    $(".add_to_cart_fixed .cartbag").click(function(){
        trackGoogleEvents("New Click actions","Add to cart button","Product Holder");
    });

    $("#search").focus(function(){
        trackGoogleEvents("New Click actions","Search","");
    });

    $(".mini-cart").click(function(){
        var pageType = 'other pages';
        if($("body").hasClass("cms-home")){
            pageType = "home page";
        }
        else if($("body").hasClass("catalog-category-view")){
            pageType = "category page";
        }
        else if($("body").hasClass("catalog-product-view")){
            pageType = "product page";
        }
        trackGoogleEvents("New Click actions","Cart",pageType);
    });  

    });
</script> <script>
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('service-worker.js', {
          scope: '/'
        });
    });
}
</script> <script>
  var ALGOLIA_INSIGHTS_SRC = "//cdn.jsdelivr.net/npm/search-insights@1.3.1";

  !function(e,a,t,n,s,i,c){e.AlgoliaAnalyticsObject=s,e[s]=e[s]||function(){
  (e[s].queue=e[s].queue||[]).push(arguments)},i=a.createElement(t),c=a.getElementsByTagName(t)[0],
  i.async=1,i.src=n,c.parentNode.insertBefore(i,c)
  }(window,document,"script",ALGOLIA_INSIGHTS_SRC,"aa");


  // Initialize library
  aa('init', {
    appId: window.algolia_app_id,
    apiKey: window.algolia_api_key
  });
</script> <script>
if($("body").hasClass("gift-page")){
    $(".pages-items a").each(function(i,el){
        var href = $(el).attr("href");
        if (href.indexOf('/gifting/page/2') > -1) {
            $(el).attr("href",href+"?prod_mart_master_vertical_products_popularity");
        }
    });
}
</script> <script>
if($("body").hasClass("prod-jewellery")){
$( "#price_section" ).after( "<div class='clearfix'></div><p class='prepaid_msg'>Only Prepaid Orders Allowed</p>" );
}
</script> </body> 
<!-- Mirrored from www.Vedgun.com/help-support by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 30 Nov 2020 05:36:22 GMT -->
</html>