<?php
session_start();
//$sesName = md5(md5("#".session_id()."@School".date("ymd")));

unset($_SESSION['userid']);
unset($_SESSION['username']);
unset($_SESSION['mobile']);
unset($_SESSION['login']);
	header("location:index.php");
?>